package SALESFORCE.TESTSCRIPTS;

import SALESFORCE.FUNCTIONLIBRARY.FunctionLibrary_SalesForce;

/**
 * Created with IntelliJ IDEA.
 * User: Ajay.khare
 * Date: 4/2/14
 * Time: 11:39 AM
 * To change this template use File | Settings | File Templates.
 */
public class SalesForce_ErrorMessageDisplayed extends FunctionLibrary_SalesForce {
    public static void main(String[] args)
    {
        try
        {
            SalesForce_ErrorMessageDisplayed oTestMain = new SalesForce_ErrorMessageDisplayed();
            oTestMain.testmain();
        }
        catch(Exception oException)
        {
            System.out.println(oException.toString());
        }
    }

    public void testmain()
    {
        String sScriptName = "";
        int iCount =87;
        boolean bResult;
        bGLTaxCodeAtLinelevel = false;
        try
        {
            sGLCustomer = "Testing";
            sGLItem1Code = "GenWatt Diesel 1000kW";
           // sGLItem2Code = "GenWatt Diesel 10kW";
         //   sGLItem3Code = "GenWatt Diesel 200kW";
          //  sGLAmount =  oResultSet.getString("Amount");
            //sGLTotalTax =  oResultSet.getString("TotalTax");
            //Step 1: Browse to application URL and login
            bResult = fStartFunction();
            if(! bResult)
                return;
            // Start Data sheet test cases execution
            for (int iTemp = 80; iTemp <= iCount; iTemp++)
            {
                sGLTestCaseName = "TestCase" + iTemp;
                fCalculateSalesTax (sGLTestCaseName);
            }
        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, oException.toString());
        }
        finally
        {
            fFinallyFunction(sScriptName);
        }
    }


}