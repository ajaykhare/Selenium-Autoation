package SALESFORCE.TESTSCRIPTS;

import SALESFORCE.FUNCTIONLIBRARY.*;
/**
 * Created with IntelliJ IDEA.
 * User: Ajay.khare
 * Date: 4/2/14
 * Time: 11:38 AM
 * To change this template use File | Settings | File Templates.
 */
public class SalesForce_EntityUseCode extends FunctionLibrary_SalesForce {
    public  static void main(String args[])     {
        try
        {
            SalesForce_EntityUseCode oTestMain = new SalesForce_EntityUseCode();
            oTestMain.testmain();
        }
        catch(Exception oException)
        {
            System.out.println(oException.toString());
        }
    }
    public void testmain()
    {


        String sScriptName = "";
        int iCount =111;
        boolean bResult;
        bGLTaxCodeAtLinelevel = false;
        try
        {
            sGLCustomer = "Testing";
            sGLItem1Code = "GenWatt Diesel 1000kW";
            sGLItem2Code = "GenWatt Diesel 10kW";
            sGLItem3Code = "GenWatt Diesel 200kW";

            //Step 1: Browse to application URL and login

            bResult = fStartFunction();
            if(!bResult)
                return;
            // Start Data sheet test cases execution
            for (int iTemp = 110; iTemp <= iCount; iTemp++)
            {
                sGLTestCaseName = "TestCase" + iTemp;
                fCalculateSalesTax (sGLTestCaseName);
            }
        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, oException.toString());
        }
        finally
        {
            fFinallyFunction(sScriptName);
        }
        //return;
    }
}
