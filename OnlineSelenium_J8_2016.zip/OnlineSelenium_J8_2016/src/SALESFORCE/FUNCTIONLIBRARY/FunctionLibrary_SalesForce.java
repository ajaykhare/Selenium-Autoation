package SALESFORCE.FUNCTIONLIBRARY;

import GLOBALLIBRARY.GenericFunctions;
//import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
//import org.openqa.selenium.Keys;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.*;
//import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.firefox.*;

import java.net.InetAddress;
import java.text.DecimalFormat;
import java.util.concurrent.TimeUnit;

/**
 * Created with IntelliJ IDEA.
 * User: Ajay.khare
 * Date: 3/13/14
 * Time: 11:20 AM
 * To change this template use File | Settings | File Templates.
 */
public class FunctionLibrary_SalesForce extends GenericFunctions

{
    public boolean fStartFunction()
    {
        boolean bResult;// = false;

        try
        {
            sGLTestCaseName = "";
            String qualifiedClassName = new Exception().getStackTrace()[1].getClassName();
            //if (sGLScriptName.equalsIgnoreCase(""))
            sGLScriptName = qualifiedClassName.substring(qualifiedClassName.lastIndexOf('.') + 1, qualifiedClassName.length());
            if (sGLMachineName.equalsIgnoreCase(""))
                sGLMachineName = InetAddress.getLocalHost().getHostName();
            //Below function opens new browser With application URL and process with login
            bResult = fLogin_SalesForce();
           return bResult;

            ///////////////////////////CREATE PRODUCTS//////////////////////////////////

           // bResult =  fCreateProducts();
          //  return bResult;
          ////////////////////////////////////////////////////////////////////////////

        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, "Start Block: " + oException.toString());
            return false;
        }
    } // End fStartFunction

    /**************************************************************************************************
    /**
     * Description   : Function To close connection.
    ***************************************************************************************************/
    public void fFinallyFunction(String sScriptName)
    {
        try
        {
            // Close connection if already open.
            if (oConnection != null )
                if(oConnection.isClosed() == false)
                    oConnection.close();
            oConnection = null;

            iGLCalculateTax = 0;  // 0 means nothing; 1 means dont calculate tax
            iGLEnterShiptoAddressontheFly = 1;  // 0 means Select Ship to addres from drop down; 1 means Enter address Run time
            iGLMSR = 0;  // 0 means NO MSR ; 1 means MSR and enter line level ship to addresses
        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, "Finally Block: " + oException.toString());
        }
        sGLTestCaseName = sScriptName;
        fLogMessage(1 , sGLTestCaseName, "Script Ended.");
    } // End fFinallyFunction
    /**************************************************************************************************
    /**
     * Description   : Function to login Sales Force web application
     * @return boolean : true if Application is logged successfully, false otherwise
     **************************************************************************************************/
    public boolean fLogin_SalesForce() throws Exception
    {

        String sEmail = "ajay.khare@asf.com";
        String sPassword = "Avalara@2016$";
        try
        {
            driver.get("https://login.salesforce.com/?locale=in");
            //Maximizing the window
            driver.manage().window().maximize();
            Thread.sleep(1000);
            // For Window switch
            String winName=   driver.getWindowHandle();
            driver.getWindowHandles() ;     // List of tabs name
            driver.switchTo().window(winName)  ;
            System.out.println(winName);
            //
            // System.exit(0);
            // Enter credentials
            driver.findElement(By.id("username")).click();
            driver.findElement(By.id("username")).clear();
            driver.findElement(By.id("username")).sendKeys(sEmail);
            driver.findElement(By.id("password")).clear();
            driver.findElement(By.id("password")).sendKeys(sPassword);
            // Click on Login button
            driver.findElement(By.id("Login")).click();
            ExecutionDelay (10);
            // Refreshing the page
           // driver.get("https://na15.salesforce.com/setup/forcecomHomepage.apexp?setupid=ForceCom&retURL=%2Fsecur%2Ffrontdoor.jsp%3Fsid%3D00Di0000000bOoK%2521AQcAQCAUgiZeJnDQwfnF0FbfR3v00kc09ze279RBYwjJTF.Eawb933Kwaip7o5q3wYDftc3HSNX_JtrXTxmCvNtiZKGEp2Ku%26apv%3D1%26cshc%3D0000000kXi40000000bOoK%26display%3Dpage");
           // driver.navigate().refresh();
            if(IsElementPresent(By.linkText("Home")))
            {
            fLogMessage(1,sGLTestCaseName,"Logging into SalesForce application is successful.");
            }
            else
            fLogMessage(0,sGLTestCaseName,"Logging into SalesForce application is Failed.");
            return true;
        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fLoginException:" + oException.toString());
            return false;
        }
    }// End fLogin_Sales Force
/**************************************************************************************************
    /**
     * Description   : Function to go to menu
     * @param sMenu: String for menu
     * @return boolean : true if Menu selection is successful, false otherwise
    ********************************************************************************************* */
    public boolean fMenuSelection(String sMenu) throws Exception
    {
        String sOpportunityName, sQuotesName;
        try
        {
           // Thread.sleep(2000);
            ExecutionDelay (10);
            // Open TaxNowSettings
            if(sMenu.equalsIgnoreCase("TaxNowSettings"))
            {
                if(IsElementPresent(By.linkText("Avalara")));
                {
                    driver.findElement(By.linkText("Avalara")).click();
                    ExecutionDelay (10);

                    driver.manage().timeouts().implicitlyWait(lGL_MAX_WAIT_TIME_IN_Seconds, TimeUnit.SECONDS);
                    // Click on recent TaxNow setting Ajay
                    driver.findElement(By.xpath("//td[@id='bodyCell']/div[3]/div/div/div[2]/table/tbody/tr[2]/th/a")).click(); // Ajay
                    // Check Address validation flag
                    if (sGLAddressValidationFlag != null)
                    {
                        ExecutionDelay (5);
                        driver.findElement(By.name("edit")).click();
                        ExecutionDelay (5);
                        driver.findElement(By.xpath("//textarea")).click();  // Origin street
                        driver.findElement(By.xpath("//textarea")).clear();
                        driver.findElement(By.xpath("//textarea")).sendKeys(sGLShiptoAddress_Line1);
                        driver.findElement(By.xpath("//div[7]/table/tbody/tr[2]/td[2]/input")).clear();  // Origin city
                        driver.findElement(By.xpath("//div[7]/table/tbody/tr[2]/td[2]/input")).sendKeys(sGLShiptoAddress_City);
                        driver.findElement(By.xpath("//div[7]/table/tbody/tr[3]/td[2]/input")).clear();  // State
                        driver.findElement(By.xpath("//div[7]/table/tbody/tr[3]/td[2]/input")).sendKeys(sGLShiptoAddress_State);
                        driver.findElement(By.xpath("//div[7]/table/tbody/tr[4]/td[2]/input")).clear();   // Zip
                        driver.findElement(By.xpath("//div[7]/table/tbody/tr[4]/td[2]/input")).sendKeys( sGLShiptoAddress_Zip);
                        driver.findElement(By.xpath("//tr[5]/td[2]/input")).clear();   // Country
                        driver.findElement(By.xpath("//tr[5]/td[2]/input")).sendKeys(sGLShipToCountryCode);
                        driver.findElement(By.name("save")).click();
                    }
                }
            }

            // Open Opportunities tab and create new opportunities
            if(sMenu.equalsIgnoreCase("Orders"))
            {
                if (IsElementPresent(By.linkText("Orders")))
                {
                    driver.findElement(By.linkText("Orders")).click();
                    ExecutionDelay (10);
                    driver.findElement(By.name("new")).click();
                    ExecutionDelay (10);
                    driver.findElement(By.xpath("//div/span/input")).clear();
                    driver.findElement(By.xpath("//div/span/input")).sendKeys("Test007");
                    driver.findElement(By.id("EffectiveDate")).click();
                    driver.findElement(By.id("EffectiveDate")).clear();
                    driver.findElement(By.id("EffectiveDate")).sendKeys(sGLDate);
                    driver.findElement(By.id("Contract")).click();
                    driver.findElement(By.id("Contract")).clear();
                    driver.findElement(By.id("Contract")).sendKeys("00000104");
                    // Entering Billing address
                    driver.findElement(By.id("BillingAddressstreet")).clear();
                    driver.findElement(By.id("BillingAddressstreet")).sendKeys(sGLShiptoAddress_Line1);
                    driver.findElement(By.id("BillingAddresscity")).clear();
                    driver.findElement(By.id("BillingAddresscity")).sendKeys(sGLShiptoAddress_City);
                    driver.findElement(By.id("BillingAddresszip")).clear();
                    driver.findElement(By.id("BillingAddresszip")).sendKeys(sGLShiptoAddress_Zip);
                    if (sGLCountryPickList == null)
                    {
                    driver.findElement(By.id("BillingAddressstate")).clear();
                    driver.findElement(By.id("BillingAddressstate")).sendKeys(sGLShiptoAddress_State);
                    driver.findElement(By.id("BillingAddresscountry")).clear();
                    driver.findElement(By.id("BillingAddresscountry")).sendKeys(sGLShipToCountryCode);
                    }


                    // Entering shipping address
                    driver.findElement(By.id("ShippingAddressstreet")).clear();
                    driver.findElement(By.id("ShippingAddressstreet")).sendKeys(sGLShiptoAddress_Line1);
                    driver.findElement(By.id("ShippingAddresscity")).clear();
                    driver.findElement(By.id("ShippingAddresscity")).sendKeys(sGLShiptoAddress_City);
                    driver.findElement(By.id("ShippingAddresszip")).clear();
                    driver.findElement(By.id("ShippingAddresszip")).sendKeys(sGLShiptoAddress_Zip);
                    if (sGLCountryPickList == null)
                    {
                    driver.findElement(By.id("ShippingAddressstate")).clear();
                    driver.findElement(By.id("ShippingAddressstate")).sendKeys(sGLShiptoAddress_State);

                    driver.findElement(By.id("ShippingAddresscountry")).clear();
                    driver.findElement(By.id("ShippingAddresscountry")).sendKeys(sGLShipToCountryCode);
                    }


                    // Check for Misc charges
                    if (sGLShippingHandling != null)
                    {
                        driver.findElement(By.xpath("//tr[4]/td[4]/input")).clear();
                        driver.findElement(By.xpath("//tr[4]/td[4]/input")).sendKeys(sGLShippingHandling);
                    }
                    driver.findElement(By.name("save")).click();
                    fLogMessage(1,sGLTestCaseName,"Order created successfully");
                }
                else
                    fLogMessage(0,sGLTestCaseName,"Order link not visible");
            }

            // Open Opportunities tab and create new opportunities
            if(sMenu.equalsIgnoreCase("Opportunities"))
            {
                if (IsElementPresent(By.id("Opportunity_Tab")))
                {
                    driver.findElement(By.linkText("Opportunities")).click();
                    ExecutionDelay (10);
                    driver.findElement(By.name("new")).click();
                    sOpportunityName = fRamdomString (5);
                    driver.findElement(By.id("opp3")).clear();
                    driver.findElement(By.id("opp3")).sendKeys(sOpportunityName);
                    driver.findElement(By.id("opp4")).clear();
                    driver.findElement(By.id("opp4")).sendKeys("Test007");
                    driver.findElement(By.id("opp9")).clear();
                    driver.findElement(By.id("opp9")).sendKeys(sGLDate);
                    new Select(driver.findElement(By.id("opp11"))).selectByVisibleText("Closed Won");
                    // Check for Misc charges
                    if (sGLShippingHandling != null)
                    {
                        driver.findElement(By.xpath("//tr[4]/td[4]/input")).clear();
                        driver.findElement(By.xpath("//tr[4]/td[4]/input")).sendKeys(sGLShippingHandling);
                    }
                    driver.findElement(By.name("save")).click();
                    ExecutionDelay (10);
                    fLogMessage(1,sGLTestCaseName,"Opportunities created successfully");
                }
                else
                    fLogMessage(0,sGLTestCaseName,"Opportunities link not visible");
            }
            // Create newQuote
            if(sMenu.equalsIgnoreCase("newQuote"))
            {
                driver.findElement(By.name("newQuote")).click();
                ExecutionDelay (10);
               // driver.manage().timeouts().implicitlyWait(lGL_MAX_WAIT_TIME_IN_Seconds, TimeUnit.SECONDS);
                sQuotesName = fRamdomString (4);
                driver.findElement(By.id("Name")).clear();
                driver.findElement(By.id("Name")).sendKeys(sQuotesName);
                driver.findElement(By.id("ExpirationDate")).clear();
                driver.findElement(By.id("ExpirationDate")).sendKeys(sGLDate);
                if (sGLShippingHandling != null)
                {
                    driver.findElement(By.xpath("//tr[4]/td[4]/input")).clear();
                    driver.findElement(By.xpath("//tr[4]/td[4]/input")).sendKeys(sGLShippingHandling);
                }
                if (sGLAddressValidationFlag != null)
                {
                    // Enter Billing address on Quotes window
                    driver.findElement(By.id("BillingAddressstreet")).clear();
                    driver.findElement(By.id("BillingAddressstreet")).sendKeys(sGLShiptoAddress_Line1);
                    driver.findElement(By.id("BillingAddresscity")).clear();
                    driver.findElement(By.id("BillingAddresscity")).sendKeys(sGLShiptoAddress_City);
                    driver.findElement(By.id("BillingAddresszip")).clear();
                    driver.findElement(By.id("BillingAddresszip")).sendKeys(sGLShiptoAddress_Zip);

                    if (sGLCountryPickList == null)
                    {
                    driver.findElement(By.id("BillingAddressstate")).clear();
                    driver.findElement(By.id("BillingAddressstate")).sendKeys(sGLShiptoAddress_State);
                    driver.findElement(By.id("BillingAddresscountry")).clear();
                    driver.findElement(By.id("BillingAddresscountry")).sendKeys(sGLShipToCountryCode);
                    }
                    //Enter Shipping  address on Quotes window
                    driver.findElement(By.id("ShippingAddressstreet")).clear();
                    driver.findElement(By.id("ShippingAddressstreet")).sendKeys(sGLShiptoAddress_Line1);
                    driver.findElement(By.id("ShippingAddresscity")).clear();
                    driver.findElement(By.id("ShippingAddresscity")).sendKeys(sGLShiptoAddress_City);
                    driver.findElement(By.id("ShippingAddresszip")).clear();
                    driver.findElement(By.id("ShippingAddresszip")).sendKeys(sGLShiptoAddress_Zip);

                    if (sGLCountryPickList == null)
                    {
                    driver.findElement(By.id("ShippingAddressstate")).clear();
                    driver.findElement(By.id("ShippingAddressstate")).sendKeys(sGLShiptoAddress_State);
                    driver.findElement(By.id("ShippingAddresscountry")).clear();
                    driver.findElement(By.id("ShippingAddresscountry")).sendKeys(sGLShipToCountryCode);
                    }
                }
                driver.findElement(By.name("save")).click();
            }
            // Open Contacts window
            if(sMenu.equalsIgnoreCase("Contacts"))
            {
                driver.findElement(By.linkText("Contacts")).click();
                ExecutionDelay (10);
                driver.findElement(By.linkText("khare, Ajay")).click();
                ExecutionDelay (6);
                driver.findElement(By.name("edit")).click();
                ExecutionDelay (5);
                //Shipping
                driver.findElement(By.id("con19street")).clear();
                driver.findElement(By.id("con19street")).sendKeys(sGLShiptoAddress_Line1);
                driver.findElement(By.id("con19city")).clear();
                driver.findElement(By.id("con19city")).sendKeys(sGLShiptoAddress_City);
                driver.findElement(By.id("con19zip")).clear();
                driver.findElement(By.id("con19zip")).sendKeys(sGLShiptoAddress_Zip);

                if (sGLCountryPickList == null)
                {
                driver.findElement(By.id("con19state")).clear();
                driver.findElement(By.id("con19state")).sendKeys(sGLShiptoAddress_State);
                driver.findElement(By.id("con19country")).clear();
                driver.findElement(By.id("con19country")).sendKeys(sGLShipToCountryCode);
                }
                //Mailing
                driver.findElement(By.id("con18street")).clear();
                driver.findElement(By.id("con18street")).sendKeys(sGLShiptoAddress_Line1);
                driver.findElement(By.id("con18city")).clear();
                driver.findElement(By.id("con18city")).sendKeys(sGLShiptoAddress_City);
                driver.findElement(By.id("con18zip")).clear();
                driver.findElement(By.id("con18zip")).sendKeys(sGLShiptoAddress_Zip);

                if (sGLCountryPickList == null)
                {
                driver.findElement(By.id("con18state")).clear();
                driver.findElement(By.id("con18state")).sendKeys(sGLShiptoAddress_State);
                driver.findElement(By.id("con18country")).clear();
                driver.findElement(By.id("con18country")).sendKeys(sGLShipToCountryCode);
                }
                driver.findElement(By.name("save")).click();
            }

            // Open Contracts window
            if(sMenu.equalsIgnoreCase("Contracts"))
            {
                driver.findElement(By.linkText("Contracts")).click();
                ExecutionDelay (14);
                driver.findElement(By.linkText("00000104")).click();
                ExecutionDelay (10);
                driver.findElement(By.xpath("//td[2]/input[3]")).click();
              //  driver.findElement(By.name("edit")).click();
                ExecutionDelay (5);
                // Billing Address line
                driver.findElement(By.id("ctrc25street")).clear();
                driver.findElement(By.id("ctrc25street")).sendKeys(sGLShiptoAddress_Line1);
                driver.findElement(By.id("ctrc25city")).clear();
                driver.findElement(By.id("ctrc25city")).sendKeys(sGLShiptoAddress_City);
                driver.findElement(By.id("ctrc25zip")).clear();
                driver.findElement(By.id("ctrc25zip")).sendKeys(sGLShiptoAddress_Zip);

                if (sGLCountryPickList == null)
                {
                driver.findElement(By.id("ctrc25state")).clear();
                driver.findElement(By.id("ctrc25state")).sendKeys(sGLShiptoAddress_State);
                driver.findElement(By.id("ctrc25country")).clear();
                driver.findElement(By.id("ctrc25country")).sendKeys(sGLShipToCountryCode);
                }

                // Shipping Address line
                driver.findElement(By.id("ShippingAddressstreet")).clear();
                driver.findElement(By.id("ShippingAddressstreet")).sendKeys(sGLShiptoAddress_Line1);
                driver.findElement(By.id("ShippingAddresscity")).clear();
                driver.findElement(By.id("ShippingAddresscity")).sendKeys(sGLShiptoAddress_City);
                driver.findElement(By.id("ShippingAddresszip")).clear();
                driver.findElement(By.id("ShippingAddresszip")).sendKeys(sGLShiptoAddress_Zip);

                if (sGLCountryPickList == null)
                {
                    driver.findElement(By.id("ShippingAddressstate")).clear();
                    driver.findElement(By.id("ShippingAddressstate")).sendKeys(sGLShiptoAddress_State);
                    driver.findElement(By.id("ShippingAddresscountry")).clear();
                    driver.findElement(By.id("ShippingAddresscountry")).sendKeys(sGLShipToCountryCode);
                }

                driver.findElement(By.name("save")).click();
            }

            // Open Accounts window
            if(sMenu.equalsIgnoreCase("Accounts"))
            {
                driver.findElement(By.linkText("Accounts")).click();
                ExecutionDelay (10);
                //driver.manage().timeouts().implicitlyWait(lGL_MAX_WAIT_TIME_IN_Seconds, TimeUnit.SECONDS);
                driver.findElement(By.xpath("//th/a")).click();  // Account name- Ajay
                driver.findElement(By.name("edit")).click();
                //driver.manage().timeouts().implicitlyWait(lGL_MAX_WAIT_TIME_IN_Seconds, TimeUnit.SECONDS);
                ExecutionDelay (10);
                if (sGLEntityUseCode != null)
                {
                    driver.findElement(By.xpath("//span/input")).clear();
                    driver.findElement(By.xpath("//span/input")).sendKeys(sGLEntityUseCode);
                }
                // Error message displayed test case for ship to null value
                if (sGLShiptoAddress_Line1==null)
                {
                    sGLShiptoAddress_Line1="";
                    sGLShiptoAddress_City ="";
                    sGLShiptoAddress_State="";
                    sGLShiptoAddress_Zip  ="";
                    sGLShipToCountryCode  ="";
                }
                // Billing address
                driver.findElement(By.id("acc17street")).clear();
                driver.findElement(By.id("acc17street")).sendKeys(sGLShiptoAddress_Line1);
                driver.findElement(By.id("acc17city")).clear();
                driver.findElement(By.id("acc17city")).sendKeys(sGLShiptoAddress_City);
                driver.findElement(By.id("acc17zip")).clear();
                driver.findElement(By.id("acc17zip")).sendKeys(sGLShiptoAddress_Zip);

                if (sGLCountryPickList == null)
                {
                driver.findElement(By.id("acc17state")).clear();
                driver.findElement(By.id("acc17state")).sendKeys(sGLShiptoAddress_State);
                driver.findElement(By.id("acc17country")).clear();
                driver.findElement(By.id("acc17country")).sendKeys(sGLShipToCountryCode);
                }
                // Shipping address
                driver.findElement(By.id("acc18street")).clear();
                driver.findElement(By.id("acc18street")).sendKeys(sGLShiptoAddress_Line1);
                driver.findElement(By.id("acc18city")).clear();
                driver.findElement(By.id("acc18city")).sendKeys(sGLShiptoAddress_City);
                driver.findElement(By.id("acc18zip")).clear();
                driver.findElement(By.id("acc18zip")).sendKeys(sGLShiptoAddress_Zip);

                if (sGLCountryPickList == null)
                {
                driver.findElement(By.id("acc18state")).clear();
                driver.findElement(By.id("acc18state")).sendKeys(sGLShiptoAddress_State);
                driver.findElement(By.id("acc18country")).clear();
                driver.findElement(By.id("acc18country")).sendKeys(sGLShipToCountryCode);
                }
                driver.findElement(By.name("save")).click();
            }

            //Thread.sleep(1000);
            ExecutionDelay (10);
            fLogMessage(1,sGLTestCaseName,"After clicking on menu " + sMenu + " Respective page opened successfully");
            return true;
        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fMenuSelection: Exception: " + oException.toString());
            return false;
        }
    }// End fMenuSelection
    /*******************************************************************************************************************
     * TaxNow Setting Function
     * Description   : Function for select the checkbox according data sheet test cases in TaxNow setting
     ******************************************************************************************************************/
    boolean fTaxNowSettingsOption()
    {
        driver.findElement(By.xpath("//td[@id='topButtonRow']/input[3]")).click();
        ExecutionDelay (10);
        // Check for EnableTaxCalculation
        if (sGLEnableTaxCalculation == null )
                {
                    if (driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[2]/td[2]/input")).isSelected() )

                    {
                        driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[2]/td[2]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[2]/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[2]/td[2]/input")).click();
            }
        }
        // Check for UncommittedInvoices
        if( sGLEnableUnCommitts == null)
        {
            if (driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[4]/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[4]/td[2]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[4]/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[4]/td[2]/input")).click();
            }
        }
        // Check for Commits
        if (sGLEnableCommittedInvoices == null)
        {
            if (driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[3]/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[3]/td[2]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[3]/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[3]/td[2]/input")).click();
            }
        }
        // Check for AutomaticTaxCalculation
        if (sGLAutomationTaxCalculation == null)
        {
            if (driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[5]/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[5]/td[2]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[5]/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[5]/td[2]/input")).click();
            }
        }
        // Check for Enable Address Validation
        if (sGLEnableAddressValidation == null)
        {
            if (driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[9]/table/tbody/tr[2]/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[9]/table/tbody/tr[2]/td[2]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[9]/table/tbody/tr[2]/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[9]/table/tbody/tr[2]/td[2]/input")).click();
            }
        }
        // Check for Verify Validated Addresses
        if (sGLVerifyValidatedAddress == null)
        {
            if (driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[9]/table/tbody/tr[3]/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[9]/table/tbody/tr[3]/td[2]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[9]/table/tbody/tr[3]/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[9]/table/tbody/tr[3]/td[2]/input")).click();
            }
        }
        // Check for Use Billing Address for Tax Calc
        if (sGLEnableBillingAddress == null)
        {
            if (driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[9]/table/tbody/tr/td[4]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[9]/table/tbody/tr/td[4]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[9]/table/tbody/tr/td[4]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[9]/table/tbody/tr/td[4]/input")).click();
            }
        }

        // Check for Entity/Use code for Tax Calc
        if (sGLEnableEntityUseCode == null)
        {
            if (driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[2]/td[4]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[2]/td[4]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[2]/td[4]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[2]/td[4]/input")).click();
            }
        }



        // Check for Tax Code for Tax Calc
        if (sGLEnableTaxCode == null)
        {
            if (driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[6]/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[6]/td[2]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[6]/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[6]/td[2]/input")).click();
            }
        }



        // Check for Shipping Tax Code for Tax Calc
        if (sGLShippingTaxCode != null)
        {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[4]/td[4]/span/input")).clear();
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[4]/td[4]/span/input")).sendKeys(sGLShippingTaxCode);
        }
        else
        {
            driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[4]/td[4]/span/input")).clear();
            driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[4]/td[4]/span/input")).sendKeys("");
        }


        // Check for Tax Override
        if (sGLTaxOverRide == null )
        {
            if (driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[3]/td[4]/input")).isSelected() )

            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[3]/td[4]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[3]/td[4]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[3]/td[4]/input")).click();
            }
        }

        // Check for UPC code
        if (sGLEnableUPCcode == null )
        {
            if (driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[6]/td[4]/input")).isSelected() )

            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[6]/td[4]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[6]/td[4]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[11]/table/tbody/tr[6]/td[4]/input")).click();
            }
        }

        // Click on Save Button
        driver.findElement(By.name("save")).click();
        ExecutionDelay (10);
       // driver.manage().timeouts().implicitlyWait(lGL_MAX_WAIT_TIME_IN_Seconds, TimeUnit.SECONDS);
        if(IsElementPresent(By.name("edit")))
        {
            fLogMessage(1,sGLTestCaseName,"Avalara Configuration settings updated successfully");
            return true;
        }
        else
        {
            fLogMessage(0,sGLTestCaseName,"Avalara Configuration settings NOT updated successfully");
            return false;
        }
    }
    // End TaxNow setting function

    /*******************************************************************************************************************
     * Calculate Sales Tax function
     * Function for Calculate Sales Tax for Automation data sheet test cases
     ******************************************************************************************************************/
    public boolean fCalculateSalesTax(String sUniqueID)
    {
        String sQuery;
        int iTemp,iRecordSetCount;
        boolean bResult;

        try
        {
            fLogMessage(1,sGLTestCaseName,"Tax Calculation for Test case: " + sUniqueID + " Started.");
            // Creating Connection  with excel sheet
            // For Excel // sQuery = "Select * From [AutomationTaxCalculation$] where  UniqueID = '" + sUniqueID + "'";
            sQuery =  "SELECT * FROM AutomationTaxCalculation where UniqueID='"+sUniqueID+"'";
            oResultSet = fGetRecordSet(sGLDataPoolTaxFilePath, sQuery);
            if (oResultSet == null)
                fLogMessage(0,sGLTestCaseName,"Unable to connect to excel sheet");
            //Move to last item in record set to get the record
            oResultSet.last();
            iRecordSetCount = oResultSet.getRow();
            oResultSet.first();

            // Get Flag value from Data sheet  to set in Tax now settings
            sGLEnableBillingAddress = oResultSet.getString("EnableBillingAddressFlag");
            sGLEnableTaxCalculation = oResultSet.getString("EnableTaxCalculationFlag");
            sGLEnableUnCommitts = oResultSet.getString("EnableUnCommittedInvoicesFlag");
            sGLEnableCommittedInvoices = oResultSet.getString("EnableCommittedInvoicesFlag");
           // sGLAutomationTaxCalculation = oResultSet.getString("AutomationTaxCalculationFlag");
            sGLEnableAddressValidation = oResultSet.getString("EnableAddressValidationFlag");
            sGLVerifyValidatedAddress = oResultSet.getString("VerifyValidatedAddressFlag");
            sGLShippingHandlingTax  = oResultSet.getString("ShippingHandlingTax");
            sGLShippingHandling    = oResultSet.getString("ShippingHandling");
            sGLEntityUseCode       = oResultSet.getString("Entity/UseCOde");
            sGLErrorMessageDisplayed       = oResultSet.getString("ErrorMessageStatus");
            sGLShiptoAddress_Line1 = oResultSet.getString("ShiptoAddress_Line1");
            sGLShiptoAddress_City = oResultSet.getString("ShiptoAddress_City");
            sGLShiptoAddress_State = oResultSet.getString("ShiptoAddress_State");
            sGLShiptoAddress_Zip = oResultSet.getString("ShiptoAddress_Zip");
            sGLShipToCountryCode = oResultSet.getString("ShiptoAddress_Country");
            sGLCountryPickList    = oResultSet.getString("CountryPickList");
            sGLEnableEntityUseCode = oResultSet.getString("EnableEntity/USeCode");
            sGLEnableTaxCode = oResultSet.getString("EnableTaxCodeMapping");
            sGLShippingTaxCode = oResultSet.getString("ShippigHandlingCode");
            // Go to Menu Selection and choose TaxNowSettings option for Flag setting
            bResult = fMenuSelection("TaxNowSettings");
            if (!bResult)
                return false;
            //Change Tax now settings depending on Flags retrieved from Excel file
            bResult = fTaxNowSettingsOption();
            if (!bResult)
                return false;
            // Enter Ship To address
            bResult = fMenuSelection("Accounts");
            if (!bResult)
                return false;
            // Sales Order

            /////////////""Orders""/////////////////////


            bResult = fMenuSelection("Orders");
            if (!bResult)
                return false;

            oResultSet.first();
            iGLIterationNumber = 0;
            for (iTemp = 0; iTemp < iRecordSetCount; iTemp++)
            {
                sGLAmount = oResultSet.getString("Amount");
                sGLProductType  = oResultSet.getString("TaxCodeMapping");
                //if (sGLProductType==null)
                    if (sGLProductType.equalsIgnoreCase("Null"))
                    sGLItem1Code =    "GenWatt Diesel 1000kW";
                else
                {
                    if (sGLProductType.equalsIgnoreCase("1"))
                        sGLItem1Code = sGLItem2Code;
                    else if (sGLProductType.equalsIgnoreCase("2"))
                        sGLItem1Code = sGLItem3Code;
                }
                //Enter data in Line Tab
                bResult = fLine_Entry("Orders");
                if (!bResult)
                    return false;
                iGLIterationNumber = iGLIterationNumber + 1;
                oResultSet.next();
            }
            iGLIterationNumber = 0;
            oResultSet.first();
            // Calling CalculateOpportunitySalesTax function for trigger Get tax for Opportunity
            sGLTotalTax = oResultSet.getString("TotalTax");
            bResult = fVerifyStatusAndTaxOnWindow("Orders", 1);
            if (!bResult)
                return false;
            if (sGLEnableCommittedInvoices != null)
            {
                sGLTotalTax = oResultSet.getString("TotalTax");
                //  sGLAmountForMultipleLines       = oResultSet.getString("AmountForMultipleLines");
               // bResult = fVerifyStatusAndTaxOnWindow("Finalize Orders", 2);
              //  if (!bResult)
              //      return false;
            }

            ///////////////""Order""////////////////

            // Go to Menu selection function and select Opportunity option for transaction

            bResult = fMenuSelection("Opportunities");
            if (!bResult)
                return false;
            // Call Line_Entry function to Enter line items in transaction
            oResultSet.first();
            iGLIterationNumber = 0;
            for (iTemp = 0; iTemp < iRecordSetCount; iTemp++)
            {
                sGLAmount = oResultSet.getString("Amount");
                sGLProductType  = oResultSet.getString("TaxCodeMapping");
                if (sGLProductType==null)
                    sGLItem1Code =    "GenWatt Diesel 1000kW";
                else
                {
                    if (sGLProductType.equalsIgnoreCase("1"))
                        sGLItem1Code = sGLItem2Code;
                    else if (sGLProductType.equalsIgnoreCase("2"))
                        sGLItem1Code = sGLItem3Code;
                }
                //Enter data in Line Tab
                bResult = fLine_Entry("Opportunities");
                if (!bResult)
                    return false;
                iGLIterationNumber = iGLIterationNumber + 1;
                oResultSet.next();
            }
            iGLIterationNumber = 0;
            oResultSet.first();
            // Calling CalculateOpportunitySalesTax function for trigger Get tax for Opportunity
            sGLTotalTax = oResultSet.getString("TotalTax");
           // sGLAmountForMultipleLines       = oResultSet.getString("AmountForMultipleLines");
            bResult = fVerifyStatusAndTaxOnWindow("Opportunities", 1);
            if (!bResult)
                return false;
            if (sGLEnableCommittedInvoices != null)
            {
                sGLTotalTax = oResultSet.getString("TotalTax");
              //  sGLAmountForMultipleLines       = oResultSet.getString("AmountForMultipleLines");
            bResult = fVerifyStatusAndTaxOnWindow("Finalize Opportunity", 2);
            if (!bResult)
                return false;
            }

            // End fCalculateSalesTax
            /*******************************************************************************************************************
             // Start- Transaction  for Quotes
             *******************************************************************************************************************/

            bResult = fMenuSelection("newQuote");
            if (!bResult)
                return false;

            // Call Line_Entry function Enter Quotes line value for transaction
            oResultSet.first();
            iGLIterationNumber = 0;
            for (iTemp = 0; iTemp < iRecordSetCount; iTemp++)
            {
                sGLAmount = oResultSet.getString("Amount");
                sGLProductType  = oResultSet.getString("TaxCodeMapping");
                if (sGLProductType==null)
                    sGLItem1Code =    "GenWatt Diesel 1000kW";
                else
                {
                    if (sGLProductType.equalsIgnoreCase("1"))
                        sGLItem1Code = sGLItem2Code;
                    else if (sGLProductType.equalsIgnoreCase("2"))
                        sGLItem1Code = sGLItem3Code;
                }

                //Enter data in Line Tab
                bResult = fLine_Entry("Quotes");
                if (!bResult)
                    return false;
                iGLIterationNumber = iGLIterationNumber + 1;
                oResultSet.next();
            }
            iGLIterationNumber = 0;
            oResultSet.first();
            // call fTotalSalesTax function for trigger Get tax for Quotes
            oResultSet.first();
            sGLTotalTax = oResultSet.getString("TotalTax");
          //  sGLAmountForMultipleLines       = oResultSet.getString("AmountForMultipleLines");
            bResult = fVerifyStatusAndTaxOnWindow("Quotes", 1);
            if (!bResult)
                return false;
            if (sGLEnableCommittedInvoices != null)
            {
                sGLTotalTax = oResultSet.getString("TotalTax");
           //     sGLAmountForMultipleLines       = oResultSet.getString("AmountForMultipleLines");
            bResult = fVerifyStatusAndTaxOnWindow("Finalize Quote", 2);
            if (!bResult)
                return false;
            }


            fLogMessage(1,sGLTestCaseName,"Tax Calculation for Test case: " + sUniqueID + " Ended.");

        }


        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fCalculateSalesTax: Exception: " + oException.toString());
        }
        return true;
    }


 /*******************************************************************************************************************
     * Line Entry Function
     * Description   : Function for Add a product for transaction
     * @param sItemSelection : - Which window we are going to add line item
     ******************************************************************************************************************/
    boolean fLine_Entry(String sItemSelection) throws Exception {
        String sOnscreenAvalaraStatus;
        String sStatusID ="";

        // Order
        if(sItemSelection.equalsIgnoreCase("Orders"))
        {
            sStatusID = "//tr[3]/td[4]/div";
            driver.findElement(By.name("addProd")).click();
            ExecutionDelay (12);
           // this.WaitForPageLoad();
           // driver.findElement(By.name("save")).click();
            driver.findElement(By.name("save")).click();
            ExecutionDelay (6);
            driver.findElement(By.id("search")).clear();
            driver.findElement(By.id("search")).sendKeys(sGLItem1Code);
            driver.findElement(By.id("save_filter_PricebookEntry")).click();
            this.WaitForPageLoad();
            ExecutionDelay (5);
           // driver.findElement(By.name("save")).click();
           // ExecutionDelay (6);
            driver.findElement(By.id("allBox")).click();
            ExecutionDelay (8);
            this.WaitForPageLoad();
            driver.findElement(By.name("edit")).click();

            driver.findElement(By.xpath("//tr[5]/td/input")).click();
            driver.findElement(By.xpath("//tr[5]/td/input")).clear();
            driver.findElement(By.xpath("//tr[5]/td/input")).sendKeys(sGLAmount);
            driver.findElement(By.xpath("//td[2]/input")).clear();
            driver.findElement(By.xpath("//td[2]/input")).sendKeys("1");
           // driver.findElement(By.xpath("//tr[7]/td/input")).click(); // Save button

        }

        //Click on Add product if Opportunity or click on Add quote line depending item selection passed
        if(sItemSelection.equalsIgnoreCase("Opportunities"))
        {
            //Thread.sleep(2000);
            sStatusID = "//tr[3]/td[4]/div";//R-> Third // Avalara Status

            driver.findElement(By.name("addProd")).click();
            ExecutionDelay (10);
            driver.findElement(By.name("save")).click();
            //driver.manage().timeouts().implicitlyWait(lGL_MAX_WAIT_TIME_IN_Seconds, TimeUnit.SECONDS);
            // Add Product from product page
            driver.findElement(By.id("search")).clear();
            driver.findElement(By.id("search")).sendKeys(sGLItem1Code);
            driver.findElement(By.id("save_filter_PricebookEntry")).click();
            // driver.manage().timeouts().implicitlyWait(lGL_MAX_WAIT_TIME_IN_Seconds, TimeUnit.SECONDS);
            this.WaitForPageLoad();
            //Thread.sleep(1000);
            ExecutionDelay (8);
            driver.findElement(By.id("allBox")).click();
            ExecutionDelay (10);
            this.WaitForPageLoad();
            driver.findElement(By.name("edit")).click();
            driver.findElement(By.xpath("//form[@id='editPage']/table/tbody/tr[5]/td/input")).clear();
            driver.findElement(By.xpath("//form[@id='editPage']/table/tbody/tr[5]/td/input")).sendKeys("1");
            driver.findElement(By.xpath("//form[@id='editPage']/table/tbody/tr[5]/td[2]/input")).clear();
            driver.findElement(By.xpath("//form[@id='editPage']/table/tbody/tr[5]/td[2]/input")).sendKeys(sGLAmount);

        }
        if(sItemSelection.equalsIgnoreCase("Quotes"))
        {
            sStatusID = "//tr[3]/td[4]/div";////R-> Third // Avalara Status
            driver.findElement(By.name("addQuoteLine")).click();

            ExecutionDelay (10);
      //  driver.manage().timeouts().implicitlyWait(lGL_MAX_WAIT_TIME_IN_Seconds, TimeUnit.SECONDS);
        // Add Product from product page
           // driver.findElement(By.name("save")).click();
        driver.findElement(By.id("search")).clear();
        driver.findElement(By.id("search")).sendKeys(sGLItem1Code);
        driver.findElement(By.id("save_filter_PricebookEntry")).click();
       // driver.manage().timeouts().implicitlyWait(lGL_MAX_WAIT_TIME_IN_Seconds, TimeUnit.SECONDS);
        this.WaitForPageLoad();
       // Thread.sleep(1000);
        ExecutionDelay (10);
        driver.findElement(By.id("allBox")).click();
        ExecutionDelay (8);
        this.WaitForPageLoad();
        driver.findElement(By.name("edit")).click();
        driver.findElement(By.xpath("//form[@id='editPage']/table/tbody/tr[5]/td[2]/input")).clear();
        driver.findElement(By.xpath("//form[@id='editPage']/table/tbody/tr[5]/td[2]/input")).sendKeys(sGLAmount);
        driver.findElement(By.xpath("//form[@id='editPage']/table/tbody/tr[5]/td[3]/input")).clear();
        driver.findElement(By.xpath("//form[@id='editPage']/table/tbody/tr[5]/td[3]/input")).sendKeys("1");
        }
        driver.findElement(By.name("save")).click();
        //driver.manage().timeouts().implicitlyWait(lGL_MAX_WAIT_TIME_IN_Seconds, TimeUnit.SECONDS);
        ExecutionDelay (10);
        //Verify Avalara Status
        if(sItemSelection.equalsIgnoreCase("Orders"))
            return true;
        else
        {
        {
        if ( sGLAutomationTaxCalculation != null)
        {
            sGLAvalaraDocStatus = "Calculating...";

        }
        else
        {
            sGLAvalaraDocStatus = "Temporary";
        }
        }
        //Capture on screen status
        sOnscreenAvalaraStatus = driver.findElement((By.xpath(sStatusID))).getText();
        //Verify on screen status with the Expected status
        if (sOnscreenAvalaraStatus.equalsIgnoreCase(sGLAvalaraDocStatus))
        {
            fLogMessage(1,sGLTestCaseName,"Avalara Status '" + sGLAvalaraDocStatus + "' verified successfully on adding products for Test case " +
                    sGLTestCaseName + " On Menu item : - " + sItemSelection);
        //selenium.setSpeed("2000");
            return true;
        }
        else
        {
            fLogMessage(0,sGLTestCaseName,"Avalara Status '"+ sGLAvalaraDocStatus +"' NOT verified successfully on adding products for Test case " +
                    sGLTestCaseName + " On Menu item : - " + sItemSelection + "Expected : "+ sGLAvalaraDocStatus +" and Actual:"+ sOnscreenAvalaraStatus );
        //selenium.setSpeed("2000");
            return false;
        }
        }
    }
    //End of fLine_Entry

    /*******************************************************************************************************************
     * Description   : Function for Add a product for transaction
     * @param  sMenuOption = On which window we are verifying tax
     ******************************************************************************************************************/
    boolean fVerifyTaxValues(String sMenuOption) throws InterruptedException {
        String sMISCTax,  sErrorMessage;// sSalesTax1 ;
        String sSalesTax="";
        String  sExpectedSalesTax;
        String [] sTax;
        String [] sExpectedShippingHandlingTax ;
        //String  sTaxID;
        String sMiscTaxID = null;
      //  selenium.setSpeed("2000");
        if(sMenuOption.equalsIgnoreCase("Opportunities") || sMenuOption.equalsIgnoreCase("Finalize Opportunity"))
        {

            sMiscTaxID = "//tr[5]/td[4]/div";//Right->10;
            Thread.sleep(1000);

            sSalesTax = driver.findElement(By.xpath("//tr[7]/td[4]/div")).getText();    //td[4]Right-> 7
            Thread.sleep(1000);
        }
        else if (sMenuOption.equalsIgnoreCase("Quotes") || sMenuOption.equalsIgnoreCase("Finalize Quote")) //For Quotes
        {
            sMiscTaxID = "//tr[5]/td[4]/div";////div[4]/table/tbody/tr[2]/td[4]/div";
            Thread.sleep(1000);
            sSalesTax = driver.findElement(By.xpath("//tr[7]/td[4]/div")).getText();
            Thread.sleep(1000);
            double d = Double.parseDouble(sGLTotalTax);
            d = d * 2;
            d =Double.parseDouble(new DecimalFormat("##.##").format(d));
            sGLTotalTax = String.valueOf(d) ;
            sGLTotalTax = sGLTotalTax+"0" ;
        }
        if(sMenuOption.equalsIgnoreCase("Orders") || sMenuOption.equalsIgnoreCase("Finalize Orders"))
        {

            sMiscTaxID = "//tr[5]/td[4]/div";//Right->10;
            Thread.sleep(1000);

            sSalesTax = driver.findElement(By.xpath("//tr[7]/td[4]/div")).getText();    //td[4]Right-> 7
            Thread.sleep(1000);
        }
        //Check if Enable Tax calculation is false
        if (sGLEnableTaxCalculation == null)
        {     sGLAvalaraDocStatus = "Calculating...";
            //Capture Error message
            sErrorMessage = driver.findElement(By.xpath("//form[@id='j_id0:j_id1:j_id2']/h1")).getText();
            sErrorMessage = sErrorMessage.replaceAll("\\n"," ");
            //Click on Ok button
            driver.findElement(By.name("j_id0:j_id1:j_id2:j_id14")).click();
            ExecutionDelay (10);
            fLogMessage(1,sGLTestCaseName,"Error message appeared as " + sErrorMessage );
        }
        else
        {
            sTax = sSalesTax.split("\\$");
            sExpectedSalesTax = sTax[1].replaceAll(",","");
        sGLTotalTax = sGLTotalTax.trim();

        if (sExpectedSalesTax.equalsIgnoreCase(sGLTotalTax))
            fLogMessage(1,sGLTestCaseName,"'Total Sales Tax' " + sGLTotalTax + " verified successfully for Test case " +sGLTestCaseName
                    + " on "  + sMenuOption + " Window.");
        else
        {
            fLogMessage(0,sGLTestCaseName,"'Total Sales Tax' " + sGLTotalTax + " NOT verified successfully for Test case" +sGLTestCaseName
                    + " on " + sMenuOption + " Window.Expected Tax :- " + sGLTotalTax + " and Actual Tax:- " + sExpectedSalesTax);
            return false;
        }
        }
        // Check for Shipping and Handling
        if (sGLShippingHandling != null)
        {
          //  sMISCTax = selenium.getText(sMiscTaxID);
            sMISCTax = driver.findElement(By.xpath(sMiscTaxID)).getText();
            sExpectedShippingHandlingTax = sMISCTax.split("\\$");
            sGLShippingHandlingTax  = sGLShippingHandlingTax .trim();
            if (sExpectedShippingHandlingTax[1].equalsIgnoreCase(sGLShippingHandlingTax))
            {
                fLogMessage(1,sGLTestCaseName,"'Misc Tax' " + sGLShippingHandlingTax + " verified successfully for Test case" +sGLTestCaseName
                        + " on " + sMenuOption + " Window.");
            }
            else
            {
                fLogMessage(0,sGLTestCaseName,"'Misc Tax' " + sGLShippingHandlingTax + " NOT verified successfully for Test case" +sGLTestCaseName
                        + " on " + sMenuOption + " Window.Expected Tax :- " + sGLShippingHandlingTax + " and Actual Tax:- " + sExpectedShippingHandlingTax[1]);
                return false;
            }
        }
        return true;
    }
    /*******************************************************************************************************************
     * Function for Avalara Status / Avalara AvaTax / Error Message Displayed
     * Description   : Function for Trigger Get Tax for Opportunity
     * @param sMenuOption = Perform Action on Opportunities or Quotes window
     * @param iClickOption = Click on Calculate push button or Finalize push button
     *******************************************************************************************************************/
    boolean fVerifyStatusAndTaxOnWindow(String sMenuOption , int iClickOption) throws InterruptedException {
        String sOnscreenAvalaraStatus;
        String sErrorMessage,sStatusID = null;
        String sCalculateOrFinalizeOption="";
        String sURL ="";
        String sURLID = "";
        boolean bResult;// = false;
        //Click on Calculate Sales Tax Button depending upon passed parameter
        if(sMenuOption.equalsIgnoreCase("Orders") || sMenuOption.equalsIgnoreCase("Finalize Orders"))
        {
            if (iClickOption == 1)
            {
                if(sGLAutomationTaxCalculation != null)
                {
                    ////tr[2]/td[4]/div
                    sURLID  = driver.findElement(By.xpath("tr[2]/td[4]/div")).getText();
                    sURL="https://na15.salesforce.com/" + "sURLID";
                    // Refreshing the Opportunity page
                    driver.get(sURL);
                    driver.navigate().refresh();
                }
                else
                    sCalculateOrFinalizeOption = "ava_sforders__calculate_sales_tax";
                if (sGLEnableTaxCalculation != null)
                {
                    sGLAvalaraDocStatus = "Temporary";
                }
                if (sGLEnableUnCommitts != null)
                {
                    sGLAvalaraDocStatus = "Saved";
                }
            }
            else
            {
                sCalculateOrFinalizeOption = "ava_sforders__finalize_order";
                if (sGLEnableCommittedInvoices != null)
                {
                    sGLAvalaraDocStatus = "Committed";
                }
            }
            //  driver.findElement(By.name(sCalculateOrFinalizeOption)).click();
            //  sStatusID = "//tr[3]/td[4]/div";
        }
        if(sMenuOption.equalsIgnoreCase("Opportunities") || sMenuOption.equalsIgnoreCase("Finalize Opportunity"))
        {
            if (iClickOption == 1)
            {
                if(sGLAutomationTaxCalculation != null)
                {
                    ////tr[2]/td[4]/div
                    sURLID  = driver.findElement(By.xpath("tr[2]/td[4]/div")).getText();
                    sURL="https://na15.salesforce.com/" + "sURLID";
                    // Refreshing the Opportunity page
                    driver.get(sURL);
                    driver.navigate().refresh();
                }
                else
                sCalculateOrFinalizeOption = "ava_sfcore__opp_calc_tax";
                if (sGLEnableUnCommitts != null)
                {
                            sGLAvalaraDocStatus = "Saved";
                }
            }
            else
            {
                sCalculateOrFinalizeOption = "ava_sfcore__finalize_opportunity";
            if (sGLEnableCommittedInvoices != null)
            {
                        sGLAvalaraDocStatus = "Committed";
            }
            }
          //  driver.findElement(By.name(sCalculateOrFinalizeOption)).click();
          //  sStatusID = "//tr[3]/td[4]/div";
        }
         if (sMenuOption.equalsIgnoreCase("Quotes") || sMenuOption.equalsIgnoreCase("Finalize Quote")) //For Quotes
        {
            if (iClickOption == 1)
            {
                if(sGLAutomationTaxCalculation != null)
                {
                    ////tr[2]/td[4]/div
                    sURLID  = driver.findElement(By.xpath("tr[2]/td[4]/div")).getText();
                    sURL="https://na15.salesforce.com/" + sURLID;
                    // Refreshing the Quotes page
                    driver.get(sURL);
                    driver.navigate().refresh();
                }
                else
                sCalculateOrFinalizeOption = "ava_sfquotes__calculate_sales_tax";
            if (sGLEnableUnCommitts != null)
            {
                    sGLAvalaraDocStatus = "Saved";
            }
        }
            else
            {
                sCalculateOrFinalizeOption = "ava_sfquotes__finalize_quote";
            if (sGLEnableCommittedInvoices != null)
            {

                    sGLAvalaraDocStatus = "Committed";
            }
        }
           // driver.findElement(By.name(sCalculateOrFinalizeOption)).click();
           // sStatusID = "//tr[3]/td[4]/div";
        }
        // Trigger Get tax and Finalize tax.

        driver.findElement(By.name(sCalculateOrFinalizeOption)).click();
        // Check if Error message displayed test cases

        if ( sGLErrorMessageDisplayed != null)
        {

            //Capture Error message
            if (IsElementPresent(By.xpath("//form[@id='j_id0:j_id1:j_id2']/h1")))
            {
            sErrorMessage = driver.findElement(By.xpath("//form[@id='j_id0:j_id1:j_id2']/h1")).getText();
            sErrorMessage = sErrorMessage.replaceAll("\\n"," ");
            //Click on Ok button
            driver.findElement(By.name("j_id0:j_id1:j_id2:j_id14")).click();
            driver.manage().timeouts().implicitlyWait(lGL_MAX_WAIT_TIME_IN_Seconds, TimeUnit.SECONDS);
            fLogMessage(1,sGLTestCaseName,"Error message appeared as " + sErrorMessage );
            }
            else
            {
                fLogMessage(0,sGLTestCaseName,"F:Error Message Test Cases verified not successfully");
                return false;
            }
        }

        else
        {
            sStatusID = "//tr[3]/td[4]/div";
            bResult = fVerifyTaxValues(sMenuOption);
            if (!bResult)
                return false;
            sOnscreenAvalaraStatus= driver.findElement(By.xpath(sStatusID)).getText();
            if (sOnscreenAvalaraStatus.equalsIgnoreCase(sGLAvalaraDocStatus))
                fLogMessage(1,sGLTestCaseName,"Avalara Status ' " + sGLAvalaraDocStatus + "' verified successfully on Calculate for Test case " +sGLTestCaseName
                        + " On tax calculation on " + sMenuOption + " Window ");
            else
            {
                fLogMessage(0,sGLTestCaseName,"Avalara Status ' " + sGLAvalaraDocStatus + " ' NOT verified successfully on Calculate for Test case " +sGLTestCaseName
                        + " On tax calculation for on " + sMenuOption + " Window " + "Expected : " + sGLAvalaraDocStatus + " and Actual: "+ sOnscreenAvalaraStatus);

                return false;
            }
        }
        return true;
    }
    //End of fCalculateOpportunitySalesTax

    /*******************************************************************************************************************
     // Function for Address validation for Automation data sheet test cases
     ********************************************************************************************************************/
    public boolean fAddressValidation(String sUniqueID)
    {
        String sQuery ;
        int iTemp,iRecordSetCount;
        boolean bResult;
        try {
            fLogMessage(1,sGLTestCaseName,"Address Validation for Test case: " + sUniqueID + " Started.");
            // Creating Connection with excel sheet
            // For Excel // sQuery = "Select * From [AutomationTaxCalculation$] where  UniqueID = '" + sUniqueID + "'";
            sQuery =  "SELECT * FROM AutomationTaxCalculation where UniqueID='"+sUniqueID+"'";
            oResultSet = fGetRecordSet(sGLDataPoolTaxFilePath, sQuery);
            if (oResultSet == null)
                fLogMessage(0,sGLTestCaseName,"Unable to connect to excel sheet");
            //Move to last item in record set to get the record
            oResultSet.last();
            iRecordSetCount = oResultSet.getRow();
            oResultSet.first();
            sGLShiptoAddress_Line1 = oResultSet.getString("ShiptoAddress_Line1");
            // sGLShiptoAddress_Line2 = oResultSet.getString("ShiptoAddress_Line2");
            sGLShiptoAddress_City = oResultSet.getString("ShiptoAddress_City");
            sGLShiptoAddress_State = oResultSet.getString("ShiptoAddress_State");
            sGLShiptoAddress_Zip = oResultSet.getString("ShiptoAddress_Zip");
            sGLShipToCountryCode = oResultSet.getString("ShiptoAddress_Country");
            sGLLineStatus   = oResultSet.getString("VerifyFinalAddress");
            sGLAddressValidationFlag = oResultSet.getString("AddressValidationStatus");
            sGLEnableAddressValidation = oResultSet.getString("EnableAddressValidationFlag");
            sGLVerifyValidatedAddress = oResultSet.getString("VerifyValidatedAddressFlag");
          //  sGLCountryPickList    = oResultSet.getString("CountryPickList");
            // Go to Menu Selection and choose TaxNowSettings option for Flag setting
            bResult = fMenuSelection("TaxNowSettings");
            if (!bResult)
                return false;
            bResult = fTaxNowSettingsOption();
            if (!bResult)
                return false;
               // Commented temporory
          /*  // Origin Address validation for TAX NOW setting
            bResult= fShipToAddressValidation("TaxNowSettings");
           if (!bResult)
               return false;*/

            // Address validation for CONTACTS
            bResult = fMenuSelection("Contacts");
            if (!bResult)
                return false;
                bResult= fShipToAddressValidation("Contacts");
            if (!bResult)
                return false;
            bResult= fBillToAddressValidation("Contacts");
            if (!bResult)
                return false;

            // Address validation for ACCOUNTS
            bResult = fMenuSelection("Accounts");
            if (!bResult)
                return false;
            bResult= fShipToAddressValidation("Accounts");
            if (!bResult)
                return false;
            bResult= fBillToAddressValidation("Accounts");
            if (!bResult)
                return false;



            bResult = fMenuSelection("Contracts");
            if (!bResult)
                return false;
           bResult= fShipToAddressValidation("Contracts");
            if (!bResult)
               return false;
            bResult= fBillToAddressValidation("Contracts");
            if (!bResult)
                return false;
            // Orders


            bResult = fMenuSelection("Orders");
            if (!bResult)
                return false;
            bResult= fShipToAddressValidation("Orders");
            if (!bResult)
                return false;
            bResult= fBillToAddressValidation("Orders");
            if (!bResult)
                return false;


            // Address validation for OPPORTUNITY
            bResult = fMenuSelection("Opportunities");
            if (!bResult)
                return false;
            bResult= fShipToAddressValidation("Opportunities");
            if (!bResult)
                return false;
            bResult= fBillToAddressValidation("Opportunities");
            if (!bResult)
                return false;
            /*
            // Address validation for OPPORTUNITY
            bResult = fMenuSelection("Opportunities");
            if (!bResult)
                return false;
            bResult= fShipToAddressValidation("Opportunities");
            if (!bResult)
                return false;
            bResult= fBillToAddressValidation("Opportunities");
            if (!bResult)
                return false;
            */



            // Address validation for QUOTES

            bResult = fMenuSelection("newQuote");
            if (!bResult)
                return false;
            bResult= fShipToAddressValidation("newQuote");
            if (!bResult)
                return false;
            bResult= fBillToAddressValidation("newQuote");
            if (!bResult)
                return false;


        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fAddressValidation: Exception: " + oException.toString());
        }
        return true;
    }
    //    End of fAddressValidation

    /*********************************************************************************************************************
     // Start -- Function for Ship To Address validation
     *********************************************************************************************************************/
    boolean fShipToAddressValidation(String sOption) throws Exception
    {    boolean bResult;
        if(sOption.equalsIgnoreCase("Contacts"))
            //   Trigger validate Validate mail  To address
            driver.findElement(By.name("ava_sfcore__validatemailto")).click();

          if(sOption.equalsIgnoreCase("Accounts"))
            //   Trigger validate Ship To address
            driver.findElement(By.name("ava_sfcore__validate_shipping_address")).click();

               if(sOption.equalsIgnoreCase("Opportunities"))
            //   Trigger validate Ship To address
            driver.findElement(By.name("ava_sfcore__oppvalshipto")).click();
        // Check Condition for New Quotes
        if(sOption.equalsIgnoreCase("newQuote"))
        //   Trigger validate Ship To address
        driver.findElement(By.name("ava_sfquotes__validate_shipto")).click();
        //  Check condition for TaxNow setting
        if(sOption.equalsIgnoreCase("TaxNowSettings"))
        driver.findElement(By.name("ava_sfcore__validate_origin_address")).click();
        // Contracts-
        if(sOption.equalsIgnoreCase("Contracts"))
            //   Trigger validate Validate mail  To address
        driver.findElement(By.name("ava_sforders__validate_shipping_address")).click();
        // Orders

        if(sOption.equalsIgnoreCase("Orders"))
            //   Trigger validate Validate mail  To address
        driver.findElement(By.name("ava_sforders__ordervalshipto")).click();
        //   Calling function for verifying the validated address
        bResult  = fVerifyValidatedAddress(sOption);
        if(!bResult)
            return false;

        if(sOption.equalsIgnoreCase("Opportunities") || sOption.equalsIgnoreCase("Contracts")|| sOption.equalsIgnoreCase("Orders"))
        {
                if (IsElementPresent(By.name("j_id0:j_id1:j_id3:j_id27")))
            {      ExecutionDelay (5);
                driver.findElement(By.name("j_id0:j_id1:j_id3:j_id27")).click();
                fLogMessage(1,sGLTestCaseName,"Address validation saved successfully");
            }
            else if   (IsElementPresent(By.name("j_id0:j_id1:j_id2:j_id14")))
            {      ExecutionDelay (5);
                driver.findElement(By.name("j_id0:j_id1:j_id2:j_id14")).click();
                fLogMessage(1,sGLTestCaseName,"Address validation saved successfully");
            }
            else
                fLogMessage(0,sGLTestCaseName,"Address validation not saved successfully");
        }
        else
        {      if(IsElementPresent(By.name("j_id0:j_id1:j_id2:j_id26")))
        {         ExecutionDelay (10);
            driver.findElement(By.name("j_id0:j_id1:j_id2:j_id26")).click();
            fLogMessage(1,sGLTestCaseName,"Address validation saved successfully");
        }
        else if  (IsElementPresent(By.name("j_id0:j_id1:j_id2:j_id14")))
        {       ExecutionDelay (10);
            driver.findElement(By.name("j_id0:j_id1:j_id2:j_id14")).click();
            fLogMessage(1,sGLTestCaseName,"Address validation saved successfully");
        }
        else
            fLogMessage(0,sGLTestCaseName,"Address validation not saved successfully");
        }
        return true;
    }
    // End of  fShipToAddressValidation
    /*********************************************************************************************************************
     // Start -- Function for Bill To Address validation
     *********************************************************************************************************************/
    boolean fBillToAddressValidation(String sOption) throws Exception
    {     boolean bResult;
        if(sOption.equalsIgnoreCase("Contacts"))
        {
            // Trigger validate billing address
            driver.findElement(By.name("ava_sfcore__contactvalidateother")).click();
        }
        else if(sOption.equalsIgnoreCase("Accounts"))
        {
            // Trigger validate billing address
            driver.findElement(By.name("ava_sfcore__validate_billing_address")).click();
        }
        else  if(sOption.equalsIgnoreCase("Opportunities"))
        {
            // Trigger validate billing address
            driver.findElement(By.name("ava_sfcore__oppvalbillto")).click();
        }

        //   Quotes window
        if(sOption.equalsIgnoreCase("newQuote"))
            // Trigger validate Bill To address
        driver.findElement(By.name("ava_sfquotes__validate_billto")).click();
        if(sOption.equalsIgnoreCase("Contracts"))
        {
            // Trigger validate billing address
            driver.findElement(By.name("ava_sforders__validate_billing_address")).click();
        }
        if(sOption.equalsIgnoreCase("Orders"))
        {
            // Trigger validate billing address
            driver.findElement(By.name("ava_sforders__validate_billing_address")).click();
        }
        this.WaitForPageLoad();
        // Calling function for verifying the validated address
        bResult  = fVerifyValidatedAddress(sOption);
        if(!bResult)
            return false;
        // Below code for click on verified address
        if(sOption.equalsIgnoreCase("Opportunities")|| sOption.equalsIgnoreCase("Contracts")|| sOption.equalsIgnoreCase("Orders"))
        {
            if  (IsElementPresent(By.name("j_id0:j_id1:j_id3:j_id27")))
            {
                ExecutionDelay (5);
                driver.findElement(By.name("j_id0:j_id1:j_id3:j_id27")).click();
            }
            else if  (IsElementPresent(By.name("j_id0:j_id1:j_id2:j_id14")))
            {
                ExecutionDelay (5);

                driver.findElement(By.name("j_id0:j_id1:j_id2:j_id14")).click();
            }
                fLogMessage(1,sGLTestCaseName,"Address validation saved successfully");
        }
        else
        {
            if(IsElementPresent(By.name("j_id0:j_id1:j_id2:j_id26")))
        {    ExecutionDelay (5);
            driver.findElement(By.name("j_id0:j_id1:j_id2:j_id26")).click();
            fLogMessage(1,sGLTestCaseName,"Address validation saved successfully");
        }
        else if  (IsElementPresent(By.name("j_id0:j_id1:j_id2:j_id14")))
        {              ExecutionDelay (5);
            driver.findElement(By.name("j_id0:j_id1:j_id2:j_id14")).click();
            fLogMessage(1,sGLTestCaseName,"Address validation saved successfully");
        }
        else
            fLogMessage(0,sGLTestCaseName,"Address validation not saved successfully");
        }
        ExecutionDelay (10);
        return true;
    }
    // End of fBillToAddressValidation
    /*******************************************************************************************************************
     * Verify Validated Address function
     * Description   : Function for Add a product for transaction
     * @param  sOption = On which window we are verifying tax
     ******************************************************************************************************************/
    boolean fVerifyValidatedAddress(String sOption) throws Exception {
        String sOnScreenValidateAddress;
        String sOnScreenLine1;
        String sOnScreenCity_State_Zip;
        String sOnScreenCountry;
        // Address validation for valid address

        if(((sOption.equalsIgnoreCase("TaxNowSettings"))||sOption.equalsIgnoreCase("newQuote"))||(sOption.equalsIgnoreCase("Accounts"))||(sOption.equalsIgnoreCase("Contacts")) )
        {
        if(IsElementPresent(By.xpath("//form[@id='j_id0:j_id1:j_id2']/table/tbody/tr/th[4]/h1")))
        {   ExecutionDelay (10);
            sOnScreenLine1 = driver.findElement(By.xpath("//form[@id='j_id0:j_id1:j_id2']/table/tbody/tr[2]/td[5]")).getText();
            sOnScreenCity_State_Zip = driver.findElement(By.xpath("//form[@id='j_id0:j_id1:j_id2']/table/tbody/tr[5]/td[5]")).getText();
            sOnScreenCountry = driver.findElement(By.xpath("//form[@id='j_id0:j_id1:j_id2']/table/tbody/tr[6]/td[5]")).getText();
            sOnScreenValidateAddress =  sOnScreenLine1+ ", "+sOnScreenCity_State_Zip+", "+sOnScreenCountry;
            if (sOnScreenValidateAddress.equalsIgnoreCase(sGLLineStatus))
                fLogMessage(1,sGLTestCaseName,"Avalara Address Validation Test Case" + "' verified successfully for " +sGLTestCaseName
                        + sOption + " Window ");
            else
            {
                fLogMessage(0,sGLTestCaseName,"Avalara Address Validation Test Case ' "  + " ' NOT verified successfully  for " +sGLTestCaseName
                        + sOption + " Window " + "Expected : " + " and Actual: "+ sOnScreenValidateAddress);
                return false;
            }
        }
        // Address validation for disable address / Invalid address
        else
        {
            if(IsElementPresent(By.xpath("//form[@id='j_id0:j_id1:j_id2']/h1")))
            {   ExecutionDelay (10);
            fLogMessage(1,sGLTestCaseName,"Address validation verified successfully");
            // sOnScreenValidateAddress = selenium.getText("//div[@id='j_id0:j_id1']/div/table/tbody/tr/td/h2");
            // fLogMessage(1,sGLTestCaseName,sOnScreenValidateAddress);
            }
        }
        }

        else if(sOption.equalsIgnoreCase("Opportunities") || sOption.equalsIgnoreCase("Orders") ||sOption.equalsIgnoreCase("Contracts"))
        {
            if(IsElementPresent(By.xpath("//form[@id='j_id0:j_id1:j_id3']/table/tbody/tr/th[4]/h1")))
            {    ExecutionDelay (10);

                sOnScreenLine1 = driver.findElement(By.xpath("//form[@id='j_id0:j_id1:j_id3']/table/tbody/tr[2]/td[5]")).getText();
                sOnScreenCity_State_Zip = driver.findElement(By.xpath("//form[@id='j_id0:j_id1:j_id3']/table/tbody/tr[5]/td[5]")).getText();
                sOnScreenCountry = driver.findElement(By.xpath("//form[@id='j_id0:j_id1:j_id3']/table/tbody/tr[6]/td[5]")).getText();
                sOnScreenValidateAddress =  sOnScreenLine1+ ", "+sOnScreenCity_State_Zip+", "+sOnScreenCountry;
                if (sOnScreenValidateAddress.equalsIgnoreCase(sGLLineStatus))
                    fLogMessage(1,sGLTestCaseName,"Avalara Address Validation Test Case" + "' verified successfully for " +sGLTestCaseName
                            + sOption + " Window ");
                else
                {
                    fLogMessage(0,sGLTestCaseName,"Avalara Address Validation Test Case ' "  + " ' NOT verified successfully  for " +sGLTestCaseName
                            + sOption + " Window " + "Expected : " + " and Actual: "+ sOnScreenValidateAddress);
                    return false;
                }
            }
            // Address validation for disable address / Invalid address
            else if(IsElementPresent(By.xpath("//form[@id='j_id0:j_id1:j_id3']/h1")))
            {      ExecutionDelay (10);
                fLogMessage(1,sGLTestCaseName,"Address validation verified successfully");
                // sOnScreenValidateAddress = selenium.getText("//div[@id='j_id0:j_id1']/div/table/tbody/tr/td/h2");
                // fLogMessage(1,sGLTestCaseName,sOnScreenValidateAddress);
            }
        }

        else
        {
            fLogMessage(0,sGLTestCaseName,"F: Address not validated successfully");
            return false;
        }
        return true;
    }

   /*

    public boolean IisElementPresent(By sElementLocatorDesc)
    {
        if(driver.findElements(sElementLocatorDesc).size() > 0)
        {
            return true;
        }
        else
        {
            return false;
        }

    }

    public boolean IesElementPresent(By xpath)
    {
        if(driver.findElements(xpath).size() > 0)
        {
            return true;
        }
        else
        {
            return false;
        }

    }
    public boolean IasElementPresent(By linkText)
    {
        if(driver.findElements(linkText).size() > 0)
        {
            return true;
        }
        else
        {
            return false;
        }

    }
    */
    public boolean IsElementPresent(By by)
    {
        return driver.findElements(by).size() > 0;

    }

  /*
    public boolean IsElementPresent(By by)
    {
        if(driver.findElements(by).size() > 0)
        {
            return true;
        }
        else

            return false;

    }
   */

    //////////////////////////// Create products  ///////////////////////////////
    public boolean fCreateProducts()
    {      int iCount =10000;
        boolean bResult;
        try
        {
            for ( int iTemp = 1041; iTemp <= iCount; iTemp++)
            {
                // sGLTestCaseName = "TestCase" + iTemp;

                driver.findElement(By.linkText("Products")).click();
                Thread.sleep(2000);

                driver.findElement(By.name("new")).click();
                Thread.sleep(2200);
                driver.findElement(By.id("Name")).clear();
                driver.findElement(By.id("Name")).sendKeys("Test"+iTemp);
                driver.findElement(By.id("ProductCode")).clear();
                driver.findElement(By.id("ProductCode")).sendKeys("Test"+iTemp);
                driver.findElement(By.id("IsActive")).click();
                driver.findElement(By.xpath("//form/div/div[3]/table/tbody/tr/td[2]/input")).click();
                Thread.sleep(2000);
                driver.findElement(By.name("add")).click();
                Thread.sleep(1000);
                driver.findElement(By.id("td0_2")).clear();
                driver.findElement(By.id("td0_2")).sendKeys("1000");
                driver.findElement(By.name("save")).click();
                Thread.sleep(2000);
                driver.findElement(By.name("add")).click();
                Thread.sleep(2000);
                driver.findElement(By.id("ids0")).click();
                driver.findElement(By.xpath("//div[3]/input")).click();
                Thread.sleep(1000);
                driver.findElement(By.id("td0_8")).clear();
                driver.findElement(By.id("td0_8")).sendKeys("1000");
                driver.findElement(By.name("save")).click();
                Thread.sleep(2000);

            }

            return true;
        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, "Products Creation failed " + oException.toString());
            return false;
        }
    }
    ///////////////////////////////////End fCreateProducts ///////////////////////////////////////////////////











}
    // End of fVerifyValidatedAddress




