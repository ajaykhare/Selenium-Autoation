package GLOBALLIBRARY;

/**
 * Description   : Super class for script helper
 *
 * @author Sandeep Bangad
 * @since  June 5, 2012
 */
import java.awt.Color;
import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class Config
{

    // All Related Variable and Constants
    // **********************************************************
    //protected static String sGLApplicationURL = "https://login.salesforce.com/?locale=in";
    /////////////// FIREOFX////////////
   // protected static String sGLBrowser = "*firefox C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe"; // iexplore  firefox

      // Firefox profile path //   For security token, we need to login first on new browser, Create the new profile and update the path

   /* ProfilesIni profile = new ProfilesIni();
   // FirefoxProfile myprofile = new FirefoxProfile(new File("D:\\AjayProfie"));
    FirefoxProfile myprofile = profile.getProfile("Online");
    public WebDriver driver = new FirefoxDriver(myprofile);*/

    ////////////// FIREFOX ////////////
   // protected static String sGLLanguage = "EN";

   //////// CHROME /////////

  protected static String sGLBrowser =   System.setProperty("webdriver.chrome.driver", "D:\\Selenium RC Working\\chromedriver.exe");
    public  ChromeDriver driver = new ChromeDriver();
     ///////////

    //////////// INTERNET EXPLORER //////////

   // protected static String sGLBrowser=   System.setProperty("webdriver.ie.driver", "D:\\Selenium RC Working\\IEDriverServer_Win32_2.48.0\\IEDriverServer.exe");
   // public WebDriver driver = new InternetExplorerDriver();
    //////////////////////
   //public WebDriver driver = new FirefoxDriver();
  // protected static String sGLBrowser = "*firefox C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe"; // iexplore  firefox

    protected static String sGLLanguage = "EN";
    protected static final String sGL_MAX_WAIT_TIME_IN_MS = "60000";

    // **********************************************************
    // Project Location
    // TODO Change the path
    //public  static String sGLProjectLocation = System.getProperty("user.dir")+ "\\src";
    // Netsuite URL
    protected static String sGLApplicationURL = "https://www.google.com";
    protected static final long lGL_MAX_WAIT_TIME_IN_Seconds = 60;

   // Project name
   // protected static String sGLProjectName = "CSCART";
   // protected static String sGLProjectName ="AccountingSeed";
   // protected static String sGLProjectName ="OpenCart";
      protected static String sGLProjectName ="SALESFORCE";


    // Netsuite Login Credentials
 //   protected static String sGLSalesFoorceUserName = "ajay.khare@asf.com";
 //   protected static String sGLSalesForceUserPwd = "kennwort.20144";

   // public WebDriver driver = new FirefoxDriver();

   // public WebDriver driver = new InternetExplorerDriver();

    protected static String[] sGLRoleArray = { "", "Basic_Administrator","OneWorld_Administrator",
            "Basic_SalesPerson","Oneworld_SalesPerson", "Basic_Accountant","Oneworld_Accountant",
            "BetaBasic_Administrator","BetaBasic_SalesPerson","BetaBasic_Accountant",
            "BetaOneWorld_Administrator", "BetaOneworld_Accountant","BetaOneworld_SalesPerson"};


    public static int iGLRoleName = 10;
    // Generic Parameters
    // Test Case Name
    protected static String sGLTestCaseName = "";
    // Name of Root script
    protected static String sGLScriptName = "";
    // Name of Computer currently executing the scripts
    protected static String sGLMachineName = "";
    // Screen shot paramaeter
    protected static int iGLSCREENSHOTFLAG = 0;

    //protected static String sGLProjectLocation = "D:\\WebDriver_NetSuiteProject\\src";

    public  static String sGLProjectLocation = System.getProperty("user.dir")+ "\\src";

    //Path of Different Files used
    // Path of the result folder
    protected static String sGLCustomeLogFolderPath = sGLProjectLocation + "\\CUSTOMLOGS\\";
    // Path of the TestCases folder
    protected static String sGLTestCaseFolderPath = sGLProjectLocation + "\\TESTCASES\\";
    // Path of the TestPass folder
    protected static String sGLTestPassFolderPath = sGLProjectLocation + "\\TESTPASS\\";
    // UserData Path
    protected static String sGLUserDataPath = sGLProjectLocation + "\\USERDATA\\";

    // TestCases sheet name
    protected static String sGLTestCaseSheetName = "TestCases_" + sGLProjectName + ".xls";
    // CSV sheet name
    protected static String sGLCSVSheetName = "TESTLOG-MC-" + sGLMachineName + ".csv";
    // Address Datapool file Name
    protected static String sGLDataPoolAddressFile = sGLProjectName	+ "_Datapool_AddressValidation.xls";
    // Tax Datapool file Name
  //  protected static String sGLDataPoolTaxFile = sGLProjectName	+ "_Datapool_TaxCalculation.xls";
    protected static String sGLDataPoolTaxFile = sGLProjectName	+ "_Datapool_TaxCalculation.accdb";

    // Path of the CSV file
    protected static String sGLCSVFilePath = sGLCustomeLogFolderPath + sGLCSVSheetName;
    // Path of the Test Case file
    protected static String sGLTestCaseFilePath = sGLTestCaseFolderPath	+ sGLTestCaseSheetName;
    // Path of the Test Pass file
    protected static String sGLTestPassFilePath = sGLTestPassFolderPath	+ sGLTestCaseSheetName;
    // Path of the Address Data pool file
    protected static String sGLDataPoolAddressFilePath = sGLUserDataPath + sGLDataPoolAddressFile;
    // Path of the Tax Data pool file
    protected static String sGLDataPoolTaxFilePath = sGLUserDataPath + sGLDataPoolTaxFile;

    // ////////////////////////////////////////////////////////////
    // Database details
    // Connection
    protected static Connection oConnection = null;
    // Result Set
    protected static ResultSet oResultSet = null;
    // Statment
    protected static Statement oStatement = null;
    protected static String  sGlAvalaraStatus= null;
    protected static String sGLTaxCodeForMultipleLines =null;
    protected static String sGLAmountForMultipleLines = null;
    protected static String sGLTestConnectionFlag  = null;
    protected static String sGLTaxOverRide  = null;
    protected static String sGLEnableUPCcode  = null;
    protected static String sGLEnableVAT  = null;
    protected static String sGLReturnAddressInUpperCase  = null;

    // Date Format
    protected static String sGLDate = "8/2/2018";

    //ERP Details Variables
    // calculate tax
    protected static int iGLCalculateTax = 0; // 0 means nothing; 1 means dont
    protected static int iGLEnterShiptoAddressontheFly = 1; // 0 means Select
    // Ship to addres
    // from drop down; 1
    // means Enter
    // address Run time
    protected static int iGLMSR = 0; // 0 means NO MSR ; 1 means MSR and enter


    //Open Cart
    protected static String sGLHistoryCommitFlag = null;
    protected static String sGLreturnOrderFlag = null;
    protected static String sGLTestCasesIteration = null;
    protected static String sGLRecheckTaxCalculation = null;
    protected static String sGLDisableTaxCalc = null;
    protected static String sGLRMA   = null;
    protected static String sGLEnableShippingCharges = null;
    protected static String sGLEnableSalesOrder = null;
    protected static String sGLItemCode = null;
    protected static String  sGLEnableActiveTavTaxSetting= null;













    // ERP details
    protected static String sGLInvoiceType = null;
    protected static String sGLShipFromAddress_Line1 = null;
    protected static String sGLShipFromAddress_Line2 = null;
    protected static String sGLShipFromAddress_City = null;
    protected static String sGLShipFromAddress_State = null;
    protected static String sGLShipFromAddress_Zip = null;

    protected static String sGLShiptoAddress_Line1 = null;
    protected static String sGLShiptoAddress_Line2 = null;
    protected static String sGLShiptoAddress_City = null;
    protected static String sGLShiptoAddress_State = null;
    protected static String sGLShiptoAddress_Zip = null;
    protected static String sGLShipToAddressCode = null;

    protected static String sGLWareHouseCode = null;
    protected static String sGLCustomerType = null;
    protected static String sGLLineExemptNo = null;
    protected static String sGLOther = null;
    protected static String sGLAmount = null;
    protected static String sGLDiscountFlag = null;
    protected static String sGLTaxScheduleId = null;

    protected static String sGLCustExemptNo = null;
    protected static String sGLDiscount = null;
    protected static String sGLFreight = null;
    protected static String sGLHandling = null;
    protected static String sGLTotalTax = null;
    protected static String sGLItem2Code = null;
    protected static String sGLItem3Code = null;
    protected static String sGLLineStatus = null;
    protected static String[] sGLArrayWareHouseCode = new String[3];
    protected static int iGLIterationNumber = 0;

    protected static String sGLItem1Code = null;
    protected static String sGLCustomer = null;
    protected static String sGLInvoiceNumber = null;
    protected static String sGLProductType = null;
    protected static String sGLShippingItemMethod = "Pick-up";//"Pick-up"; // Canada UPS for
    // Canadian
    // subcidairy
    protected static boolean sGLShippingTabExistFlag = true; // In case of
    // Return
    // Authorization
    // Shipping tab
    // does NOT
    // appears.
    protected static String  sGLEnableBillingAddress= null;
    protected static String  sGLShippingHandlingTax= null;
    protected static String  sGLShippingHandling= null;
    protected static String  sGLCountryPickList   = null;
    protected static String  sGLEnableAddressValidation= null;
    protected static String  sGLVerifyValidatedAddress= null; //sGLAvalaraDocStatus
    protected static String  sGLAvalaraDocStatus= null;
    protected static String  sGLEntityUseCode= null;
    protected static String  sGLErrorMessageDisplayed= null;
    protected static String  sGLAddressValidationFlag= null;
    protected static String  sGLEnableTaxCalculation= null;
    protected static String  sGLEnableUnCommitts= null;
    protected static String  sGLEnableCommittedInvoices= null;
    protected static String  sGLAutomationTaxCalculation= null;
    protected static String sGLShipToCountryCode = null;
    protected static String  sGLEnableEntityUseCode= null;
    protected static String  sGLEnableTaxCode= null;
    protected static String  sGLShippingTaxCode= null;
    protected static String  sGLUPCCode= null;
    protected static String sGLSaveDoce_AvaAdmin   = null;
    private final static Color m_oBorderColor = new Color(255, 129, 53);

    protected static boolean sGLMemorizeTransactionFlag = false;
    protected static int iGLGiftItem = 0;
    protected static boolean bGLFirstTimeItemAdd = true;

    protected static boolean bGLTaxCodeAtLinelevel = false;
    protected static boolean bGLCanedianSubcidary = false;
    protected static int iGLColumnCount = -1;
    protected static int iGLRowCount = -1;


}
