package GLOBALLIBRARY;


import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.sql.*;
import java.text.*;
import java.util.*;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import javax.imageio.ImageIO;
import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.By;


/**
 * Description   : Super class for script helper
 *
 * @author Sandeep Bangad
 * @since  June 5, 2012
 */
public class GenericFunctions extends Config
{


/**************************************************************************************************/
    /** Global Functions

     /**************************************************************************************************/

/**************************************************************************************************/
    /**
     * Description   : Returns a connection to the Excel database.
     * @param sPath : Excel file path
     * @param sReadOnly: false for write access.
     * @return oConnection: Connection object in case of successful connection, null otherwise.
     */

    /////////////// Access/////////////////////
    /**************************************************************************************************/
    /**
     * Description   : Returns a connection to the Excel database.
     * @param sPath : Excel file path
     * @param sReadOnly: false for write access.
     * @return oConnection: Connection object in case of successful connection, null otherwise.
     */



    public Connection fGetExcelConnection(String sPath, String sReadOnly) throws Exception
    {
        try
        {

            ////////////For ACCESS////////////
           Connection oConnection;
            oConnection = DriverManager.getConnection(
                    "jdbc:ucanaccess://" + sPath);
            ////////END ACCESS //////////////////

            ///////// For EXCEl ////////////
           /* Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            String sConnStr =
                    "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ=" + sPath + ";"	+ "DriverID=22;READONLY=" + sReadOnly;
            Connection oConnection = DriverManager.getConnection(sConnStr,"","");
            */
            ////////// End EXCEL///////////
            return oConnection;
        }
        catch (Exception oEx)
        {
            System.out.println("Function fGetExcelConnection: " + oEx.toString());
            return oConnection;
        }
    } // End fGetExcelConnection



/**************************************************************************************************/
    /**
     * Description   : Function to kill instances of IE
     */
    public void fCloseBrowser()
    {
        try
        {
            driver.close();
            driver.quit();
        }
        catch(Exception e)
        {
            System.out.println(e.toString());
        }
    } // End fCloseIE



/**************************************************************************************************/
    /**
     * Description   : Returns Values of result set
     * @param oStatement : Conection Statement
     * @param sQuery : Query to execute
     */
    public String fGetValueFromResultSet(Statement oStatement, String sQuery) throws Exception
    {
        ResultSet oResultSet;
        oResultSet = oStatement.executeQuery(sQuery);
        oResultSet.next();
        String sValue = oResultSet.getString("Value");
        return sValue;
    } // End fGetValueFromResultSet



/**************************************************************************************************/
    /**
     * Description   : Expands array to new size
     * @param oArrayName : Array Object
     * @param iNewSize : Size to be expanded
     */
    public static String[] fExpandStringArray(Object oArrayName, int iNewSize)
    {
        Class cClass  = oArrayName.getClass();
        if (!cClass.isArray()) return null;
        Class cComponentType = oArrayName.getClass().getComponentType();
        oArrayName = Array.newInstance(cComponentType, iNewSize);
        return (String[])oArrayName;
    } // End fExpandStringArray



/**************************************************************************************************/
    /**
     * Description    : Function to add an element to existing array by increasing its size by 1
     * @param sArray  : The array to be added element to
     * @param sAppend : Tehe element to be appended
     * @return
     */
    public String[] fAppendArray(String [] sArray, String sAppend)
    {
        String [] sNewArray = new String[sArray.length + 1];
        System.arraycopy(sArray, 0, sNewArray, 0, sArray.length);
        sNewArray[sArray.length] = sAppend;
        return sNewArray;
    } // End fAppendArray



/**************************************************************************************************/
    /**
     * Description   : Function to convert between various date formats
     * 				  convert("2007-06-18 00:00:00.0", "yyyy-MM-dd hh:mm:ss.S",

     "MM/dd/yyyy");
     * 				  converts to 06/18/2007
     * @author Saber.Take
     * @param sDate : Date to format.
     * @param sFormatFrom : Input date format
     * @param sFormatTo : Output date format
     * @return boolean : String in expected date format
     */
    public String fConvertDate(String sDate, String sFormatFrom, String sFormatTo)
    {
        try
        {
            if( "now" == sDate )
            {
                return (new SimpleDateFormat(sFormatTo).format(new Date()));
            }
            else
            {
                return (new SimpleDateFormat(sFormatTo)).format((new

                        SimpleDateFormat(sFormatFrom)).parse(sDate, new ParsePosition(0)));
            }
        }
        catch( Exception oException )
        {
            System.out.println(oException.toString());
            return "";
        }
    } // End fConvertDate



/**************************************************************************************************/
    /**
     * Replace characters having special meaning in regular expressions
     * with their escaped equivalents.
     *
     * <P>The escaped characters include :
     *<ul>
     *<li>.
     *<li>\
     *<li>?, * , and +
     *<li>&
     *<li>:
     *<li>{ and }
     *<li>[ and ]
     *<li>( and )
     *<li>^ and $
     *</ul>
     *
     */
    public static String fMakeStringRegExpFree(String aRegexFragment)
    {
        final StringBuffer result = new StringBuffer();
        final StringCharacterIterator iterator = new StringCharacterIterator

                (aRegexFragment);
        char character =  iterator.current();
        while (character != CharacterIterator.DONE ){
			/*
			 * All literals need to have backslashes doubled.
			 */
            if (character == '.') {
                result.append("\\.");
            }
            else if (character == '\\') {
                result.append("\\\\");
            }
            else if (character == '?') {
                result.append("\\?");
            }
            else if (character == '*') {
                result.append("\\*");
            }
            else if (character == '+') {
                result.append("\\+");
            }
            else if (character == '&') {
                result.append("\\&");
            }
            else if (character == ':') {
                result.append("\\:");
            }
            else if (character == '{') {
                result.append("\\{");
            }
            else if (character == '}') {
                result.append("\\}");
            }
            else if (character == '[') {
                result.append("\\[");
            }
            else if (character == ']') {
                result.append("\\]");
            }
            else if (character == '(') {
                result.append("\\(");
            }
            else if (character == ')') {
                result.append("\\)");
            }
            else if (character == '^') {
                result.append("\\^");
            }
            else if (character == '$') {
                result.append("\\$");
            }
            else
            {
                //the char is not a special one, add it to the result as is
                result.append(character);
            }
            character = iterator.next();
        }
        return result.toString();
    }// End fMakeStringRegExpFree



/**************************************************************************************************/
    /**
     * Deletes all the directoried and files from Temporary Internet Files folder.
     */
    public void fDeleteTemporaryInternetFiles() throws Exception
    {
        try
        {
            String tmpFilePath = System.getProperty("java.io.tmpdir");


            File oTempDir = new File(tmpFilePath);
            String sLocalSettings = oTempDir.getParent();

            String sTempInternetDirPath = sLocalSettings + "\\Temporary Internet Files";
            File oTempInternetDir = new File(sTempInternetDirPath);
            fDeleteAllFiles(oTempInternetDir);
        }
        catch(IOException oException){}
    }// End fDeleteTemporaryInternetFiles



/**************************************************************************************************/
    /**
     * Deletes all the directories and files from Cookies.
     */
    public void fDeleteCookies() throws Exception
    {
        try
        {
            String tmpFilePath = System.getProperty("java.io.tmpdir");

            File oTempDir = new File(tmpFilePath);
            String sLocalSettings = oTempDir.getParent();
            File oLocalSettingsDir = new File(sLocalSettings);
            String sUserFolder = oLocalSettingsDir.getParent();

            String sCookies = sUserFolder + "\\Cookies";
            File oCookiesDir = new File(sCookies);
            fDeleteAllFiles(oCookiesDir);
        }
        catch(IOException oException){}
    }// End fDeleteCookies



/**************************************************************************************************/
    /**
     * Function takes directory path and delete all the directories and file in it.
     * @param path : Path of directory in which files need to be deleted.
     * @throws IOException: if unable to do not have permissions to perform file IO
     */
    public static void fDeleteAllFiles(File path) throws IOException
    {
        File[] files = path.listFiles();
        for(int i=0; i<files.length; ++i)
        {
            if(files[i].isDirectory())
            {
                fDeleteAllFiles(files[i]);
            }
            files[i].delete();
        }
    }// End fDeleteAllFiles



/**************************************************************************************************/
    /**
     * Read Text file into String variable.
     * @param f: file object to read.
     * @param encoding: Encoding type of file being read e.g. UTF-8
     * @return: File as String
     * @throws IOException: Exception while reading file.
     */
    public String fReadTextFile(File f, String encoding) throws Exception
    {
        //Reader r = new InputStreamReader(new FileInputStream(f), encoding);
        Reader r = new InputStreamReader(new FileInputStream(f));
        try
        {
            StringWriter w = new StringWriter();
            char[] buffer = new char[900000];
            int len;
            while ((len = r.read(buffer)) != -1)
            {
                w.write(buffer, 0, len);
            }
            return w.toString();
        }
        catch(Exception oException)
        {
            System.out.println(oException.toString());
            return null;
        }
        finally
        {
            r.close();
        }
    }// End fReadTextFile



/**************************************************************************************************/
    /**
     * Description : Case Insensitive equivalent of String.ReplaceAll
     * @param sStringToSearch : String to be searched
     * @param sOldSubstring : String to be replaced
     * @param sNewSubstring : Replacement string
     * @return String : String with replacements done
     */
    public String fCaseInsensitiveStringReplaceAll(String sStringToSearch, String sOldSubstring,

                                                   String sNewSubstring) throws Exception
    {
        int iStart = -1;
        String sStringToSearchCaps = sStringToSearch.toUpperCase();
        sOldSubstring = sOldSubstring.toUpperCase();
        while(sStringToSearchCaps.indexOf(sOldSubstring) > -1)
        {
            iStart = sStringToSearchCaps.indexOf(sOldSubstring);
            sStringToSearchCaps = sStringToSearchCaps.substring(0, iStart) +

                    sNewSubstring + sStringToSearchCaps.substring(iStart + sOldSubstring.length());
            sStringToSearch = sStringToSearch.substring(0, iStart) + sNewSubstring +

                    sStringToSearch.substring(iStart + sOldSubstring.length());
        }
        return sStringToSearch;
    } // End fCaseInsensitiveStringReplaceAll



/**************************************************************************************************/
    /**
     * Description   : Writes logs to the Testcase sheet.

     */
    public void fUPDATERESULTS() throws Exception
    {
        FileReader oCSVFileReader = null;
        BufferedReader oCSVBuffer = null;

        try
        {
            String sResult = null, sResultColumn = null, sXLResult = null;
            String sDescription = null, sDescriptionColumn = null, sXLDescription =

                    null;
            String sQuery = null, sTCName = null, sScriptName = null, sTemp = null;

            // Close Connections if already Open
            if (oStatement != null)
                oStatement.close();
            if (oConnection != null)
                oConnection.close();
            if (oCSVBuffer != null)
                oCSVBuffer.close();
            if (oCSVFileReader != null)
                oCSVFileReader.close();

            oConnection = null;

            // Check whether TC file and CSV file Exists or NOT
            File oTCFile = new File(sGLTestCaseFilePath);
            File oCSVFile = new File(sGLCSVFilePath);
            if (oTCFile.exists() == false || oCSVFile.exists() == false)
                return;

            // Copy TC File from TESTCASES to TESTPASS
            if (false == fCopyFile(sGLTestCaseFilePath, sGLTestPassFilePath))
                fLogMessage(0, "Fucntion: UPDATERESULTS", "Error occured while copying file from Test Cases to Test Pass folder.");

            // Open buffer to read from .csv file
            oCSVFileReader = new FileReader(oCSVFile);
            oCSVBuffer = new BufferedReader(oCSVFileReader);
            oCSVBuffer.readLine();

            // Update Excel
            while ((sTemp = oCSVBuffer.readLine()) != null)
            {
                // Get CSV Fields
                String [] sSplit = sTemp.split(",");
                sScriptName = sSplit[0].replaceAll("'", "");
                sScriptName = sScriptName.replaceAll(sGLProjectName + "_", "");
                sTCName = sSplit[1].replaceAll("'", "");
                sResult = sSplit[3].replaceAll("'", "");
                sDescription = sSplit[4].replaceAll("'", "");

                String [] sTempSplitArray = sTCName.split("_");
                sTCName = sTempSplitArray[sTempSplitArray.length - 1];

                if (sScriptName.indexOf("ACCOUNTANT") >= 0 || sScriptName.indexOf("SALESPERSON") >= 0
                        || sScriptName.indexOf("BETA_ONEWORLD_ACCOUNTANT") >= 0 || sScriptName.indexOf("BETA_ONEWORLD_SALESPERSON") >= 0)
                    sTCName = sScriptName;

                // Get Excel Fields
                // Get connection to Testcases excel
                if (oConnection == null)
                {
                    oConnection = fGetExcelConnection(sGLTestPassFilePath, "false");
                    // Create statement
                    oStatement = oConnection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                }
                sQuery = "Select * From [DetailedTestCases$] where TestScenarioID = '" + sScriptName + "' AND TestCaseID = '" + sTCName + "'";
                oResultSet = oStatement.executeQuery(sQuery);
                //oResultSet.next();
                if(oResultSet.next())
                {
                    // Get column names
                    if(sResultColumn == null)
                    {
                        ResultSetMetaData oMeta = oResultSet.getMetaData();
                        sResultColumn = oMeta.getColumnLabel(5);
                        sDescriptionColumn = oMeta.getColumnLabel(6);
                        oMeta = null;
                    }
                    // Get Column Data
                    sXLResult = oResultSet.getString(sResultColumn);
                    sXLDescription = oResultSet.getString(sDescriptionColumn);

                    // Append the data if available
                    if (sXLResult != null || sXLDescription != null)
                    {
                        if (sResult.equalsIgnoreCase("PASS") == false)
                            sResult = sResult;
                        else
                            sResult = sXLResult;
                        sDescription = sXLDescription + "\n" + sDescription;
                    }

                    // Update the results
                    sQuery = "Update [DetailedTestCases$] Set " + sResultColumn + " = '" + sResult + "', " + sDescriptionColumn + " = '" + sDescription + "' where TestCaseID = '" + sTCName + "'";
                    oStatement.executeUpdate(sQuery);
                    oConnection.commit();
                    sResult = null;
                    sDescription = null;
                    sTCName = null;
                }
            }
            oConnection.commit();
        }
        catch(Exception oEx)
        {
            System.out.println(oEx.toString());
            oEx.printStackTrace();
        }
        finally
        {
            if (oStatement != null)
                oStatement.close();
            if (oConnection != null)
                oConnection.close();
            if (oCSVBuffer != null)
                oCSVBuffer.close();
            if (oCSVFileReader != null)
                oCSVFileReader.close();
        }
    } // End fUPDATERESULTS



/**************************************************************************************************/
    /**
     * Description: Writes logs to default RFT format and in CSV file.
     * @param iStatus: Status
     * 					0 FAIL
     * 					1 PASS
     * 					2 NA
     * 					3 MANUAL
     * 					4 NOT AUTOMATED
     * @param sTestCaseName: Log status.
     * @param sMessage: Details of the log.
     */
    public void fLogMessage(int iStatus, String sTestCaseName, String sMessage)
    {
        try
        {
            String sStatus = null;
            String sScriptName = sGLScriptName;

            String sTemp = "";
            // Get date
            String sDate = new java.util.Date().toString();
            sTestCaseName = sTestCaseName.toUpperCase();

            if (sTestCaseName == null || sTestCaseName == "")
            {
                sTestCaseName = sScriptName;
            }

            // Log Result in to RFT Log
            switch(iStatus)
            {
                case 0: //Fail
                    // If Known issues is NOT propery initialized then log messege as Failure
                    sStatus = "FAIL";
                    //logTestResult(sTestCaseName, false, sMessage);
                    break;
                case 1: //Pass
                    sStatus = "PASS";
                    //logTestResult(sTestCaseName, true, sMessage);
                    break;
                case 2: //Na
                    sStatus = "NA";
                    //logWarning(sTestCaseName + ": " + sMessage);
                    break;
                case 3: //MANUAL
                    sStatus = "MANUAL";
                    //logInfo(sTestCaseName + ": " + sMessage);
                    break;
                case 4: //NOT Automated
                    sStatus = "NOT AUTOMATED";
                    //logInfo(sTestCaseName + ": " + sMessage);
                    break;
            }

            if(iGLRoleName == 3 || iGLRoleName == 4 || iGLRoleName == 5 || iGLRoleName == 6 || iGLRoleName == 8 || iGLRoleName == 9 || iGLRoleName == 11 || iGLRoleName == 12 )
            {
                String [] sNewTempArray  = sGLRoleArray[iGLRoleName].split("_");
                sScriptName = sNewTempArray[1].toString().toUpperCase();
            }
            sMessage = sScriptName + "," + sTestCaseName + "," + sDate + ","  + sStatus + ","  + sMessage ;

            // Log Result to Csv
            // Get CSV file name
            // String sFileName = sGLProjectLocation + sGLResultPath + sGLMachineName + ".csv";
            String sFileName = sGLCSVFilePath;
            // Check if the file exists
            File oFileE = new File(sFileName);
            if (oFileE.exists() == true)
            {
                // Read file
                FileWriter oFile = new FileWriter(sFileName, true);
                BufferedWriter oOut = new BufferedWriter(oFile);

                oOut.append(sMessage + "\n");
                //Close the output stream
                oOut.close();
                oFile.close();
            }
            else
            {
                // Create file
                FileWriter oFileWriter = new FileWriter(sFileName, true);
                BufferedWriter oOut = new BufferedWriter(oFileWriter);

                // Write the header
                sTemp = "ScriptName,TCName,Date,Result,Description";
                oOut.append(sTemp + "\n");

                // Write Messege
                oOut.append(sMessage + "\n");
                oOut.close();
                oFileWriter.close();
            }

            // Define name for the image
            if (sTestCaseName.equalsIgnoreCase(sScriptName))
                sFileName = sScriptName;
            else
                sFileName = sScriptName + "_" + sTestCaseName;

            // Get screen Snapshot and save the image to the image folder.
            switch(iGLSCREENSHOTFLAG)
            {
                case 0: // Failures Only
                    if (iStatus == 0)
                        //fCaptureImage(sFileName);
                        //fSaveScreenSnapInWord(sFileName, iStatus, sMessage);
                        break;
                case 1: // Failure + Pass 'For Support People
                    fSaveScreenSnapInWord(sFileName, iStatus, sMessage);
                    break;
                case 2: // NO screen shots
                    // Do Nothing
            }
        }
        catch (Exception oExcpetion) //Catch exception if any
        {
            System.err.println("Error in LogMessage: " + oExcpetion.toString());
        }
    } // End fLogMessage



/**************************************************************************************************/
    /**
     * Description   : Function To capture screen image
     */
    public void fCaptureImage(String sFileName)
    {
        try
        {
            Robot oRobot = new Robot();
            BufferedImage oImage = oRobot.createScreenCapture(new Rectangle

                    (Toolkit.getDefaultToolkit().getScreenSize()));
            // save captured image to PNG file
            ImageIO.write(oImage, "png", new File("C:\\RFTFailureImages\\" + sFileName + ".png"));
        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, "fCaptureImage: " + oException.toString());
        }
    } // End fCaptureImage



/**************************************************************************************************/
    /**
     * Description: Function to get screen shot of desktop and save it in the word file
     * @param sFileName: File Name.
     * @param iStatus: Log status.
     * @param sMessage: Details of the log.
     */
    public void fSaveScreenSnapInWord(String sFileName, int iStatus, String sMessage)
    {
        try
        {

            File oImageFolder = new File("C:\\RFTFailureImages");
            if (oImageFolder.exists() == false)
            {
                oImageFolder.mkdir();
            }
        }
        catch(Exception oException)
        {
            System.out.println("Function SaveScreenSnapInWord:" + oException.toString());
        }
    } // End fSaveScreenSnapInWord



/**************************************************************************************************/
    /**
     * Description: Function to copy file from one location to another
     * @param sSourceLoaction: Sourece File Name.
     * @param sTargetLocation: Target File Name.
     * @return boolean: true/false
     */
    public boolean fCopyFile(String sSourceLoaction, String sTargetLocation)
    {
        try
        {
            // Delete File if it exists
            File oFile = new File(sTargetLocation);
            if (oFile.exists() == true)
            {
                oFile.delete();
            }
            Thread.sleep(3000);

            Runtime oRun = Runtime.getRuntime();
            String sCmd = "cmd /c copy ";
            if (sSourceLoaction.indexOf(" ")!=-1 && !sSourceLoaction.startsWith("\n"))

                sSourceLoaction ="\"" + sSourceLoaction + "\"";
            if (sTargetLocation.indexOf(" ")!=-1 && !sTargetLocation.startsWith("\n"))

                sSourceLoaction ="\"" + sTargetLocation + "\"";
            sCmd = sCmd + sSourceLoaction + " " + sTargetLocation;
            oRun.exec(sCmd);
            Thread.sleep(2000);
            return true;
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            return false;
        }
    } // End fCopyFile



/**************************************************************************************************/
    /**
     * Description : Function to Execute Scripts
     */
    public void fExecuteScripts()
    {
        Connection oXLConnection = null;
        ResultSet oXLResultSet = null;
        Statement oXLStatement = null;
        try
        {
            String sQuery = null, sScriptName = null;
            //callScript("NETSUITE.TESTSCRIPTS.NETSUITE_TAXCALC");

            // Get connection to Testcases excel
            if (oXLConnection == null)
            {
                oXLConnection = fGetExcelConnection(sGLTestCaseFilePath, "false");
                // Create statement
                oXLStatement = oXLConnection.createStatement

                        (ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            }
            // Get Result Set
            sQuery = "Select AutomationID From [TestCases$] where ExecutionFlag = 1";
            oXLResultSet = oXLStatement.executeQuery(sQuery);

            // Get ScriptName in a Array
            ArrayList oArrayList = new ArrayList();
            while(oXLResultSet.next())
            {
                oArrayList.add(oXLResultSet.getString("AutomationID"));
            }
            String [] sScriptArray = (String[])oArrayList.toArray(new String[0]);
            oXLResultSet.close();

            int i = sScriptArray.length;
            for (int iTemp = 0; iTemp < sScriptArray.length; iTemp++)
            {
                sScriptName = sGLProjectName + ".TESTSCRIPTS." + sGLProjectName + "_" + sScriptArray[iTemp];
                try
                {
                    //callScript(sScriptName);
                    fCallClassMethodRuntime(sScriptName, "main");
                    System.out.println(sScriptName);
                }
                catch(Exception oInnerEx)
                {
                    System.out.println("Inner Exception: " + oInnerEx.toString

                            ());
                }
                catch (Error oError)
                {
                    System.out.println("Error:" + oError.toString());
                }
            }
        }
        catch(Exception oException)
        {
            System.out.println("Outer Exception: " + oException.toString());
        }
        finally
        {
            try
            {
                if (oXLStatement != null)
                    oXLStatement.close();
                if (oXLConnection != null || false == oXLConnection.isClosed())
                {
                    oXLConnection.commit();
                    oXLConnection.close();
                }
                if (oXLResultSet != null )
                    oXLConnection.close();
            }
            catch(Exception oException)
            {
                System.out.println("fExecuteScripts Finally: " +

                        oException.toString());
            }
        }
    } // End fExecuteScripts



/**************************************************************************************************/
    /**
     * Description: Get RecordSet Value
     * @param sExcelLocation: Excel file Location.
     * @param sQuery: Query to be executed.
     * @return boolean: true/false
     */
    public ResultSet /**/fGetRecordSet(String sExcelLocation, String sQuery)
    {
        String sDataSourceName = null;
        try
        {
            // Get connection to Testcases excel
            if (oConnection == null || oConnection.isClosed())
            {
                oConnection = fGetExcelConnection(sExcelLocation, "false");
            }
            else
            {
                // Check if the existing conncetion is with the same Excel sheet or NOT
                sDataSourceName = oConnection.getCatalog();
                if(sExcelLocation.indexOf(sDataSourceName) >= 0)
                {
                    //Do Nothing
                }
                else
                {
                    oConnection.close();
                    oConnection  = null;
                    oConnection = fGetExcelConnection(sExcelLocation, "false");
                }
            }

            // Create statement
            oStatement = oConnection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);

            // Get Result Set
            oResultSet = oStatement.executeQuery(sQuery);
            oResultSet.next();
        }
        catch(Exception oException)
        {
            oResultSet = null;
            System.out.println("Function fGetRecordSet Finally: " + oException.toString());
            try
            {
                if (oStatement != null)
                    oStatement.close();
                if (oConnection != null && false == oConnection.isClosed())
                    oConnection.close();
            }
            catch(Exception oEx)
            {
                System.out.println("Function fGetRecordSet Finally: " + oException.toString());
            }
        }
        finally
        {
            return oResultSet;
        }
    } // End fGetRecordSet



/**************************************************************************************************/
    /**
     * Captures entire screen (desktop) image and writes it to the specified file as a jpeg <p>
     * @param filename 	path and filename of file to write image out to
     * @author Tony Venditti
     */
    public static void captureScreen(String filename)
    {
        //this method captures the whole screen when only one arguement is given
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int width = screenSize.width;
        int height = screenSize.height;
        doScreenCapture(filename, 0, 0, width, height);
    }



    /***************************************************************************************************

     ***
     /**
     * Helper function to capture screen image <p>
     * @param filename 	path and filename of file to write image out to
     * @param x 		x coordinate of screen location to capture
     * @param y 		y coordinate of screen location to capture
     * @param width 	width coordinate of screen location to capture
     * @param height 	height coordinate of screen location to capture
     * @author Tony Venditti
     */
    protected static void doScreenCapture(String filename, int x, int y, int width, int height)
    {
        //screen capture
        try {
            BufferedImage capture = null;
            Rectangle area = new Rectangle(x, y, width, height);
            Robot robot = new Robot();
            capture = robot.createScreenCapture(area);
            FileOutputStream out =	new FileOutputStream(filename);
            //JPEGImageEncoder encoder =
            //JPEGCodec.createJPEGEncoder(out);
            //encoder.encode(capture);
            out.flush();
            out.close();
        }
        catch (Exception e)
        {
            System.out.println("Error in BitmapOps#doScreen: error capturing image: " +

                    e.toString());
        }
    }



/**************************************************************************************************/
    /**
     * Description: Get RecordSet Value
     * @param sClassName: Class Name
     */
    public static void fCallClassMethodRuntime(String sClassName, String sMethodName)
    {
        try
        {
            String[] args = {""};

            Class oClass = Class.forName(sClassName);
            Class[] oClassArray = new Class[] {String[].class};
            Object [] oPassedArgObjectArray = { args };
            Object oObject = oClass.newInstance();
            Method oMethod = oClass.getMethod(sMethodName, oClassArray);
            oObject = oMethod.invoke(oObject, oPassedArgObjectArray);
        }
        catch(Exception oException)
        {
            System.out.println("Function fCallClassMethodRuntime: " +

                    oException.toString());
        }
    } // End fCallClassMethodRuntime



    /**************************************************************************************************/
    /**
     * Description   : Returns the Row numebr of the table
     */
    public int fGetRowNumberofTable(String sTableDesc, int iColumnNumber, String sTextToFind)
    {
        int iRowCount = 0, iFlag = 0, iReturnRowNumber = 0;
        String sTemp = "";
        try
        {
            // Get Row and column Count
            iRowCount = driver.findElements(By.xpath(sTableDesc + "/tbody/tr")).size();
            // Get row number of specific text
            for (int iCount = 1; iCount <= iRowCount; iCount++)
            {
                sTemp =driver.findElement(By.xpath(sTableDesc + "/tbody/tr[" + iCount + "]/td[" + iColumnNumber + "]")).getText();

                if(sTemp.equalsIgnoreCase(sTextToFind) == true)
                {
                    iFlag = 1;
                    iReturnRowNumber = iCount; // (One for Header row)
                    break;
                }
            }
            if(iFlag != 1)
                fLogMessage(2, sGLTestCaseName, "Function fGetRowNumberofTable: Row number NOT found.For sTableDesc=" + sTableDesc + ":iColumnNumber=" + iColumnNumber + ":sTextToFind=" + sTextToFind);
        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, "Function fGetRowNumberofTable: " + oException.toString());
        }
        return iReturnRowNumber;
    }


/**************************************************************************************************/
    /**
     * Description   : Function to Handle DialogBox
     */
    public void fHandleDialogBox() throws Exception
    {
        //String sTemp = null;
        try
        {
            Thread.sleep(1000);
            if (true == fIsAlertPresent())
            {
                Alert alert = driver.switchTo().alert();
                String sAlertMessage;
                sAlertMessage = alert.getText();
                if (sAlertMessage.contains("accounting period")  || sAlertMessage.contains("different kind of tax")
                        || sAlertMessage.equalsIgnoreCase("Are you sure you want to void this transaction?")
                        || sAlertMessage.equalsIgnoreCase( "Are you sure you want to delete this transaction?"))
                {
                    //Accept the Alert message by clicking OK button or Higlighted button
                    alert.accept();
                }
                else
                {
                    alert.dismiss();
                }

                Thread.sleep(2000);
            }
        }
        catch (Exception oException)
        {
            //fLogMessage(0,sGLTestCaseName,"fHandleDialogBox:." + oException.toString());

        }
    }// End fHandleDialogBox

/**************************************************************************************************/
    /**
     * Description   : Function to Verify Alert Present OR NOT
     */
    public boolean fIsAlertPresent()  throws Exception
    {
        try
        {
            Thread.sleep(3000);
            driver.switchTo().alert();
            return true;
        }
        catch (NoAlertPresentException Ex)
        {
            return false;
        }
    }   // End fIsAlertPresent


    public void WaitForPageLoad() throws Exception
    {

        try
        {
            //Wait for the Page lGL_MAX_WAIT_TIME_IN_Seconds
            driver.manage().timeouts().implicitlyWait(lGL_MAX_WAIT_TIME_IN_Seconds, TimeUnit.SECONDS);

        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"WaitForPageLoad failed with the exception : ." + oException.toString());
        }
    }// End WaitForPageLoad

    public String fRamdomString (int iStringLength)
    {

        StringBuilder sStringBuffer = new StringBuilder();
        for (int x = 0; x < iStringLength; x++)
        {
            sStringBuffer.append((char)((int)(Math.random()*26)+97));
        }
        //System.out.println(sStringBuffer.toString());
        return sStringBuffer.toString();
    }

    public void ExecutionDelay (int iSeconds)
    {   //Date d = new Date();
        Date date = new Date();
        date.setSeconds(date.getSeconds()+ iSeconds);
           // int i= d.compareTo(date);
        while(new Date().compareTo(date)<0)
        {

        }



    }

















}