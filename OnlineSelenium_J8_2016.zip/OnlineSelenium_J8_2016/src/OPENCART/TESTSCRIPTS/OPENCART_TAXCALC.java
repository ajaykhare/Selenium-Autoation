package OPENCART.TESTSCRIPTS;

import OPENCART.FUNCTIONLIBRARY.OPENCART_FUNCTIONLIBRARY;

/**
 * Created with IntelliJ IDEA.
 * User: Ajay.khare
 * Date: 12/8/14
 * Time: 11:00 AM
 * To change this template use File | Settings | File Templates.
 */
public class OPENCART_TAXCALC extends OPENCART_FUNCTIONLIBRARY {
    public static void main(String[] args) {

        try
        {
            OPENCART_TAXCALC oTestMain = new OPENCART_TAXCALC();
            oTestMain.testmain();
        }
        catch(Exception oException)
        {
            System.out.println(oException.toString());
        }
    }

    public void testmain()
    {

        String sScriptName = "";

        boolean bResult;
        bGLTaxCodeAtLinelevel = false;
        try
        {
            //  sGLCustomer = "Testing";

            // Step 1: Browse to application URL and login
            bResult = fStartFunction();
            if(!bResult)
                return;
            // Start Data sheet test cases execution
            int iCount =4;
            for (int iTemp = 2; iTemp <= iCount; iTemp++)
            {
                sGLTestCaseName = "TestCase" + iTemp;
                fCalculateSalesTax (sGLTestCaseName);
                if(!bResult)
                    return;
            }

        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, oException.toString());
        }
        finally
        {
            fFinallyFunction(sScriptName);
        }

    }
}
