package ScriptTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

/**
 * Created with IntelliJ IDEA.
 * User: Ajay.khare
 * Date: 5/18/16
 * Time: 11:10 AM
 * To change this template use File | Settings | File Templates.
 */
public class Testing {
    public static void main(String[] args) throws InterruptedException {
        // TODO Auto-generated method stub



        System.setProperty("webdriver.chrome.driver", "D:\\Selenium RC Working\\chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();


        driver.get("https://admin-development.avalara.net/login.aspx");
        driver.manage().window().maximize();
        driver.findElement(By.id("ctl00_MainContentPlaceHolder_Login1_UserName")).click();
        driver.findElement(By.id("ctl00_MainContentPlaceHolder_Login1_UserName")).clear();
        driver.findElement(By.id("ctl00_MainContentPlaceHolder_Login1_UserName")).sendKeys("ajay.khare@avalara.com");
        driver.findElement(By.id("ctl00_MainContentPlaceHolder_Login1_Password")).clear();
        driver.findElement(By.id("ctl00_MainContentPlaceHolder_Login1_Password")).sendKeys("kennwort");
        driver.findElement(By.id("ctl00_MainContentPlaceHolder_Login1_Login")).click();
        driver.findElement(By.linkText("Reports")).click();
        driver.findElement(By.id("ctl00_WebPartManager_gwpRptHomePage1_RptHomePage1_hlReconcile")).click();//

        WebElement element=driver.findElement(By.id("ctl00_WebPartManager_gwpReportHomePage1_ReportHomePage1_lstReports"));

       // Select dropdown = new Select(driver.findElement(By.id("identifier")));
        new Select(driver.findElement(By.id("ctl00_WebPartManager_gwpReportHomePage1_ReportHomePage1_lstReports"))).selectByVisibleText("Document Summary");
        driver.findElement(By.cssSelector("option[value=\"/SDK_Dev_13.3.0.20_Sales/DocumentSummaryReport\"]")).click();

       // driver.findElement(By.id("ctl00_WebPartManager_gwpReportHomePage1_ReportHomePage1_ctl00_WebPartManager_gwpReportHomePage1_ReportHomePage1_tblMainPanel")).click();
        driver.findElement(By.id("ctl00_WebPartManager_gwpReportHomePage1_ReportHomePage1_btnSecondGenrateButton")).click();


        for(String winHandle : driver.getWindowHandles()){
            driver.switchTo().window(winHandle);
        }
        System.out.println("Title of the page after - switchingTo: " + driver.getTitle());
        driver.findElement(By.xpath("//label[@id='LABEL1']/input")).click();
        String S1 = driver.getTitle();
        /*Iterable<String> handles = driver.getWindowHandles();
        System.out.println(handles);*/








      /* // WebDriver driver = new FirefoxDriver();
        driver.get("http://avpn-ascent/avalaraess/Default.htm");
        driver.manage().window().maximize();
        Thread.sleep(3000);
        String S1 = driver.getTitle();
        driver.findElement(By.name("Image1")).click();
       // driver.get("https://in.yahoo.com/?p=us");

        //Iterable<String> handles = driver.getWindowHandles();
        //System.out.println(handles);

        String winHandle=handles.iterator().next();
        String S2 = driver.getTitle();


        Object firstWinHandle = driver.getWindowHandle(); ((java.util.Set<String>) handles).remove(firstWinHandle+S1);

      //  String winHandle=handles.iterator().next();

        String S3 = driver.getTitle();
        System.out.println(handles);*/
    }
}