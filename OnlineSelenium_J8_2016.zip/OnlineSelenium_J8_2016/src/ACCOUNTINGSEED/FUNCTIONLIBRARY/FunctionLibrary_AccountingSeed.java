package ACCOUNTINGSEED.FUNCTIONLIBRARY;

import GLOBALLIBRARY.GenericFunctions;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import java.net.InetAddress;
import java.text.DecimalFormat;
import java.util.concurrent.TimeUnit;


/**
 * Created with IntelliJ IDEA.
 * User: Ajay.Khare
 * Date: 1/29/15
 * Time: 11:51 AM
 * To change this template use File | Settings | File Templates.
 */
public class FunctionLibrary_AccountingSeed  extends GenericFunctions

    {
        public boolean fStartFunction()
        {

            boolean bResult;// = false;

            try
            {
                sGLTestCaseName = "";
                String qualifiedClassName = new Exception().getStackTrace()[1].getClassName();
                //if (sGLScriptName.equalsIgnoreCase(""))
                sGLScriptName = qualifiedClassName.substring(qualifiedClassName.lastIndexOf('.') + 1, qualifiedClassName.length());
                if (sGLMachineName.equalsIgnoreCase(""))
                    sGLMachineName = InetAddress.getLocalHost().getHostName();
                //Below function opens new browser With application URL and process with login
                bResult = fLogin_Accountingseed();
              //  if(!bResult)
                //   return false;
                ///////////////////////////Products creation///////////////////////////////

             //  bResult =  fCreateProducts();
              // if(!bResult)
              //     return false;

                ///////////////////////////////////////////////////////////////////////////
            }
            catch(Exception oException)
            {
                fLogMessage(0, sGLTestCaseName, "Start Block: " + oException.toString());
                return false;
            }
            return true;
        }
    // End fStartFunction

        /**************************************************************************************************
         /**
         * Description   : Function To close connection.
         ***************************************************************************************************/
    public void fFinallyFunction(String sScriptName)
    {
        try
        {
            // Close connection if already open.
            if (oConnection != null )
                if(oConnection.isClosed() == false)
                    oConnection.close();
            oConnection = null;

            iGLCalculateTax = 0;  // 0 means nothing; 1 means dont calculate tax
            iGLEnterShiptoAddressontheFly = 1;  // 0 means Select Ship to addres from drop down; 1 means Enter address Run time
            iGLMSR = 0;  // 0 means NO MSR ; 1 means MSR and enter line level ship to addresses
        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, "Finally Block: " + oException.toString());
        }
        sGLTestCaseName = sScriptName;
        fLogMessage(1 , sGLTestCaseName, "Script Ended.");
    } // End fFinallyFunction
    /**************************************************************************************************
     * Description   : Function to login Sales Force web application
     * @return boolean : true if Application is logged successfully, false otherwise
     **************************************************************************************************/
    public boolean fLogin_Accountingseed() throws Exception
    {

        String sUsername = "connectorsforg@27demo.com";
       // String sPassword = "Avalara201444";
        String sPassword = "Avalara@200016";

        try
        {
            driver.get("https://login.salesforce.com/?locale=in");
            //Maximizing the window
            driver.manage().window().maximize();
            Thread.sleep(1000);
            // Enter credentials
            driver.findElement(By.id("username")).click();
            driver.findElement(By.id("username")).clear();
            driver.findElement(By.id("username")).sendKeys(sUsername);
            driver.findElement(By.id("password")).clear();
            driver.findElement(By.id("password")).sendKeys(sPassword);
            // Click on Login button
            driver.findElement(By.id("Login")).click();
            ExecutionDelay (12);
            if(IsElementPresent(By.id("ForceCom_font")))
            {
                fLogMessage(1,sGLTestCaseName,"Logging into AccountingSeed application is successful.");
            }
            else
                fLogMessage(0,sGLTestCaseName,"Logging into AccountingSeed application is Failed.");
            return true;
        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fLoginException:" + oException.toString());
            return false;
        }
    }// End fLogin_Sales Force
    /**************************************************************************************************
     /**
     * Description   : Function to go to menu
     * @param sMenu: String for menu
     * @return boolean : true if Menu selection is successful, false otherwise
     **************************************************************************************************/
    public boolean fMenuSelection(String sMenu) throws Exception
    {    int iCount = 3;
        String AvalaraURL ="";
        String AvalaraAccountNumber = "";
        String AvalaraLicenseKey = "";

        String sOpportunityName;
        try
        {
            ExecutionDelay (10);
            // Open TaxNowSettings
            if(sMenu.equalsIgnoreCase("AvaTax Settings"))
            {
               // if(IsElementPresent(By.linkText("AvaTax Settings")));
                if(IsElementPresent(By.linkText("Avalara")));
                {
                    driver.findElement(By.linkText("Avalara")).click();
                   // driver.findElement(By.linkText("Avalara")).click();
                    ExecutionDelay (10);

                    driver.manage().timeouts().implicitlyWait(lGL_MAX_WAIT_TIME_IN_Seconds, TimeUnit.SECONDS);
                    // Click on recent TaxNow setting Ajay
                    driver.findElement(By.xpath("//th/a")).click();
                    ExecutionDelay (10);
                    ////// Test connection  /////
                    /*
                    sGLTestConnectionFlag = oResultSet.getString("TestConnections");
                    if (sGLTestConnectionFlag != null)
                       for ( int iTemp = 1; iTemp <=  iCount; iTemp++)
                        {
                         if (iTemp==2)    // InValid values
                         {
                             AvalaraURL ="https://development.avalara.nett/";
                             AvalaraAccountNumber = "1100005845";
                             AvalaraLicenseKey = "D1BF31B87DEFD8er";
                         }
                    if (iTemp==3)   // valid Values
                    {

                        AvalaraURL ="https://development.avalara.net";
                        AvalaraAccountNumber = "1100005803";
                        AvalaraLicenseKey = "D1BF31B87DEFD817";
                    }

                    driver.findElement(By.name("edit")).click();
                    Thread.sleep(2000);
                    driver.findElement(By.xpath("//tr[2]/td[2]/input")).clear();
                    driver.findElement(By.xpath("//tr[2]/td[2]/input")).sendKeys(AvalaraURL);
                    driver.findElement(By.xpath("//tr[3]/td[2]/input")).clear();
                    driver.findElement(By.xpath("//tr[3]/td[2]/input")).sendKeys(AvalaraAccountNumber);
                    driver.findElement(By.xpath("//tr[4]/td[2]/input")).clear();
                    driver.findElement(By.xpath("//tr[4]/td[2]/input")).sendKeys(AvalaraLicenseKey);
                    driver.findElement(By.name("save")).click();
                    Thread.sleep(2000);
                    driver.findElement(By.name("avaacctseed__cbtestconnect")).click();
                    Thread.sleep(3000);
                    String Status_Result = driver.findElement(By.xpath("//form[@id='j_id0:j_id1:j_id2']/h1")).getText();
                    fLogMessage(1,sGLTestCaseName,"-"+  sMenu + Status_Result +" - Test connection result" );
                   // fLogMessage(1, Status_Result, "Opportunities created successfully");   // Log result
                    driver.findElement(By.name("j_id0:j_id1:j_id2:j_id14")).click();
                    Thread.sleep(2000);
                        }

                    ///////////////////////////////
                    // Check Address validation flag
                    if (sGLAddressValidationFlag != null)
                    {
                        driver.findElement(By.name("edit")).click();
                        driver.findElement(By.xpath("//textarea")).click();
                        driver.findElement(By.xpath("//textarea")).clear();
                        driver.findElement(By.xpath("//textarea")).sendKeys(sGLShiptoAddress_Line1);
                        driver.findElement(By.xpath("//td[4]/input")).clear();
                        driver.findElement(By.xpath("//td[4]/input")).sendKeys(sGLShiptoAddress_City);
                        driver.findElement(By.xpath("//tr[4]/td[4]/input")).clear();
                        driver.findElement(By.xpath("//tr[4]/td[4]/input")).sendKeys(sGLShiptoAddress_State);
                        driver.findElement(By.xpath("//tr[5]/td[4]/input")).clear();
                        driver.findElement(By.xpath("//tr[5]/td[4]/input")).sendKeys(sGLShiptoAddress_Zip);
                        driver.findElement(By.xpath("//tr[6]/td[4]/input")).clear();
                        driver.findElement(By.xpath("//tr[6]/td[4]/input")).sendKeys(sGLShipToCountryCode);
                        driver.findElement(By.name("save")).click();

                    }
                    */
                }
            }

            // Open Opportunities tab and create new opportunities

            if(sMenu.equalsIgnoreCase("Opportunities"))
            {
                if (IsElementPresent(By.linkText("Opportunities")))
                {
                    driver.findElement(By.linkText("Opportunities")).click();
                    ExecutionDelay (10);
                    driver.findElement(By.name("new")).click();
                    sOpportunityName = fRamdomString (5);
                    driver.findElement(By.id("opp3")).clear();
                    driver.findElement(By.id("opp3")).sendKeys(sOpportunityName);
                    driver.findElement(By.id("opp4")).clear();
                    driver.findElement(By.id("opp4")).sendKeys("Ajay");
                    driver.findElement(By.id("opp9")).clear();
                    driver.findElement(By.id("opp9")).sendKeys(sGLDate);
                    new Select(driver.findElement(By.id("opp11"))).selectByVisibleText("Closed Won");
                    driver.findElement(By.name("save")).click();
                    fLogMessage(1,sGLTestCaseName,"Opportunities created successfully");
                }
                else
                    fLogMessage(0,sGLTestCaseName,"Opportunities link not visible");
            }
            if(sMenu.equalsIgnoreCase("Create Billing"))
            {
                if (sGLAddressValidationFlag != null)
                {
                    driver.findElement(By.linkText("Billings")).click();
                    ExecutionDelay (8);
                    driver.findElement(By.name("new")).click();
                    ExecutionDelay (8);
                    driver.findElement(By.xpath("//div/span/input")).clear();
                    driver.findElement(By.xpath("//div/span/input")).sendKeys("Ajay");
                    driver.findElement(By.xpath("//tr[4]/td[2]/span/input")).clear();
                    driver.findElement(By.xpath("//tr[4]/td[2]/span/input")).sendKeys("Default Billing Product");
                }
                else
                {
                    driver.findElement(By.name("acctseed__create_billing")).click();
                    ExecutionDelay (10);
                    driver.findElement(By.xpath("//td[2]/input")).click();
                    ExecutionDelay (10);
                    driver.findElement(By.name("edit")).click(); // Edit
                    ExecutionDelay (10);
                    new Select(driver.findElement(By.xpath("//span/select"))).selectByVisibleText("Approved");
                    driver.findElement(By.xpath("//tr[5]/td[2]/span/input")).clear();
                    driver.findElement(By.xpath("//tr[5]/td[2]/span/input")).sendKeys("Default Billing Product");
                }
                // Enter Billing address on Billing window
                driver.findElement(By.xpath("//textarea")).click();
                driver.findElement(By.xpath("//textarea")).clear();
                driver.findElement(By.xpath("//textarea")).sendKeys(sGLShiptoAddress_Line1);
                driver.findElement(By.xpath("//div[5]/table/tbody/tr[3]/td[2]/input")).clear();
                driver.findElement(By.xpath("//div[5]/table/tbody/tr[3]/td[2]/input")).sendKeys(sGLShiptoAddress_City);
               // driver.findElement(By.xpath("//tr[4]/td[2]/input")).clear();
               // driver.findElement(By.xpath("//tr[4]/td[2]/input")).sendKeys(sGLShiptoAddress_State);
                driver.findElement(By.xpath("//div[5]/table/tbody/tr[5]/td[2]/input")).clear();
                driver.findElement(By.xpath("//div[5]/table/tbody/tr[5]/td[2]/input")).sendKeys(sGLShiptoAddress_Zip);
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[5]/table/tbody/tr[4]/td[2]/input")).clear();
                driver.findElement(By.xpath("//div[@id='ep']/div[2]/div[5]/table/tbody/tr[4]/td[2]/input")).sendKeys(sGLShiptoAddress_State);
                driver.findElement(By.xpath("//tr[6]/td[2]/input")).clear();
                driver.findElement(By.xpath("//tr[6]/td[2]/input")).sendKeys(sGLShipToCountryCode);

                //Enter Shipping  address on billing window
                driver.findElement(By.xpath("//td[4]/textarea")).click();
                driver.findElement(By.xpath("//td[4]/textarea")).clear();
                driver.findElement(By.xpath("//td[4]/textarea")).sendKeys(sGLShiptoAddress_Line1);
                driver.findElement(By.xpath("//tr[3]/td[4]/input")).clear();
                driver.findElement(By.xpath("//tr[3]/td[4]/input")).sendKeys(sGLShiptoAddress_City);
                driver.findElement(By.xpath("//tr[4]/td[4]/input")).clear();
                driver.findElement(By.xpath("//tr[4]/td[4]/input")).sendKeys(sGLShiptoAddress_State);
                driver.findElement(By.xpath("//tr[5]/td[4]/input")).clear();
                driver.findElement(By.xpath("//tr[5]/td[4]/input")).sendKeys(sGLShiptoAddress_Zip);
                driver.findElement(By.xpath("//tr[6]/td[4]/input")).clear();
                driver.findElement(By.xpath("//tr[6]/td[4]/input")).sendKeys(sGLShipToCountryCode);
                driver.findElement(By.name("save")).click();   //Save
            }
            // Open Contacts window
            if(sMenu.equalsIgnoreCase("Contacts"))
            {
                driver.findElement(By.linkText("Contacts")).click();
                ExecutionDelay (10);
                //driver.findElement(By.linkText("khare, Ajay")).click();
               // driver.findElement(By.xpath("//th/a")).click();
                driver.findElement(By.linkText("Khare, Ajay")).click();
                ExecutionDelay (6);
                driver.findElement(By.name("edit")).click();
                ExecutionDelay (5);
                //Shipping
                driver.findElement(By.id("con19street")).clear();
                driver.findElement(By.id("con19street")).sendKeys(sGLShiptoAddress_Line1);
                driver.findElement(By.id("con19city")).clear();
                driver.findElement(By.id("con19city")).sendKeys(sGLShiptoAddress_City);
                driver.findElement(By.id("con19state")).clear();
                driver.findElement(By.id("con19state")).sendKeys(sGLShiptoAddress_State);
                driver.findElement(By.id("con19zip")).clear();
                driver.findElement(By.id("con19zip")).sendKeys(sGLShiptoAddress_Zip);
                driver.findElement(By.id("con19country")).clear();
                driver.findElement(By.id("con19country")).sendKeys(sGLShipToCountryCode);

                //Mailing
                driver.findElement(By.id("con18street")).clear();
                driver.findElement(By.id("con18street")).sendKeys(sGLShiptoAddress_Line1);
                driver.findElement(By.id("con18city")).clear();
                driver.findElement(By.id("con18city")).sendKeys(sGLShiptoAddress_City);
                driver.findElement(By.id("con18state")).clear();
                driver.findElement(By.id("con18state")).sendKeys(sGLShiptoAddress_State);
                driver.findElement(By.id("con18zip")).clear();
                driver.findElement(By.id("con18zip")).sendKeys(sGLShiptoAddress_Zip);
                driver.findElement(By.id("con18country")).clear();
                driver.findElement(By.id("con18country")).sendKeys(sGLShipToCountryCode);

                driver.findElement(By.name("save")).click();
            }
            // Open Accounts window
            if(sMenu.equalsIgnoreCase("Accounts"))
            {
                driver.findElement(By.linkText("Accounts")).click();
                ExecutionDelay (10);
                driver.findElement(By.xpath("//th/a")).click();  // Account name- Ajay
                driver.findElement(By.name("edit")).click();
                ExecutionDelay (10);
                if (sGLEntityUseCode != null)
                {
                    driver.findElement(By.xpath("//span/input")).clear();
                    driver.findElement(By.xpath("//span/input")).sendKeys(sGLEntityUseCode);
                }
                if (sGLEnableVAT != null)
                {
                    driver.findElement(By.xpath("//tr[2]/td[4]/input")).clear();
                    driver.findElement(By.xpath("//tr[2]/td[4]/input")).sendKeys(sGLEnableVAT);
                }
                // Error message displayed test case for ship to null value
                if (sGLShiptoAddress_Line1==null)
                {
                    sGLShiptoAddress_Line1="";
                    sGLShiptoAddress_City ="";
                    sGLShiptoAddress_State="";
                    sGLShiptoAddress_Zip  ="";
                    sGLShipToCountryCode  ="";
                }
                // Billing address
                driver.findElement(By.id("acc17street")).clear();
                driver.findElement(By.id("acc17street")).sendKeys(sGLShiptoAddress_Line1);
                driver.findElement(By.id("acc17city")).clear();
                driver.findElement(By.id("acc17city")).sendKeys(sGLShiptoAddress_City);
                driver.findElement(By.id("acc17zip")).clear();
                driver.findElement(By.id("acc17zip")).sendKeys(sGLShiptoAddress_Zip);

                // Shipping address
                driver.findElement(By.id("acc18street")).clear();
                driver.findElement(By.id("acc18street")).sendKeys(sGLShiptoAddress_Line1);
                driver.findElement(By.id("acc18city")).clear();
                driver.findElement(By.id("acc18city")).sendKeys(sGLShiptoAddress_City);
                driver.findElement(By.id("acc18zip")).clear();
                driver.findElement(By.id("acc18zip")).sendKeys(sGLShiptoAddress_Zip);

                driver.findElement(By.name("save")).click();
            }
            ExecutionDelay (10);
            fLogMessage(1,sGLTestCaseName,"After clicking on menu " + sMenu + " Respective page opened successfully");
            return true;
        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fMenuSelection: Exception: " + oException.toString());
            return false;
        }
    }// End fMenuSelection

    /********************************************************************
     * Description   : Function for select the checkbox in Avalara setting
     ********************************************************************/
    public boolean fAvaTaxSettingsOption()
    {
        driver.findElement(By.linkText("Avalara")).click();
        ExecutionDelay (4);
        driver.findElement(By.xpath("//th/a")).click();
        ExecutionDelay (4);
        driver.findElement(By.name("edit")).click();
        ExecutionDelay (10);
        // Check for Enable Active Avalara setting
        if (sGLEnableActiveTavTaxSetting == null )
        {
            if (driver.findElement(By.xpath("//tr[3]/td[2]/input")).isSelected() )

            {
                driver.findElement(By.xpath("//tr[3]/td[2]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//tr[3]/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//tr[3]/td[2]/input")).click();
            }
        }
        // Check for EnableTaxCalculation
        if (sGLEnableTaxCalculation==null )
        {
            if (driver.findElement(By.xpath("//div[11]/table/tbody/tr[2]/td[2]/input")).isSelected() )

            {
                driver.findElement(By.xpath("//div[11]/table/tbody/tr[2]/td[2]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[11]/table/tbody/tr[2]/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[11]/table/tbody/tr[2]/td[2]/input")).click();
            }
        }
        // Check for Enable Address Validation
        if (sGLEnableAddressValidation==null)
        {
            if (driver.findElement(By.xpath("//div[9]/table/tbody/tr/td[2]/input")).isSelected() )

            {
                driver.findElement(By.xpath("//div[9]/table/tbody/tr/td[2]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[9]/table/tbody/tr/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[9]/table/tbody/tr/td[2]/input")).click();
            }
        }
        // Check for Verify Validated Addresses
        if (sGLVerifyValidatedAddress==null)
        {
            if (driver.findElement(By.xpath("//div[9]/table/tbody/tr/td[4]/input")).isSelected() )

            {
                driver.findElement(By.xpath("//div[9]/table/tbody/tr/td[4]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[9]/table/tbody/tr/td[4]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[9]/table/tbody/tr/td[4]/input")).click();
            }
        }

        // Check for Return address in upper case
        if (sGLReturnAddressInUpperCase==null)
        {
            if (driver.findElement(By.xpath("//div[9]/table/tbody/tr[2]/td[2]/input")).isSelected() )

            {
                driver.findElement(By.xpath("//div[9]/table/tbody/tr[2]/td[2]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[9]/table/tbody/tr[2]/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[9]/table/tbody/tr[2]/td[2]/input")).click();
            }
        }
        // Checking Entity/Use code
        if (sGLEntityUseCode == null)
        {
            if (driver.findElement(By.xpath("//div[11]/table/tbody/tr[2]/td[4]/input")).isSelected() )

            {
                driver.findElement(By.xpath("//div[11]/table/tbody/tr[2]/td[4]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[11]/table/tbody/tr[2]/td[4]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[11]/table/tbody/tr[2]/td[4]/input")).click();
            }
        }
        // Checking TAX CODE
        if (sGLEnableTaxCode == null)
        {
            if (driver.findElement(By.xpath("//div[11]/table/tbody/tr[3]/td[2]/input")).isSelected() )

            {
                driver.findElement(By.xpath("//div[11]/table/tbody/tr[3]/td[2]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[11]/table/tbody/tr[3]/td[2]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[11]/table/tbody/tr[3]/td[2]/input")).click();
            }
        }

        // Checking UPC CODE
        if (sGLEnableUPCcode == null)
        {
            if (driver.findElement(By.xpath("//div[11]/table/tbody/tr[3]/td[4]/input")).isSelected() )

            {
                driver.findElement(By.xpath("//div[11]/table/tbody/tr[3]/td[4]/input")).click();
            }
        }
        else
        {
            if (!driver.findElement(By.xpath("//div[11]/table/tbody/tr[3]/td[4]/input")).isSelected() )
            {
                driver.findElement(By.xpath("//div[11]/table/tbody/tr[3]/td[4]/input")).click();
            }
        }
        // Click on Save Button
        driver.findElement(By.name("save")).click();

        ExecutionDelay (10);
        if(IsElementPresent(By.name("edit")))
        {
            fLogMessage(1,sGLTestCaseName,"Tax now settings updated successfully");
            return true;
        }
        else
        {
            fLogMessage(0,sGLTestCaseName,"Tax now settings NOT updated successfully");
            return false;
        }
    }
    // End Avalara setting function

    /*******************************************************************************************************************
     * Calculate Sales Tax function
     * Function for Calculate Sales Tax for Automation data sheet test cases
     ******************************************************************************************************************/
    public boolean fCalculateSalesTax(String sUniqueID)
    {
        String sQuery;
        int iTemp,iRecordSetCount;
        boolean bResult;

        String sOpportunityName;



        try
        {

            fLogMessage(1,sGLTestCaseName,"Tax Calculation for Test case: " + sUniqueID + " Started.");
            // Creating Connection  with excel sheet
            // For Excel // sQuery = "Select * From [AutomationTaxCalculation$] where  UniqueID = '" + sUniqueID + "'";
            sQuery =  "SELECT * FROM AutomationTaxCalculation where UniqueID='"+sUniqueID+"'";
            oResultSet = fGetRecordSet(sGLDataPoolTaxFilePath, sQuery);
            if (oResultSet == null)
                fLogMessage(0,sGLTestCaseName,"Unable to connect to excel sheet");
            //Move to last item in record set to get the record
            oResultSet.last();
            iRecordSetCount = oResultSet.getRow();
            oResultSet.first();
          //  String url = driver.getCurrentUrl();
            // Go to Menu Selection and choose TaxNowSettings option for Flag setting
         //   bResult = fMenuSelection("AvaTax Settings");
          //  if (!bResult)
           //     return false;

            // Get Flag value from Data sheet  to set in Tax now settings
            sGLEnableActiveTavTaxSetting = oResultSet.getString("EnableActiveTavTaxSettingFlag");
            sGLEnableTaxCalculation = oResultSet.getString("EnableTaxCalculationFlag");
            sGLEnableAddressValidation = oResultSet.getString("EnableAddressValidationFlag");
            sGLVerifyValidatedAddress = oResultSet.getString("VerifyValidatedAddressFlag");
            sGLEntityUseCode       = oResultSet.getString("Entity/UseCOde");
            sGLEnableTaxCode       = oResultSet.getString("EnableTaxCodeMapping");
            sGLAmountForMultipleLines       = oResultSet.getString("AmountForMultipleLines");
            sGLErrorMessageDisplayed       = oResultSet.getString("ErrorMessageStatus");
            sGLShiptoAddress_Line1 = oResultSet.getString("ShiptoAddress_Line1");
            sGLShiptoAddress_City = oResultSet.getString("ShiptoAddress_City");
            sGLShiptoAddress_State = oResultSet.getString("ShiptoAddress_State");
            sGLShiptoAddress_Zip = oResultSet.getString("ShiptoAddress_Zip");
            sGLShipToCountryCode = oResultSet.getString("ShiptoAddress_Country");

            bResult = fAvaTaxSettingsOption();
            if (!bResult)
                return false;
            // Enter Ship To address
            bResult = fMenuSelection("Accounts");
            if (!bResult)
                return false;

          /*  //////////////Creating Transaction for TPA//////////////////////////


            driver.findElement(By.linkText("Opportunities")).click();
            ExecutionDelay (10);
            driver.findElement(By.name("new")).click();
            sOpportunityName = fRamdomString (5);
            driver.findElement(By.id("opp3")).clear();
            driver.findElement(By.id("opp3")).sendKeys(sOpportunityName);
            driver.findElement(By.id("opp4")).clear();
            driver.findElement(By.id("opp4")).sendKeys("Ajay");
            driver.findElement(By.id("opp9")).clear();
            driver.findElement(By.id("opp9")).sendKeys(sGLDate);
            new Select(driver.findElement(By.id("opp11"))).selectByVisibleText("Closed Won");
            driver.findElement(By.name("save")).click();

// Add line items
            driver.findElement(By.name("addProd")).click();
            ExecutionDelay (10);

            // Add Product from product page

            driver.findElement(By.id("search")).sendKeys(sGLItemCode);
            driver.findElement(By.id("save_filter_PricebookEntry")).click();
            ExecutionDelay (5);
            if (IsElementPresent(By.xpath("//tr[3]/td/div/table/tbody/tr/td")))   // Alert keyword for selected item
                driver.findElement(By.id("lineItemView_refresh")).click();
            ExecutionDelay (8);
            driver.findElement(By.id("allBox")).click();
            driver.findElement(By.xpath("//form/div/input")).click();// Select Button
            ExecutionDelay (10);
            driver.findElement(By.xpath("//tr[5]/td/input")).clear();
            driver.findElement(By.xpath("//tr[5]/td/input")).sendKeys("1");
            driver.findElement(By.xpath("//td[2]/input")).clear();
            driver.findElement(By.xpath("//td[2]/input")).sendKeys(sGLAmount);
            driver.findElement(By.name("save")).click();
            ExecutionDelay (10);

            driver.findElement(By.name("acctseed__create_billing")).click();
            ExecutionDelay (10);

            driver.findElement(By.name("avaacctseed__calculate_sales_tax")).click();


            //////////////////End Script for TPA data creation/////////////////////////*/



            // Go to Menu selection function and select Opportunity option for transaction
            bResult = fMenuSelection("Opportunities");
            if (!bResult)
                return false;
            // Call Line_Entry function to Enter line items in transaction
            oResultSet.first();
            iGLIterationNumber = 0;
            for (iTemp = 0; iTemp < iRecordSetCount; iTemp++)
            {
               // sGLTaxCodeForMultipleLines = oResultSet.getString("TaxCodeForTwoLines");
                sGLProductType  = oResultSet.getString("TaxCodeMapping");
                sGLAmount = oResultSet.getString("Amount");
                //sGLProductType  = oResultSet.getString("TaxCodeMapping");

                    if (sGLProductType.equalsIgnoreCase("1"))
                    //    if (sGLProductType=="1")
                        sGLItemCode = sGLItem1Code;
                    else if (sGLProductType.equalsIgnoreCase("2"))
                   // else   if (sGLProductType=="2")
                        sGLItemCode = sGLItem3Code;
                    else
                        sGLItemCode =    sGLItem2Code;

                //Enter data in Line Tab
                bResult = fLine_Entry("Opportunities");
                if (!bResult)
                    return false;
                iGLIterationNumber = iGLIterationNumber + 1;
                oResultSet.next();
            }
            iGLIterationNumber = 0;
            oResultSet.first();
            // Calling CalculateOpportunitySalesTax function for trigger Get tax for Opportunity
            sGLTotalTax = oResultSet.getString("TotalTax");
            sGLAmountForMultipleLines       = oResultSet.getString("AmountForMultipleLines");
            bResult = fVerifyStatusAndTaxOnWindow("Opportunities", 1);
            if (!bResult)
                return false;
            /*******************************************************************************************************************
             // Start- Transaction  for Quotes
             *******************************************************************************************************************/

/*

            bResult = fMenuSelection("Create Billing");
            if (!bResult)
                return false;
            // call fTotalSalesTax function for trigger Get tax for Quotes
            oResultSet.first();
            sGLTotalTax = oResultSet.getString("TotalTax");
            sGLAmount = oResultSet.getString("Amount");
            //sGLAmountForMultipleLines       = oResultSet.getString("AmountForMultipleLines");
            bResult = fVerifyStatusAndTaxOnWindow("Billing", 1);
            if (!bResult)
                return false;
            //sGLTotalTax = oResultSet.getString("TotalTax");
            // sGLAmount = oResultSet.getString("Amount");
            //sGLAmountForMultipleLines       = oResultSet.getString("AmountForMultipleLines");
            bResult = fVerifyStatusAndTaxOnWindow("Commit Billing", 2);
            if (!bResult)
                return false;

*/


            /////////////////////////////////////////////////////

            fLogMessage(1,sGLTestCaseName,"Tax Calculation for Test case: " + sUniqueID + " Ended.");
        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fCalculateSalesTax: Exception: " + oException.toString());
        }
        return true;
    }

    /*******************************************************************************************************************
     * Line Entry Function
     * Description   : Function for Add a product for transaction
     * @param sItemSelection : - Which window we are going to add line item
     ******************************************************************************************************************/
    boolean fLine_Entry(String sItemSelection) throws Exception {
        boolean bResult;
         //Click on Add product if Opportunity or click on Add quote line depending item selection passed
        if(sItemSelection.equalsIgnoreCase("Opportunities"))
            Thread.sleep(2000);
        ExecutionDelay (10);
        driver.findElement(By.name("addProd")).click();
        ExecutionDelay (10);

        // Add Product from product page

        driver.findElement(By.id("search")).sendKeys(sGLItemCode);
        driver.findElement(By.id("save_filter_PricebookEntry")).click();
        ExecutionDelay (5);
        if (IsElementPresent(By.xpath("//tr[3]/td/div/table/tbody/tr/td")))   // Alert keyword for selected item
        driver.findElement(By.id("lineItemView_refresh")).click();
        ExecutionDelay (8);
        driver.findElement(By.id("allBox")).click();
        driver.findElement(By.xpath("//form/div/input")).click();// Select Button


    //////////////////////////////SOQL error test cases///////////////////////////////
      // bResult= fLine_EntryForMultipleProducts();
      //  if (!bResult)
      //      return false;
    /////////////////////////////////////////////////////////////////////////////////


        ExecutionDelay (10);
        driver.findElement(By.xpath("//tr[5]/td/input")).clear();
        driver.findElement(By.xpath("//tr[5]/td/input")).sendKeys("1");
        driver.findElement(By.xpath("//td[2]/input")).clear();
        driver.findElement(By.xpath("//td[2]/input")).sendKeys(sGLAmount);
        driver.findElement(By.name("save")).click();
        ExecutionDelay (10);
        return true;
    }
    //End of fLine_Entry


    /*******************************************************************************************************************
     * Function for Avalara Status / Avalara AvaTax / Error Message Displayed
     * Description   : Function for Trigger Get Tax for Opportunity
     * @param sMenuOption = Perform Action on Opportunities or Quotes window
     * @param iClickOption = Click on Calculate push button or Finalize push button
     *******************************************************************************************************************/
    boolean fVerifyStatusAndTaxOnWindow(String sMenuOption , int iClickOption)
    {     String sSalesTax, sTaxID1="",sTaxID,sExpectedSalesTax;
        String [] sTaxID3 ;
        // String [] sSalesTax1 ;
        String  sTaxID2 ;
        double d2;
        double d3;
        String  sErrorMessage ;
        String sCalculateOrFinalizeOption;
        ExecutionDelay (10);
        //Click on Calculate Sales Tax Button depending upon passed parameter
        if(sMenuOption.equalsIgnoreCase("Opportunities"))// || sMenuOption.equalsIgnoreCase("Finalize Opportunity"))
        {
            if (iClickOption == 1)
                driver.findElement(By.name("avaacctseed__add_sales_tax")).click();
            ExecutionDelay (10);
            sTaxID1 = "//tr[3]/td[4]/div";
        }
        else if (sMenuOption.equalsIgnoreCase("Billing") || sMenuOption.equalsIgnoreCase("Commit Billing")) //For Billing
        {
            if (iClickOption == 1)
                sCalculateOrFinalizeOption = "avaacctseed__calculate_sales_tax";
            else
                sCalculateOrFinalizeOption = "avaacctseed__post_commit";
            driver.findElement(By.name(sCalculateOrFinalizeOption)).click();
            ExecutionDelay (10);
            // Billing Tax field
            sTaxID1 ="//tr[3]/td[4]/div";
        }
        // Check if Error message displayed test cases
        if (sGLEnableTaxCalculation == null || sGLErrorMessageDisplayed != null)
        {
            //Capture Error message
            ExecutionDelay (8);
            sErrorMessage = driver.findElement(By.xpath("//form[@id='j_id0:j_id1:j_id2']/h1")).getText();
            sErrorMessage = sErrorMessage.replaceAll("\\n"," ");
            //Click on Ok button
            driver.findElement(By.name("j_id0:j_id1:j_id2:j_id14")).click();
            /*
            if (sMenuOption.equalsIgnoreCase("Commit Billing"))
            {
                sErrorMessage = driver.findElement(By.xpath("//td/h2")).getText();
                sErrorMessage =sErrorMessage +"Error" ;
               // sErrorMessage = driver.findElement(By.xpath("//span/div/table/tbody/tr/td[2]/div"+"Error")).getText();
                sErrorMessage = sErrorMessage.replaceAll("\\n"," ");
                //Click on Ok button
                driver.findElement(By.xpath("//td[2]/input")).click();
            }
            else{

                sErrorMessage = driver.findElement(By.xpath("//form[@id='j_id0:j_id1:j_id2']/h1")).getText();
                sErrorMessage = sErrorMessage.replaceAll("\\n"," ");
                //Click on Ok button
                driver.findElement(By.name("j_id0:j_id1:j_id2:j_id14")).click();
            }
            */
            ExecutionDelay (10);
            //selenium.waitForPageToLoad(sGL_MAX_WAIT_TIME_IN_MS);
            fLogMessage(1,sGLTestCaseName,"Error message appeared as " + sErrorMessage );
        }
        else
        {

            sTaxID2 = driver.findElement(By.xpath(sTaxID1)).getText();
            sTaxID3 = sTaxID2.split("\\$");
            sTaxID = sTaxID3[1].replaceAll(",","");
            double d1 = Double.valueOf(sTaxID);
            if(sGLTaxCodeForMultipleLines != null)
            {
                ExecutionDelay (2);
                // d2 = Double.valueOf(sGLAmount);
                // sGLAmountForMultipleLines = sGLAmountForMultipleLines+".00";
                d2 = Double.valueOf(sGLAmountForMultipleLines);
            }
            else {
                if (sMenuOption.equalsIgnoreCase("Commit Billing"))
                    ExecutionDelay (2);
                else
                {
                    sGLAmount = sGLAmount+".00";

                }
                d2 = Double.valueOf(sGLAmount);
            }
            d3 = d1-d2;
            d3 =Double.parseDouble(new DecimalFormat("##.##").format(d3));
            sSalesTax = String.valueOf(d3) ;
            sExpectedSalesTax=sSalesTax+"0";
            sGLTotalTax = sGLTotalTax.trim();
            if (sExpectedSalesTax.equalsIgnoreCase(sGLTotalTax))
                fLogMessage(1,sGLTestCaseName,"'Total Sales Tax' " + sGLTotalTax + " verified successfully for Test case " +sGLTestCaseName
                        + " on "  + sMenuOption + " Window.");
            else
            {
                fLogMessage(0,sGLTestCaseName,"'Total Sales Tax' " + sGLTotalTax + " NOT verified successfully for Test case" +sGLTestCaseName
                        + " on " + sMenuOption + " Window.Expected Tax :- " + sGLTotalTax + " and Actual Tax:- " + sExpectedSalesTax);
                return false;
            }
        }
        ExecutionDelay (10);

        return true;
    }



    /*******************************************************************************************************************
     // Function for Address validation for Automation data sheet test cases
     *******************************************************************************************************************/
    public boolean fAddressValidation(String sUniqueID)
    {
        String sQuery ;
        boolean bResult;
        try {
            fLogMessage(1,sGLTestCaseName,"Address Validation for Test case: " + sUniqueID + " Started.");
            // Creating Connection  with excel sheet
            // For Excel // sQuery = "Select * From [AutomationTaxCalculation$] where  UniqueID = '" + sUniqueID + "'";
            sQuery =  "SELECT * FROM AutomationTaxCalculation where UniqueID='"+sUniqueID+"'";
            oResultSet = fGetRecordSet(sGLDataPoolTaxFilePath, sQuery);
            if (oResultSet == null)
                fLogMessage(0,sGLTestCaseName,"Unable to connect to excel sheet");
            oResultSet.first();
            sGLEnableActiveTavTaxSetting = oResultSet.getString("EnableActiveTavTaxSettingFlag");
            sGLShiptoAddress_Line1 = oResultSet.getString("ShiptoAddress_Line1");
            sGLShiptoAddress_City = oResultSet.getString("ShiptoAddress_City");
            sGLShiptoAddress_State = oResultSet.getString("ShiptoAddress_State");
            sGLShiptoAddress_Zip = oResultSet.getString("ShiptoAddress_Zip");
            sGLShipToCountryCode = oResultSet.getString("ShiptoAddress_Country");
            sGLLineStatus   = oResultSet.getString("VerifyFinalAddress");
            sGLAddressValidationFlag = oResultSet.getString("AddressValidationStatus");
            sGLEnableAddressValidation = oResultSet.getString("EnableAddressValidationFlag");
            sGLVerifyValidatedAddress = oResultSet.getString("VerifyValidatedAddressFlag");
            // Go to Menu Selection and choose TaxNowSettings option for Flag setting

            bResult = fMenuSelection("AvaTax Settings");
            if (!bResult)
                return false;
            bResult = fAvaTaxSettingsOption();
            if (!bResult)
                return false;
            // Origin Address validation for TAX NOW setting
            bResult= fShipToAddressValidation("AvaTax Settings");
            if (!bResult)
                return false;

            // Address validation for CONTACTS
            bResult = fMenuSelection("Contacts");
            if (!bResult)
                return false;
            bResult= fShipToAddressValidation("Contacts");
            if (!bResult)
                return false;
            // Address validation for ACCOUNTS
            bResult = fMenuSelection("Accounts");
            if (!bResult)
                return false;
            bResult= fShipToAddressValidation("Accounts");
            if (!bResult)
                return false;
            bResult= fBillToAddressValidation("Accounts");
            if (!bResult)
                return false;

            // Address validation for Billing
            bResult = fMenuSelection("Create Billing");
            if (!bResult)
                return false;
            bResult= fShipToAddressValidation("Billings");
            if (!bResult)
                return false;
            bResult= fBillToAddressValidation("Billings");
            if (!bResult)
                return false;
        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fAddressValidation: Exception: " + oException.toString());
        }
        return true;
    }
    //    End of fAddressValidation





    /*********************************************************************************************************************
     // Start -- Function for Ship To Address validation
     *********************************************************************************************************************/
    boolean fShipToAddressValidation(String sOption)
    {    boolean bResult;
        if(sOption.equalsIgnoreCase("Contacts"))
            //   Trigger validate Ship To address for Contacts
            driver.findElement(By.name("avaacctseed__validate_mailing_address")).click();

        if(sOption.equalsIgnoreCase("Accounts"))
            //   Trigger validate Ship To address for Accounts
            driver.findElement(By.name("avaacctseed__validate_shipping_address")).click();

        //   Trigger validate Ship To address for Billings
        if(sOption.equalsIgnoreCase("Billings"))
            driver.findElement(By.name("avaacctseed__validate_shipping_address")).click();

        //  Check condition for TaxNow setting
        if(sOption.equalsIgnoreCase("AvaTax Settings"))
            driver.findElement(By.name("avaacctseed__cbvalidateorigin")).click();

        // taking time for loading the page
        ExecutionDelay (10);
        //   Calling function for verifying the validated address
        bResult  = fVerifyValidatedAddress(sOption);
        if(!bResult)
            return false;
        if(IsElementPresent(By.name("j_id0:j_id1:j_id2:j_id26")))
        {
            driver.findElement(By.name("j_id0:j_id1:j_id2:j_id26")).click();

            fLogMessage(1,sGLTestCaseName,"Address validation saved successfully"+ sOption);
        }
        else if  (IsElementPresent(By.name("j_id0:j_id1:j_id2:j_id14")))
        {
            driver.findElement(By.name("j_id0:j_id1:j_id2:j_id14")).click();

            fLogMessage(1,sGLTestCaseName,"Address validation saved successfully"+ sOption);
        }
        else
            fLogMessage(0,sGLTestCaseName,"Address validation not saved successfully"+ sOption);
        ExecutionDelay (10);
        return true;
    }
    // End of  fShipToAddressValidation

    /*********************************************************************************************************************
     // Start -- Function for Bill To Address validation
     *********************************************************************************************************************/
    boolean fBillToAddressValidation(String sOption)
    {     boolean bResult;
        ExecutionDelay (8);
        if(sOption.equalsIgnoreCase("Accounts"))
            // Trigger validate billing address
            driver.findElement(By.name("avaacctseed__validate_billing_address")).click();

        //   Billings window
        if(sOption.equalsIgnoreCase("Billings"))
            // Trigger validate Bill To address
            driver.findElement(By.name("avaacctseed__validate_billing_address")).click();

        ExecutionDelay (10);

        // Calling function for verifying the validated address
        bResult  = fVerifyValidatedAddress(sOption);
        if(!bResult)
            return false;
        // Click on Save button
        if(IsElementPresent(By.name("j_id0:j_id1:j_id2:j_id26")))
        {
            driver.findElement(By.name("j_id0:j_id1:j_id2:j_id26")).click();

            fLogMessage(1,sGLTestCaseName,"Address validation saved successfully");
        }
        else if  (IsElementPresent(By.name("j_id0:j_id1:j_id2:j_id14")))
        {
            driver.findElement(By.name("j_id0:j_id1:j_id2:j_id14")).click();

            fLogMessage(1,sGLTestCaseName,"Address validation saved successfully");
        }
        else
            fLogMessage(0,sGLTestCaseName,"Address validation not saved successfully");
        ExecutionDelay (10);

        return true;
    }
    // End of fBillToAddressValidation
    /*******************************************************************************************************************
     * Verify Validated Address function
     * Description   : Function for Add a product for transaction
     * @param  sOption = On which window we are verifying tax
     ******************************************************************************************************************/
    boolean fVerifyValidatedAddress(String sOption)
    {
        String sOnScreenValidateAddress;
        String sOnScreenLine1;
        String sOnScreenCity_State_Zip;
        String sOnScreenCountry;
        ExecutionDelay (10);
        // Address validation for valid address
        if(sOption.equalsIgnoreCase("AvaTax Settings")||(sOption.equalsIgnoreCase("Contacts"))||(sOption.equalsIgnoreCase("Accounts"))||(sOption.equalsIgnoreCase("Billings")))
        {
            if(IsElementPresent(By.xpath("//form[@id='j_id0:j_id1:j_id2']/table/tbody/tr[7]/td[4]/input")))
            {
                sOnScreenLine1 =  driver.findElement(By.xpath("//form[@id='j_id0:j_id1:j_id2']/table/tbody/tr[2]/td[5]")).getText();
                sOnScreenCity_State_Zip = driver.findElement(By.xpath("//form[@id='j_id0:j_id1:j_id2']/table/tbody/tr[5]/td[5]")).getText();
                sOnScreenCountry = driver.findElement(By.xpath("//form[@id='j_id0:j_id1:j_id2']/table/tbody/tr[6]/td[5]")).getText();
                sOnScreenValidateAddress =  sOnScreenLine1+ ", "+sOnScreenCity_State_Zip+", "+sOnScreenCountry;
                if (sOnScreenValidateAddress.equalsIgnoreCase(sGLLineStatus))
                    fLogMessage(1,sGLTestCaseName,"Avalara Address Validation Test Case" + "' verified successfully for " +sGLTestCaseName
                            + sOption + " Window ");
                else
                {
                    fLogMessage(0,sGLTestCaseName,"Avalara Address Validation Test Case ' "  + " ' NOT verified successfully  for " +sGLTestCaseName
                            + sOption + " Window " + "Expected : " + " and Actual: "+ sOnScreenValidateAddress);
                    return false;
                }
                ExecutionDelay (10);
            }
            // Address validation for disable address / Invalid address
            else if(IsElementPresent(By.xpath("//form[@id='j_id0:j_id1:j_id2']/h1")))
            {
                fLogMessage(1,sGLTestCaseName,"Address validation verified successfully" + sOption);
            }
        }
        else
        {
            fLogMessage(0,sGLTestCaseName,"F: Address not validated successfully" + sOption);
            return false;
        }
        ExecutionDelay (5);
        return true;
    }
    //////////////////////////// Create products  ///////////////////////////////
    public boolean fCreateProducts()
    {      int iCount =200;
        boolean bResult;
        try
        {
            for ( int iTemp = 2; iTemp <= iCount; iTemp++)
            {
               // sGLTestCaseName = "TestCase" + iTemp;
                driver.findElement(By.linkText("Products")).click();
                Thread.sleep(2000);
                driver.findElement(By.name("new")).click();
                Thread.sleep(2000);
                driver.findElement(By.id("Name")).clear();
                driver.findElement(By.id("Name")).sendKeys("Test"+iTemp);
                driver.findElement(By.id("ProductCode")).clear();
                driver.findElement(By.id("ProductCode")).sendKeys("Test"+iTemp);
                driver.findElement(By.id("Description")).click();
                driver.findElement(By.id("Description")).clear();
                driver.findElement(By.id("Description")).sendKeys("Testing");
                driver.findElement(By.id("IsActive")).click();
                driver.findElement(By.xpath("//div[3]/table/tbody/tr/td[2]/input[2]")).click();
                Thread.sleep(2000);
                driver.findElement(By.name("add")).click();
                Thread.sleep(1000);
                driver.findElement(By.id("td0_2")).clear();
                driver.findElement(By.id("td0_2")).sendKeys("1000");
                driver.findElement(By.name("save")).click();
                Thread.sleep(2000);
                driver.findElement(By.name("add")).click();
                Thread.sleep(2000);
                driver.findElement(By.id("ids0")).click();
                driver.findElement(By.xpath("//div[3]/input")).click();
                Thread.sleep(1000);
                driver.findElement(By.id("td0_8")).clear();
                driver.findElement(By.id("td0_8")).sendKeys("1000");
                driver.findElement(By.name("save")).click();
                Thread.sleep(2000);
            }
            return true;
        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, "Products Creation failed " + oException.toString());
            return false;
        }
    }
 ///////////////////////////////////End fCreateProducts ///////////////////////////////////////////////////

        //////////////////////////// Create products  ///////////////////////////////
        public boolean fLine_EntryForMultipleProducts()
        {      int iCount =50;
            //boolean bResult;
            int tr =5;
            String td ="";
            try
            {
                for ( int iTemp = 1; iTemp <= iCount; iTemp++)
                {
                   // Thread.sleep(2000);
                // Entering amount and quantity
                    driver.findElement(By.xpath("//tr["+tr+"]/td/input")).clear();
                    driver.findElement(By.xpath("//tr["+tr+"]/td/input")).sendKeys("1");
                    driver.findElement(By.xpath("//"+td+"td[2]/input")).clear();
                    driver.findElement(By.xpath("//"+td+"td[2]/input")).sendKeys("1000");
                     tr = tr+4;
                     td =  "tr["+tr+"]/";
                }
                return true;
            }
            catch(Exception oException)
            {
                fLogMessage(0, sGLTestCaseName, "Products Creation failed " + oException.toString());
                return false;
            }
        }
        ///////////////////////////////////End fCreateProducts ///////////////////////////////////////////////////
        //////////////////////////// Create products  ///////////////////////////////
        public boolean fMultiplePosting()
        {      int iCount =3;
            int iTemp,iRecordSetCount ;
            boolean bResult;

            try
            {
                for (  iTemp = 1; iTemp <= iCount; iTemp++)
                {
                    bResult = fMenuSelection("Opportunities");
                    if (!bResult)
                        return false;
                    // Call Line_Entry function to Enter line items in transaction
                    oResultSet.first();
                    iGLIterationNumber = 0;
                    oResultSet.last();
                    iRecordSetCount = oResultSet.getRow();
                    oResultSet.first();
                    for (iTemp = 0; iTemp < iRecordSetCount; iTemp++)
                    {
                        // sGLTaxCodeForMultipleLines = oResultSet.getString("TaxCodeForTwoLines");
                        sGLProductType  = oResultSet.getString("TaxCodeMapping");
                        sGLAmount = oResultSet.getString("Amount");
                        //sGLProductType  = oResultSet.getString("TaxCodeMapping");

                        if (sGLProductType.equalsIgnoreCase("1"))
                            //    if (sGLProductType=="1")
                            sGLItemCode = sGLItem1Code;
                        else if (sGLProductType.equalsIgnoreCase("2"))
                            // else   if (sGLProductType=="2")
                            sGLItemCode = sGLItem3Code;
                        else
                            sGLItemCode =    sGLItem2Code;

                        //Enter data in Line Tab
                        bResult = fLine_Entry("Opportunities");
                        if (!bResult)
                            return false;
                        iGLIterationNumber = iGLIterationNumber + 1;
                        oResultSet.next();
                    }
                    bResult = fMenuSelection("Create Billing");
                    if (!bResult)
                        return false;
                }
                return true;
            }
            catch(Exception oException)
            {
                fLogMessage(0, sGLTestCaseName, "Products Creation failed " + oException.toString());
                return false;
            }
        }
        ///////////////////////////////////End fCreateProducts ///////////////////////////////////////////////////

    public boolean IsElementPresent(By by)
    {
        return driver.findElements(by).size() > 0;
    }
}
// End of fVerifyValidatedAddress

/*********************************************************************************************************************
 FINISH - ACCOUNTING_SEED_FUNCTIONLIBRARY
 * *********************************************************************************************************************/
