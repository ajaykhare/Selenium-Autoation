package ACCOUNTINGSEED.TESTSCRIPTS;

import ACCOUNTINGSEED.FUNCTIONLIBRARY.FunctionLibrary_AccountingSeed;


/**
 * Created with IntelliJ IDEA.
 * User: Ajay.Khare
 * Date: 1/23/15
 * Time: 6:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class AccountingSeed_TaxCalc extends FunctionLibrary_AccountingSeed {
    public static void main(String[] args)
    {
        try
        {
            AccountingSeed_TaxCalc oTestMain = new AccountingSeed_TaxCalc();
            oTestMain.testmain();
        }
        catch(Exception oException)
        {
            System.out.println(oException.toString());
        }
    }

    public void testmain()
    {
        String sScriptName = "";
        int iCount =1;
        boolean bResult;
        bGLTaxCodeAtLinelevel = false;
        try
        {
            sGLCustomer = "Testing";
            sGLItem1Code = "GenWatt Diesel 1000kW";
            sGLItem2Code = "GenWatt Diesel 10kW";
            sGLItem3Code = "GenWatt Diesel 200kW";


            //Step 1: Browse to application URL and login
            //bResult = false;
         bResult = fStartFunction();
          if(!bResult)
               return;
            // Start Data sheet test cases execution
            for (int iTemp = 1; iTemp <= iCount; iTemp++)
            {
                sGLTestCaseName = "TestCase" + iTemp;
                fCalculateSalesTax (sGLTestCaseName);
            }
        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, oException.toString());
        }
        finally
        {
            fFinallyFunction(sScriptName);
        }
        //return;
    }
}
