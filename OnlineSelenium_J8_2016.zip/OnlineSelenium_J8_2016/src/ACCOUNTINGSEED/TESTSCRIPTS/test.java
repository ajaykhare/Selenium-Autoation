package ACCOUNTINGSEED.TESTSCRIPTS;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

/**
 * Created with IntelliJ IDEA.
 * User: Ajay.khare
 * Date: 3/10/16
 * Time: 11:43 AM
 * To change this template use File | Settings | File Templates.
 */
public class test {

    public static void main (String a[]){
        System.out.println("sdfsdf");

        System.setProperty("webdriver.ie.driver", "D:\\Selenium RC Working\\ie\\IEDriverServer.exe");
       WebDriver driver = new InternetExplorerDriver();

       // WebDriver wb = new FirefoxDriver();
        driver.get("http://google.com");
    }



}
