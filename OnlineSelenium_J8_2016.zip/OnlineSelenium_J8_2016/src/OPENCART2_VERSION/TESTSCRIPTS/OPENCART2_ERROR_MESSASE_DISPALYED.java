package OPENCART2_VERSION.TESTSCRIPTS;

import OPENCART2_VERSION.FUNCTIONLIBRARY.OPENCART2_FUNCTIONLIBRARY;

/**
 * Created with IntelliJ IDEA.
 * User: Ajay.Khare
 * Date: 3/26/15
 * Time: 3:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class OPENCART2_ERROR_MESSASE_DISPALYED extends OPENCART2_FUNCTIONLIBRARY {
    public static void main(String[] args) {

        try
        {
            OPENCART2_ERROR_MESSASE_DISPALYED oTestMain = new OPENCART2_ERROR_MESSASE_DISPALYED();
            oTestMain.testmain();
        }
        catch(Exception oException)
        {
            System.out.println(oException.toString());
        }
    }

    public void testmain()
    {

        String sScriptName = "";

        boolean bResult;
        bGLTaxCodeAtLinelevel = false;
        try
        {
            //  sGLCustomer = "Testing";

            // Step 1: Browse to application URL and login
            bResult = fStartFunction();
            if(!bResult)
                return;
            // Start Data sheet test cases execution
            int iCount =91;
            for (int iTemp = 90; iTemp <= iCount; iTemp++)
            {
                sGLTestCaseName = "TestCase" + iTemp;
                fCalculateSalesTax (sGLTestCaseName);

            }

        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, oException.toString());
        }
        finally
        {
            fFinallyFunction(sScriptName);
        }

    }
}

