package OPENCART2_VERSION.TESTSCRIPTS;

import OPENCART2_VERSION.FUNCTIONLIBRARY.OPENCART2_FUNCTIONLIBRARY;

/**
 * Created with IntelliJ IDEA.
 * User: Ajay.khare
 * Date: 2/20/15
 * Time: 11:35 AM
 * To change this template use File | Settings | File Templates.
 */
public class OPENCART2_TAXCODE extends OPENCART2_FUNCTIONLIBRARY {
    public static void main(String[] args) {

        try
        {
            OPENCART2_TAXCODE oTestMain = new OPENCART2_TAXCODE();
            oTestMain.testmain();
        }
        catch(Exception oException)
        {
            System.out.println(oException.toString());
        }
    }

    public void testmain()
    {

        String sScriptName = "";

        boolean bResult;
        bGLTaxCodeAtLinelevel = false;
        try
        {
            //  sGLCustomer = "Testing";

            // Step 1: Browse to application URL and login
           bResult = fStartFunction();
            if(!bResult)
                return;
            // Start Data sheet test cases execution
            int iCount =42;
            for (int iTemp = 42; iTemp <= iCount; iTemp++)
            {
                sGLTestCaseName = "TestCase" + iTemp;
                fCalculateSalesTax (sGLTestCaseName);

            }

        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, oException.toString());
        }
        finally
        {
            fFinallyFunction(sScriptName);
        }

    }
}

