package OPENCART2_VERSION.FUNCTIONLIBRARY;

import GLOBALLIBRARY.GenericFunctions;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.net.InetAddress;
import java.util.concurrent.TimeUnit;

/**
 * Created with IntelliJ IDEA.
 * User: Ajay.khare
 * Date: 2/20/15
 * Time: 11:28 AM
 * To change this template use File | Settings | File Templates.
 */
public class OPENCART2_FUNCTIONLIBRARY extends GenericFunctions {
    public String sGLTestCaseName;
    //public GENERIC_FUNCTION oGenericFunctions;
    public static String sCust = "";
    public static int iRecordSetCount1=0  ;

    /**
     * Description   : Function To Initialize
     * Function to Start application in the New browser session
     */
    public boolean fStartFunction()
    {
        boolean bResult;
        try
        {
            //Get Script Name to store it in the temporary results  for reporting purpose
            sGLTestCaseName = "";
            String qualifiedClassName = new Exception().getStackTrace()[1].getClassName();
            //if (sGLScriptName.equalsIgnoreCase(""))
            sGLScriptName = qualifiedClassName.substring(qualifiedClassName.lastIndexOf('.') + 1, qualifiedClassName.length());
            //Get Machine Name to append the temporary logs file name
            if (sGLMachineName.equalsIgnoreCase(""))
                sGLMachineName = InetAddress.getLocalHost().getHostName();
            //Below function opens new browser With application URL and process with login


          bResult = fLogin_OpenCart();

           bResult=  fLine_EntryForMultipleProducts();


           // bResult = fLogin_Opencart_Admin();
          //  return bResult;
            //  bResult =  fCreateProducts();
               if(!bResult)
                return false;
            return bResult;

        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, "Start Block: " + oException.toString());
            return false;
        }
    } // End fStartFunction

    /**************************************************************************************************/
    /**
     * Description   : Function To close all DB connection.
     **************************************************************************************************/
    public void fFinallyFunction(String sScriptName)
    {
        try
        {
            // Close connection if already open.
            if (oConnection != null ) //&& oConnection.isClosed() == false
                if(!oConnection.isClosed())
                    oConnection.close();
            oConnection = null;
        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, "Finally Block: " + oException.toString());
        }
        sGLTestCaseName = sScriptName;
        fLogMessage(1 , sGLTestCaseName, "Script Ended.");
    }
    // End fFinallyFunction
    /** Description   : Function to login OpenCart web application
     * @return boolean : true if Application is logged successfully, false otherwise
    **/

    public boolean fLogin_OpenCart() throws Exception
    {
        try
        {
            // Open Opencart product page
            //  driver.get("http://localhost/opencart156/");      //opencart156testing
            driver.get("http://localhost/opencart2.0.0.0/");
            driver.manage().window().maximize();
            // selenium.open("http://av-pn-kharea:88/opencart");

            ExecutionDelay (2);
            // Verify Login Successful Or not
            if(IsElementPresent(By.xpath("//div[@id='top-links']/ul/li[4]/a/span"))) //Shopping cart
            {
                fLogMessage(1,sGLTestCaseName,"OpenCart application is open successfully.");
                ExecutionDelay (10);
                return true;
            }
            else
            {
                fLogMessage(1,sGLTestCaseName,"OpenCart application is not open successfully.");
                return false;
            }
        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fLoginException:" + oException.toString());
            return false;
        }
    }// End fLogin_OpenCart

    /**********************************************************************
     // Function for Shopping Cart for Automation data sheet test cases
     ************************************************************************/
    public boolean fCalculateSalesTax(String sUniqueID) throws Exception
    {
        String sQuery;
        int iRecordSetCount;
        boolean bResult;
        try
        {

            fLogMessage(1,sGLTestCaseName,"Tax Calculation for Test case: " + sUniqueID + " Started");//. Line Tax Code flag(bGLTaxCodeAtLinelevel):" + bGLTaxCodeAtLinelevel);
            // Connect to excel sheet
            sQuery = "Select * From [AutomationTaxCalculation$] where  UniqueID = '" + sUniqueID + "'";
            oResultSet = fGetRecordSet(sGLDataPoolTaxFilePath, sQuery);
            if (oResultSet == null)
                fLogMessage(0,sGLTestCaseName,"Unable to connect to excel sheet");
            oResultSet.last();
            iRecordSetCount = oResultSet.getRow();
            iRecordSetCount1=iRecordSetCount ;
            oResultSet.first();

            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            // Get Flag value from Data sheet
            sGLEnableTaxCalculation = oResultSet.getString("EnableTaxCalculationFlag");
            //sGLadmin = oResultSet.getString("AdminFlag");
            sGLHistoryCommitFlag = oResultSet.getString("HistoryCommit");
            sGLreturnOrderFlag = oResultSet.getString("ReturnOrder");
            sGLTotalTax = oResultSet.getString("TotalTax");
            sGLShiptoAddress_Line1 = oResultSet.getString("ShiptoAddress_Line1");
            sGLShiptoAddress_City = oResultSet.getString("ShiptoAddress_City");
            sGLShiptoAddress_State = oResultSet.getString("ShiptoAddress_State");
            sGLShiptoAddress_Zip = oResultSet.getString("ShiptoAddress_Zip");
            sGLShipToCountryCode = oResultSet.getString("ShiptoAddress_Country");
            sGLErrorMessageDisplayed       = oResultSet.getString("ErrorMessageStatus");  ///TestCasesIteration   //sGLTestCasesIteration
            sGLTestCasesIteration       = oResultSet.getString("TestCasesIteration");       //sGLTaxCalculation
            sGLRecheckTaxCalculation       = oResultSet.getString("RecheckTaxCalculation");
            sGLDisableTaxCalc       = oResultSet.getString("DisableTaxCalc");
            sGLEnableShippingCharges       = oResultSet.getString("EnableShippingCharges");  //sGLEnableSalesOrder
            sGLEnableSalesOrder       = oResultSet.getString("EnableSalesOrder");
            // sGLCustomer = oResultSet.getString("sCustName");
            // oResultSet.close();
            // ExecutionDelay (15);
            // Config setting at Open Cart admin UI
            bResult = fAdminSetting();
            if (!bResult)
                return false;
            ExecutionDelay (6);
            // Open Opencart product page
            bResult = fLogin_OpenCart();
            if (!bResult)
                return false;
            ExecutionDelay (10);
           /*
            if (sGLTestCasesIteration != null)
            {   ExecutionDelay (4);
                driver.findElement(By.linkText("Logout")).click();
                ExecutionDelay (10);
                driver.findElement(By.xpath("//img")).click();
                ExecutionDelay (10);
            }
            */
            // Go to Menu selection function and select StoreCart option for transaction
            bResult= fMenuSelection  ("StoreCart");
            if (!bResult)
                return false;
            // Verifying Tax at StoreCart
            bResult=  fVerifyTaxValues ("StoreCart");
            if (!bResult)
                return false;
            // Calling  fLogin_Opencart_Admin for opening the OpenCart Admin
            bResult= fLogin_Opencart_Admin();
            if (!bResult)
                return false;
            // Go to Menu selection function and select AdminCart option for transaction
            bResult= fMenuSelection  ("AdminCart");
            if (!bResult)
                return false;
            // Verifying Tax at AdminCart
            bResult=  fVerifyTaxValues ("AdminCart");
            if (!bResult)
                return false;
            // Verifying Status
            bResult = fVerifyStatusAndTaxOnWindow("AdminCart", 1);
            if (!bResult)
                return false;
        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fCalculateSalesTax: Exception: " + oException.toString());
        }
        return true;
    }

    // End of fCalculateSalesTax
    public boolean fMenuSelection(String sMenu) throws Exception
    {
        boolean bResult;
        int iTemp,iRecordSetCount;
        String sConfirmPassword = "admin";
        String sPassword = "admin";
        String sQuery = null;


        // String [] sExpectedSalesTax = new String[5];
        String sCustEmailID = fRamdomString (6);
        String sCustName = "";
        String sCustLastName = fRamdomString (4);
        String sCustPhoneNumber =  "1234567890";// fRamdomInteger (10);  //
        try {
            ExecutionDelay (4);
            if(sMenu.equalsIgnoreCase("StoreCart"))
            {
                // sGLItem1Code = "//div[@id='content']/div[2]/div[2]/div/div[5]/div[4]/input";  //  Sony VAIO
                // sGLItem2Code = "//div[@id='content']/div[2]/div[2]/div/div/div[4]/input";     // MacBook
                // sGLItem3Code = "//div[@id='content']/div[2]/div[2]/div/div[2]/div[4]/input";  // iPhone

                sGLItem1Code = "Sony VAIO";
                sGLItem2Code = "MacBook";
                sGLItem3Code = "iPhone";
                sCustName = fRamdomString (5);
                sCust = sCustName;

                //  oResultSet = fGetRecordSet(sGLDataPoolTaxFilePath, sQuery);
                // oResultSet.last();
                // iRecordSetCount = oResultSet.getRow();
                //  oResultSet.first();
                iGLIterationNumber = 0;
                for (iTemp = 0; iTemp < iRecordSetCount1; iTemp++)
                {
                    sGLProductType  = oResultSet.getString("TaxCodeMapping");
                    if (sGLProductType.equalsIgnoreCase("Null") || sGLProductType.equalsIgnoreCase("NonTaxable"))
                        sGLItemCode =    sGLItem1Code;

                    else
                    {
                        if (sGLProductType.equalsIgnoreCase("xyz"))
                            sGLItemCode = sGLItem2Code;
                        else if (sGLProductType.equalsIgnoreCase("NT"))
                            sGLItemCode = sGLItem3Code;
                    }
                    //Enter data in Line Tab
                    ExecutionDelay (10);
                    // Searching items
                    driver.findElement(By.name("search")).click();
                    driver.findElement(By.name("search")).clear();
                    driver.findElement(By.name("search")).sendKeys(sGLItemCode);    // Entering item in search field
                    driver.findElement(By.xpath("//div[@id='search']/span/button")).click(); // Clicking on searching button
                    Thread.sleep(500);
                    driver.findElement(By.xpath("//div[@id='content']/div[4]/div/div/div[3]/button")).click();  //  Clicking on Add to cart
                    ExecutionDelay (5);
                    // selenium.click(sGLItemCode);
                    iGLIterationNumber = iGLIterationNumber + 1;
                    oResultSet.next();
                }
                iGLIterationNumber = 0;
                oResultSet.first();
                ExecutionDelay (10);
                //Thread.sleep(1000);
                // selenium.waitForPageToLoad(sGL_MAX_WAIT_TIME_IN_MS);
                driver.findElement(By.xpath("//div[@id='top-links']/ul/li[5]/a/span")).click(); // Clicking on check out
                ExecutionDelay (10);
                driver.findElement(By.xpath("//div[@id='collapse-checkout-option']/div/div/div/div[2]/label/input")).click(); // Guest option
                driver.findElement(By.id("button-account")).click();
                ExecutionDelay (10);
                // Register Customer
                /*
                driver.findElement(By.id("input-payment-firstname")).clear();
                driver.findElement(By.id("input-payment-firstname")).sendKeys(sCustName);
                driver.findElement(By.id("input-payment-lastname")).clear();
                driver.findElement(By.id("input-payment-lastname")).sendKeys(sCustLastName);
                driver.findElement(By.id("input-payment-email")).clear();
                driver.findElement(By.id("input-payment-email")).sendKeys(sCustEmailID+"@g.com");
                driver.findElement(By.id("input-payment-telephone")).clear();
                driver.findElement(By.id("input-payment-telephone")).sendKeys(sCustPhoneNumber);
                driver.findElement(By.id("input-payment-password")).clear();
                driver.findElement(By.id("input-payment-password")).sendKeys(sPassword);
                driver.findElement(By.id("input-payment-confirm")).clear();
                driver.findElement(By.id("input-payment-confirm")).sendKeys(sConfirmPassword);
                driver.findElement(By.id("input-payment-address-1")).clear();
                driver.findElement(By.id("input-payment-address-1")).sendKeys(sGLShiptoAddress_Line1);
                driver.findElement(By.id("input-payment-city")).clear();
                driver.findElement(By.id("input-payment-city")).sendKeys(sGLShiptoAddress_City);
                driver.findElement(By.id("input-payment-postcode")).clear();
                driver.findElement(By.id("input-payment-postcode")).sendKeys(sGLShiptoAddress_Zip);
                new Select(driver.findElement(By.id("input-payment-zone"))).selectByVisibleText(sGLShiptoAddress_State);
                new Select(driver.findElement(By.id("input-payment-country"))).selectByVisibleText("United States");
                driver.findElement(By.name("agree")).click();
                driver.findElement(By.id("button-register")).click();
                driver.findElement(By.name("agree")).click();
                driver.findElement(By.id("button-payment-method")).click();
                 */



            // GUEST  CUSTOMER OPTION
                driver.findElement(By.id("input-payment-firstname")).clear();
                driver.findElement(By.id("input-payment-firstname")).sendKeys(sCustName);
                driver.findElement(By.id("input-payment-lastname")).clear();
                driver.findElement(By.id("input-payment-lastname")).sendKeys(sCustLastName);
                driver.findElement(By.id("input-payment-email")).clear();
                driver.findElement(By.id("input-payment-email")).sendKeys(sCustEmailID+"@g.com");
                driver.findElement(By.id("input-payment-telephone")).clear();
                driver.findElement(By.id("input-payment-telephone")).sendKeys(sCustPhoneNumber);
                driver.findElement(By.id("input-payment-address-1")).clear();
                driver.findElement(By.id("input-payment-address-1")).sendKeys(sGLShiptoAddress_Line1);
                driver.findElement(By.id("input-payment-city")).clear();
                driver.findElement(By.id("input-payment-city")).sendKeys(sGLShiptoAddress_City);
                driver.findElement(By.id("input-payment-postcode")).clear();
                driver.findElement(By.id("input-payment-postcode")).sendKeys(sGLShiptoAddress_Zip);
                new Select(driver.findElement(By.id("input-payment-zone"))).selectByVisibleText(sGLShiptoAddress_State);
                driver.findElement(By.id("button-guest")).click();
                ExecutionDelay (8);
                driver.findElement(By.id("button-shipping-method")).click();
                ExecutionDelay (8);
                driver.findElement(By.name("agree")).click();
                driver.findElement(By.id("button-payment-method")).click();


                ExecutionDelay (10);


              //  boolean TotalTax = isElementPresent(By.xpath("//tfoot/tr[2]/td[2]"));
             //   driver.findElement(By.id("button-confirm")).click();
              //////////////////////////////// Needs to add updated script ///////////////////////////////

                if(IsElementPresent(By.xpath("//div[@id='shipping-method']/div[2]/table/tbody/tr[2]/td[2]/label")) )
                {
                    driver.findElement(By.xpath("//div[2]/div[4]/div[2]/div/div/input")).click();   //id=button-shipping-method
                }
                ////////////////////////////////////////////////////////////////////////////

              //  driver.findElement(By.id("button-confirm")).click();   // Adding this in verify tax
               // driver.findElement(By.name("agree")).click(); // Agree button
               // driver.findElement(By.id("button-payment-method")).click();  // Payment button
                ExecutionDelay (10);

            }

            // ADMIN MENU OPTION
            if(sMenu.equalsIgnoreCase("AdminCart"))
            {
                sCustName = sCust;

                ExecutionDelay (10);
               driver.findElement(By.xpath("//li[@id='sale']/a/i")).click(); // Sales
                driver.findElement(By.linkText("Orders")).click();
                ExecutionDelay (8);
                driver.findElement(By.name("filter_customer")).clear();
                driver.findElement(By.name("filter_customer")).sendKeys(sCustName);
                ExecutionDelay (5);
                driver.findElement(By.id("button-filter")).click();
                ExecutionDelay (8);
                driver.findElement(By.name("selected[]")).click();
                //Verify Avalara Status
                bResult = fVerifyStatusAndTaxOnWindow("AdminCart", 2);
                if (!bResult)
                    return false;
                if (sGLHistoryCommitFlag ==null)
                {

                    driver.findElement(By.xpath("//form[@id='form-order']/div/table/tbody/tr/td[8]/a[2]")).click();
                    ExecutionDelay (10);
                  //  driver.findElement(By.linkText("2. Products")).click();
                  //  driver.findElement(By.linkText("3. Payment Details")).click();
                  //  driver.findElement(By.linkText("4. Shipping Details")).click();
                  //  driver.findElement(By.linkText("5. Totals")).click();
                    driver.findElement(By.id("button-customer")).click();
                    driver.findElement(By.id("button-refresh")).click();
                    ExecutionDelay (8);
                    driver.findElement(By.id("button-cart")).click();
                    ExecutionDelay (4);
                    driver.findElement(By.id("button-payment-address")).click();
                    driver.findElement(By.id("button-refresh")).click();
                    ExecutionDelay (8);
                    if ( sGLErrorMessageDisplayed != null)
                    {
                    driver.findElement(By.id("button-shipping-address")).click();
                    driver.findElement(By.id("button-refresh")).click();
                    ExecutionDelay (8);
                    }
                    new Select(driver.findElement(By.id("input-order-status"))).selectByVisibleText("Complete");
                    driver.findElement(By.id("button-payment-method")).click();
                    driver.findElement(By.id("button-refresh")).click();
                    ExecutionDelay (8);
                    driver.findElement(By.id("button-save")).click();


                    /*
                    driver.findElement(By.linkText("Edit")).click();
                    ExecutionDelay (10);
                    driver.findElement(By.linkText("Totals")).click();
                    new Select(driver.findElement(By.name("order_status_id"))).selectByVisibleText("Complete");
                    */
                }
                else{
                    /*
                    driver.findElement(By.xpath("//form[@id='form-order']/div/table/tbody/tr/td[8]/a")).click();
                    ExecutionDelay (10);
                    driver.findElement(By.linkText("History")).click();
                    new Select(driver.findElement(By.id("input-order-status"))).selectByVisibleText("Complete");
                    driver.findElement(By.id("button-history")).click();
                    driver.findElement(By.xpath("//div[2]/ul/li[3]/a")).click();  // Product tab
                   */



                    driver.findElement(By.xpath("//form[@id='form-order']/div/table/tbody/tr/td[8]/a/i")).click();
                    ExecutionDelay (10);
                    driver.findElement(By.linkText("Payment Details")).click();
                    driver.findElement(By.xpath("//div[2]/ul/li[3]/a")).click();
                    driver.findElement(By.linkText("History")).click();
                    new Select(driver.findElement(By.id("input-order-status"))).selectByVisibleText("Complete");
                    driver.findElement(By.id("button-history")).click();
                    /*
                    driver.findElement(By.linkText("View")).click();
                    ExecutionDelay (10);
                    driver.findElement(By.linkText("History")).click();
                    new Select(driver.findElement(By.name("order_status_id"))).selectByVisibleText("Complete");
                    ExecutionDelay (2);
                    driver.findElement(By.id("button-history")).click();
                    ExecutionDelay (5);
                    driver.findElement(By.xpath("//a[4]")).click();  // Product Tab
                    */
                }
            }
            ExecutionDelay (10);
            return true;
        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fCalculateSalesTax: Exception: " + oException.toString());
            return false;
        }
    }

    /**************************************************************
    ** fLogin_Opencart_Admin - FUNCTION FOR LOGIN OPEN CART ADMIN
    ***************************************************************/
    public boolean fLogin_Opencart_Admin() throws Exception
    {
        // OPEN CART LOGIN CREDENTIALS
        String sUsername = "admin";
        String sPassword = "admin";
        try
        {
            //Opening Opencart admin URL
            //selenium.open("http://localhost:88/opencart1551/admin");
            driver.get("http://localhost/opencart2.0.0.0/admin/");
            driver.manage().window().maximize();
            ExecutionDelay (10);
            // Enter credentials for Admin
            driver.findElement(By.id("input-username")).clear();
            driver.findElement(By.id("input-username")).sendKeys(sUsername);
           // driver.findElement(By.name("password")).clear();
           // driver.findElement(By.name("password")).sendKeys("");
            driver.findElement(By.id("input-password")).clear();
            driver.findElement(By.id("input-password")).sendKeys(sPassword);
            driver.findElement(By.xpath("//div[@id='content']/div/div/div/div/div[2]/form/div[3]/button")).click();  // Clicking on login button
            ExecutionDelay (14);
        // VERIFYING LOGIN SUCCESSFUL OR NOT
            if(IsElementPresent(By.xpath("//header[@id='header']/div/a[2]/img")))
            {
                fLogMessage(1,sGLTestCaseName,"Logging into OpenCartAdmin application is successful.");
                ExecutionDelay (8);
                return true;
            }
            else
            {
                fLogMessage(1,sGLTestCaseName,"Logging into OpenCartAdmin application is Failed.");
                return false;
            }
        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fLoginException:" + oException.toString());
            return false;
        }

    }
    /**************************************************
     ** fVerifyTaxValues - FUNCTION FOR VERIFYING TAX
    **************************************************/

    public boolean fVerifyTaxValues(String sMenuOption) throws Exception
    {
        String sSalesTax;
        String [] sExpectedSalesTax;// = new String[0];
        String  sTaxID = null;
        String sOrderID1;
        String  sOrderID;
        String  sErrorMessage ;
        //String[] sOnScreenOrderID = null;

        String sCaptcha;
        Thread.sleep(1000);
        ExecutionDelay (10);
        if ( sGLErrorMessageDisplayed != null)
        {   if(sMenuOption.equalsIgnoreCase("StoreCart"))
        {
            sErrorMessage = "//div[4]/div[2]/div/div";
            sErrorMessage=  driver.findElement(By.xpath(sErrorMessage)).getText();
            sErrorMessage = sErrorMessage.replaceAll("\\n"," ");
            fLogMessage(1,sGLTestCaseName,"Error message appeared as " + sErrorMessage );
        }
        else
        {
            if (sGLHistoryCommitFlag !=null)
            {
                sErrorMessage=  driver.findElement(By.xpath("//div[4]/div")).getText();
            fLogMessage(1,sGLTestCaseName,"Error message appeared as " + sErrorMessage );
            }
           else
            {
                sErrorMessage = "Invalid Address for Open  Cart Admin Admin";
                fLogMessage(1,sGLTestCaseName,"Errosr message appeared as " + sErrorMessage );
            }
                driver.findElement(By.linkText("Save")).click();
        }
        }
        else
        {
            if(sMenuOption.equalsIgnoreCase("StoreCart"))       //$$$$$$$
            {
                if(IsElementPresent(By.xpath("//div[@id='shipping-method']/div[2]/table/tbody/tr[2]/td[2]/label")) )  // Flat shipping rate
                {
                    sTaxID = driver.findElement(By.xpath("//div[@id='confirm']/div[2]/div/table/tfoot/tr[3]/td[2]")).getText();
                    if (sGLDisableTaxCalc !=null)
                    {
                        sTaxID = sTaxID.replaceAll(",","");

                        // sTaxID=sTaxID.substring(0,1)+","+sTaxID.substring(1,sTaxID.length()-1);
                    }
                }
                else
                {
                    Thread.sleep(2000);
                    sTaxID = driver.findElement(By.xpath("//tr[3]/td[2]")).getText();
                    Thread.sleep(1000);
                    if (sGLDisableTaxCalc !=null)
                    {
                        sTaxID = sTaxID.replaceAll(",","");
                        // sTaxID=sTaxID.substring(0,1)+","+sTaxID.substring(1,sTaxID.length()-1);

                    }
                }

            }
            else if(sMenuOption.equalsIgnoreCase("AdminCart"))
            {
                if (sGLHistoryCommitFlag ==null)
                {
                    sTaxID = driver.findElement(By.xpath("//div[4]/table/tbody/tr[4]/td[2]")).getText();
                    sTaxID = "$"+sTaxID;
                    sGLTotalTax = sGLTotalTax +"00";
                    driver.findElement(By.linkText("Save")).click();
                }
                else {
                    driver.findElement(By.xpath("//div[2]/ul/li[4]/a")).click();
                    Thread.sleep(1000);

                    sTaxID =  driver.findElement(By.xpath("//div[4]/table/tbody/tr[4]/td[2]")).getText();
                    //Mutliple Tax code
                    sGLTaxCodeForMultipleLines  = oResultSet.getString("MultipleTaxCode");
                    if (sGLTaxCodeForMultipleLines.equalsIgnoreCase("1"));
                    {
                        sTaxID =  driver.findElement(By.xpath("//div[4]/table/tbody/tr[5]/td[2]")).getText();
                    }

                    // sTaxID = "1000";
                    if (sGLDisableTaxCalc !=null)
                    {
                        sTaxID = sTaxID.replaceAll(",","");

                        // sTaxID=sTaxID.substring(0,1)+","+sTaxID.substring(1,sTaxID.length()-1);

                    }
                }
            }

            sSalesTax =  sTaxID;
            sExpectedSalesTax = sSalesTax.split("\\$");
            sGLTotalTax = sGLTotalTax.trim();
            if (sExpectedSalesTax[1].equalsIgnoreCase(sGLTotalTax))
                fLogMessage(1,sGLTestCaseName,"'Total Sales Tax' " + sGLTotalTax + " verified successfully for Test case " +sGLTestCaseName
                        + " on "  + sMenuOption + " Window.");
            else
            {
                fLogMessage(0,sGLTestCaseName,"'Total Sales Tax' " + sGLTotalTax + " NOT verified successfully for Test case" +sGLTestCaseName
                        + " on " + sMenuOption + " Window.Expected Tax :- " + sGLTotalTax + " and Actual Tax:- " + sExpectedSalesTax[1]);
                return false;
            }
        }
        if(sMenuOption.equalsIgnoreCase("StoreCart"))
        {
            ExecutionDelay (10);
            driver.findElement(By.id("button-confirm")).click();
            // selenium.click("id=button-confirm");
            ExecutionDelay (10);
            if (sGLreturnOrderFlag !=null)
            {
                driver.findElement(By.linkText("history")).click();
                ExecutionDelay (10);
                // sOrderID =   "//div[@id='content']/div[2]/div";
                sOrderID1=driver.findElement(By.xpath("//div[@id='content']/div[2]/div")).getText();
                // sOrderID1=selenium.getText("//div[@id='content']/div[2]/div");

                sOrderID = sOrderID1.replaceAll("[^0-9]", "");
                //sOnScreenOrderID = sOnScreenOrderID.split("\\Order ID: #");
                driver.findElement(By.xpath("//a[contains(text(),'Returns')])[2]")).click();
                ExecutionDelay (10);
                driver.findElement(By.name("order_id")).sendKeys(sOrderID);
                driver.findElement(By.name("product")).sendKeys("MacBook");
                driver.findElement(By.name("model")).sendKeys("Product 16");
                driver.findElement(By.id("return-reason-id3]")).click();
                // Captcha
                sCaptcha= driver.findElement(By.xpath("//div[3]/img")).getText();
                driver.findElement(By.name("captcha")).clear();
                driver.findElement(By.name("captcha")).sendKeys(sCaptcha);
                driver.findElement(By.xpath("//div[3]/div[2]/input")).click(); // Continue return order
                ExecutionDelay (10);
            }

        }
        return true;
    }

    /************************************************************************
    // fVerifyStatusAndTaxOnWindow- FUNCTION FOR VERIFYING TRANSACTION STATUS
    *************************************************************************/

    boolean fVerifyStatusAndTaxOnWindow(String sMenuOption , int iClickOption)
    {
        String sOnscreenAvalaraStatus,sStatusID = null;
        String sCustName= sCust;

        if(sMenuOption.equalsIgnoreCase("AdminCart"))
        {
            if (iClickOption == 1)
            {
              //  driver.findElement(By.linkText("Sales")).click();
                driver.findElement(By.linkText("Orders")).click();
                ExecutionDelay (10);
                driver.findElement(By.name("filter_customer")).sendKeys(sCustName);
                ExecutionDelay (4);
               // driver.findElement(By.linkText("Filter")).click();
                ExecutionDelay (5);
                sGLAvalaraDocStatus = "Complete";
            }
            else
            {
                sGLAvalaraDocStatus = "Pending";
                // sStatusID="//form[@id='form']/table/tbody/tr[2]/td[4]";
            }
        }
        sStatusID="//tbody/tr/td[4]";
        sOnscreenAvalaraStatus = driver.findElement(By.xpath(sStatusID)).getText();

        if (sOnscreenAvalaraStatus.equalsIgnoreCase(sGLAvalaraDocStatus))
            fLogMessage(1,sGLTestCaseName,"Avalara Status ' " + sGLAvalaraDocStatus + "' verified successfully on Calculate for Test case " +sGLTestCaseName
                    + " On tax calculation on " + sMenuOption + " Window ");
        else
        {
            fLogMessage(0,sGLTestCaseName,"Avalara Status ' " + sGLAvalaraDocStatus + " ' NOT verified successfully on Calculate for Test case " +sGLTestCaseName
                    + " On tax calculation for on " + sMenuOption + " Window " + "Expected : " + sGLAvalaraDocStatus + " and Actual: "+ sOnscreenAvalaraStatus);
            return false;
        }
        // FOR DISABLE TAX CALCULATION TEST CASES
        if(sMenuOption.equalsIgnoreCase("AdminCart") &&  sGLEnableTaxCalculation == null)
        {
            //driver.findElement(By.linkText("System")).click();
           // ExecutionDelay (4);
            driver.findElement(By.linkText("Settings")).click();
            ExecutionDelay (10);
            driver.findElement(By.xpath("//td[4]/a")).click();   //Edit
            ExecutionDelay (10);
            driver.findElement(By.linkText("Option")).click();

            driver.findElement(By.id("config_avatax_tax_calculation_no")).click();
            driver.findElement(By.linkText("Save")).click();
            ExecutionDelay (10);
        }
        if  (sMenuOption.equalsIgnoreCase("AdminCart") && sGLRecheckTaxCalculation != null)
        {
          //  driver.findElement(By.linkText("System")).click();
            driver.findElement(By.linkText("Settings")).click();
            ExecutionDelay (8);
            driver.findElement(By.xpath("//td[4]/a")).click();   //Edit
            ExecutionDelay (8);
            driver.findElement(By.linkText("Option")).click();
            //if(driver.findElement(By.id("config_avatax_tax_calculation_yes")).isSelected() )
            driver.findElement(By.id("config_avatax_tax_calculation_yes")).click();
            driver.findElement(By.linkText("Save")).click();
            ExecutionDelay (10);
        }

        return true;
    }
    /***********************************************
     *  *    fAdminSetting FOR CONFIGURATION SETTING
    ***********************************************/

    public boolean fAdminSetting() throws Exception
    {
        try{

         //CONFIGURATION SETTING
            Thread.sleep(2000);
            ExecutionDelay (8);
            driver.findElement(By.xpath("//li[@id='system']/a/i")).click();   //System
          //  ExecutionDelay (4);
            driver.findElement(By.linkText("Settings")).click();
            ExecutionDelay (10);
            driver.findElement(By.xpath("//td[4]/a")).click();   //Edit
            ExecutionDelay (8);
            driver.findElement(By.linkText("Option")).click();
            ExecutionDelay (8);

       /*     Actions actions = new Actions(driver);
           // WebElement menuElement = driver.findElement(By.id("menu-element-id"));
            WebElement menuElement = driver.findElement(By.id("config_avatax_tax_calculation_yes"));
            actions.moveToElement(menuElement).moveToElement(driver.findElement(By.xpath("//tr[5]/td[2]/input[2]"))).click();
             */
            // For disable tax calculation test case

            if( sGLEnableTaxCalculation == null)
            {

                // driver.findElement(By.id("config_avatax_tax_calculation_no")).click();

                //driver.findElement(By.xpath("//table[5]/tbody/tr[5]/td[2]/input")).click();
                WebElement element = driver.findElement(By.id("config_avatax_tax_calculation_no"));
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
                Thread.sleep(500);
                element.click();

            }
            if  (sGLEnableTaxCalculation != null)
            {
                //driver.findElement(By.id("config_avatax_tax_calculation_yes")).click();

                //  driver.findElement(By.xpath("//tr[5]/td[2]/input[2]")).click();
                WebElement element = driver.findElement(By.id("config_avatax_tax_calculation_yes"));
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
                Thread.sleep(500);
                element.click();

                //driver.getPageSource();
            }
            if( sGLEnableSalesOrder == null)
            {
                //driver.findElement(By.xpath("//tr[7]/td[2]/input[2]")).click();
                driver.findElement(By.xpath("//div[7]/div/label[2]/input")).click();
                //WebElement element = driver.findElement(By.xpath("//tr[7]/td[2]/input[2]"));
                ////  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
                //  Thread.sleep(500);
                //  element.click();

            }
            if  (sGLEnableSalesOrder != null)
            {
                // driver.findElement(By.id("config_avatax_transaction_calculation")).click();
                // driver.findElement(By.xpath("///tr[7]/td[2]/input")).click();
                WebElement element = driver.findElement(By.id("config_avatax_transaction_calculation"));
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
                Thread.sleep(500);
                element.click();
            }
        // SAVING CONFIGURATION SETTING

            WebElement element = driver.findElement(By.xpath("//div[@id='content']/div/div/div/button"));   //Save button
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
            Thread.sleep(500);
            element.click();
            ExecutionDelay (10);

        // SETTING FOR CHANGING THE SHIPPING CHARGES

            driver.findElement(By.xpath("//nav/ul/li[3]/a/i")).click();   // Extension
            ExecutionDelay (2);
            driver.findElement(By.linkText("Shipping")).click();
            ExecutionDelay (12);
            driver.findElement(By.xpath("//div[@id='content']/div[2]/div/div[2]/div/table/tbody/tr[4]/td[4]/a[2]/i")).click();   // Edit link
            ExecutionDelay (10);
            driver.findElement(By.name("flat_cost")).clear();

            if  (sGLEnableShippingCharges == null)
            {
                driver.findElement(By.name("flat_cost")).sendKeys("0");       // Enter Value
            }
            if  (sGLEnableShippingCharges != null)
            // if (sGLEnableShippingCharges.equalsIgnoreCase("NotNull"))
            {
                driver.findElement(By.name("flat_cost")).sendKeys("5");
                sGLProductType  = oResultSet.getString("TaxCodeMapping");// Enter Value
                if (sGLProductType.equalsIgnoreCase("NonTaxable"))
                    new Select(driver.findElement(By.name("flat_tax_class_id"))).selectByVisibleText("Non Taxable");
                    //new Select(driver.findElement(By.name("order_status_id"))).selectByVisibleText("Complete");
                else
                    new Select(driver.findElement(By.name("flat_tax_class_id"))).selectByVisibleText("Taxable Goods");
            }

            driver.findElement(By.xpath("//div[@id='content']/div/div/div/button")).click();     // Saving the shipping setting
            ExecutionDelay (10);

            if(IsElementPresent(By.xpath("//header[@id='header']/div/a[2]/img")))    // Open Cart Logo Image
            {
                fLogMessage(1,sGLTestCaseName,"All the OpenCart admin setting is updated successfully");
            }
            else
                fLogMessage(0,sGLTestCaseName,"All the OpenCart admin setting is not updated successfully");
            return true;
        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fUpdateSettingsException:" + oException.toString());
            return false;
        }
    }

    public boolean IsElementPresent(By by)
    {
        return driver.findElements(by).size() > 0;

    }

   ////////////// CONNECTOR MATRIX SCRIPT //////////////////////////

   ///////////////////////////CS Cart script/////////////////////
    public boolean fLine_EntryForMultipleProducts()
    {      int iCount =220;
        //boolean bResult;
        //    int tr =5;
        //    String td ="";
        boolean bResult;

        String sCustName = fRamdomString (4);

        String sCustPhoneNumber =  "1234567890";// fRamdomInteger (10);  //
        // int iTemp;
        String sCustEmailID = fRamdomString (6);
        // String sCustName ;
        String sCustLastName = fRamdomString (4);
        String  sCardNumber =  "1234567890123456";// fRamdomInt (16);
        String  sCVVNumber =  "234";
        String  sYear =  "08";
        String  sCardHolder =  fRamdomString (3);
        try
        {
            for ( int iTemp = 21; iTemp <= iCount; iTemp++)
            {
                driver.get("http://localhost/opencart2.0.0.0/index.php?route=product/search&search="+"Test"+iTemp);
               // driver.get("http://localhost/opencart2.0.0.0/index.php?route=product/product&product_id=50&search="+"Test"+iTemp);
                Thread.sleep(20000);
                driver.findElement(By.xpath("//div[4]/div/div/div/a/img")).click();
                Thread.sleep(20000);
                driver.findElement(By.id("button-cart")).click();
                Thread.sleep(20000);



            }
            driver.findElement(By.xpath("//div[@id='top-links']/ul/li[5]/a/span")).click(); // Clicking on check out
            ExecutionDelay (10);
            driver.findElement(By.xpath("//div[@id='collapse-checkout-option']/div/div/div/div[2]/label/input")).click(); // Guest option
            driver.findElement(By.id("button-account")).click();
            ExecutionDelay (10);

            // GUEST  CUSTOMER OPTION
            driver.findElement(By.id("input-payment-firstname")).clear();
            driver.findElement(By.id("input-payment-firstname")).sendKeys(sCustName);
            driver.findElement(By.id("input-payment-lastname")).clear();
            driver.findElement(By.id("input-payment-lastname")).sendKeys(sCustLastName);
            driver.findElement(By.id("input-payment-email")).clear();
            driver.findElement(By.id("input-payment-email")).sendKeys(sCustEmailID+"@g.com");
            driver.findElement(By.id("input-payment-telephone")).clear();
            driver.findElement(By.id("input-payment-telephone")).sendKeys(sCustPhoneNumber);
            driver.findElement(By.id("input-payment-address-1")).clear();
            driver.findElement(By.id("input-payment-address-1")).sendKeys("900 winslow way e");
            driver.findElement(By.id("input-payment-city")).clear();
            driver.findElement(By.id("input-payment-city")).sendKeys("Bainbridge Island");
            driver.findElement(By.id("input-payment-postcode")).clear();
            driver.findElement(By.id("input-payment-postcode")).sendKeys("98110");
            new Select(driver.findElement(By.id("input-payment-zone"))).selectByVisibleText("Washington");
            driver.findElement(By.id("button-guest")).click();
            ExecutionDelay (8);
            driver.findElement(By.id("button-shipping-method")).click();
            ExecutionDelay (8);
            driver.findElement(By.name("agree")).click();
            driver.findElement(By.id("button-payment-method")).click();


            ExecutionDelay (10);
            driver.findElement(By.id("button-confirm")).click();
            ExecutionDelay (10);



            return true;
        }

        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, "Products Creation failed " + oException.toString());
            return false;
        }



    }




    //////////////////////////// Create products  ///////////////////////////////
    public boolean fCreateProducts()
    {      int iCount =120;
        boolean bResult;
        try
        {
            for ( int iTemp = 118; iTemp <= iCount; iTemp++)
            {
                // sGLTestCaseName = "TestCase" + iTemp;
                Thread.sleep(100);
                driver.findElement(By.xpath("//li[@id='catalog']/a/i")).click();
                Thread.sleep(100);
                driver.findElement(By.linkText("Products")).click();
                Thread.sleep(5000);
                driver.findElement(By.xpath("//div/div/div/a")).click();
                Thread.sleep(5000);
                driver.findElement(By.id("input-name1")).clear();
                driver.findElement(By.id("input-name1")).sendKeys("Test"+iTemp);
                driver.findElement(By.xpath("//div[2]/div/div/div[6]")).click();
                driver.findElement(By.xpath("//div[2]/div/div/div[6]")).sendKeys("Testing Connector Matrix");
                driver.findElement(By.id("input-meta-title1")).clear();
                driver.findElement(By.id("input-meta-title1")).sendKeys("Test"+iTemp);

                driver.findElement(By.linkText("Data")).click();
                Thread.sleep(1000);
                driver.findElement(By.id("input-model")).sendKeys("Product"+iTemp);
                driver.findElement(By.id("input-price")).clear();
                driver.findElement(By.id("input-price")).sendKeys("1000");
                driver.findElement(By.id("input-quantity")).clear();
                driver.findElement(By.id("input-quantity")).sendKeys("1000");
                driver.findElement(By.xpath("//button[@type='submit']")).click();
                Thread.sleep(2000);
                ExecutionDelay (10);

            }

            return true;
        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, "Products Creation failed " + oException.toString());
            return false;
        }
    }


    ////////////// CONNECTOR MATRIX SCRIPT END//////////////////////////







}
