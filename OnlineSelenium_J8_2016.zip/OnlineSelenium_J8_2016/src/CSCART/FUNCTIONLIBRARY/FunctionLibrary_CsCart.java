package CSCART.FUNCTIONLIBRARY;

import GLOBALLIBRARY.GenericFunctions;
//import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
//import org.openqa.selenium.Keys;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.*;
//import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.firefox.*;

import java.net.InetAddress;
//import java.text.DecimalFormat;
//import java.util.concurrent.TimeUnit;


/***********************************************************************************************************************
 * Created with IntelliJ IDEA.
 * User: Ajay.Khare
 * Date: 10/27/14
 * Time: 2:06 PM
 * To change this template use File | Settings | File Templates.
 **********************************************************************************************************************/
public class FunctionLibrary_CsCart extends GenericFunctions {
    public static int iRecordSetCount1=0  ;
    public static String RMA_Store_URL = "";
    public static String sCust = "";
    public boolean fStartFunction()
    {
        boolean bResult;
        try
        {
            sGLTestCaseName = "";
            String qualifiedClassName = new Exception().getStackTrace()[1].getClassName();
            //if (sGLScriptName.equalsIgnoreCase(""))
            sGLScriptName = qualifiedClassName.substring(qualifiedClassName.lastIndexOf('.') + 1, qualifiedClassName.length());
            if (sGLMachineName.equalsIgnoreCase(""))
                sGLMachineName = InetAddress.getLocalHost().getHostName();
            //Below function opens new browser With application URL and process with login


           bResult = fLogin_CsCart();

           bResult=  fLine_EntryForMultipleProducts();

          // bResult= fLogin_CsCart_Admin("First Time Open");
           // return bResult;

             // bResult =  fCreateProducts();
              if(!bResult)
                return false;
            return bResult;
        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, "Start Block: " + oException.toString());
            return false;
        }
    } // End fStartFunction
    /*******************************************************************************************************************
     /**
     * Description   : Function To close connection.
     ******************************************************************************************************************/
    public void fFinallyFunction(String sScriptName)
    {
        try
        {
            // Close connection if already open.
            if (oConnection != null )
                if(oConnection.isClosed() == false)
                    oConnection.close();
            oConnection = null;
            iGLCalculateTax = 0;  // 0 means nothing; 1 means dont calculate tax
            iGLEnterShiptoAddressontheFly = 1;  // 0 means Select Ship to addres from drop down; 1 means Enter address Run time
            iGLMSR = 0;  // 0 means NO MSR ; 1 means MSR and enter line level ship to addresses
        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, "Finally Block: " + oException.toString());
        }
        sGLTestCaseName = sScriptName;
        fLogMessage(1 , sGLTestCaseName, "Script Ended.");
    } // End fFinallyFunction
    /*******************************************************************************************************************
     /**
     * Description   : Function to login Sales Force web application
     * @return boolean : true if Application is logged successfully, false otherwise
     ******************************************************************************************************************/
    public boolean fLogin_CsCart() throws Exception
    {
            try
            {
            // Open Cart store URL
               // driver.get("http://localhost/cscart421/");
               // driver.get("http://localhost/cscartlog/");
                driver.get("http://localhost/cscart423logreader/");
                // selenium.open("http://av-pn-kharea:88/opencart");
            //Wait for page to get load
                driver.manage().window().maximize();
                ExecutionDelay (10);
            // Verify Login Successful Or not
                if(IsElementPresent(By.xpath("//div[3]/div/div/div/a/span")))
                {
                    fLogMessage(1,sGLTestCaseName,"Logging into CsCart application is successful.");
                    return true;
                }
                else
                {
                    fLogMessage(1,sGLTestCaseName,"Logging into CsCart application is Failed.");
                    return false;
                }
        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fLoginException:" + oException.toString());
            return false;
        }
    }// End fLogin_CS Cart

    /*******************************************************************************************************************
     * Calculate Sales Tax function
     * Function for Calculate Sales Tax for Automation data sheet test cases
     ******************************************************************************************************************/
    public boolean fCalculateSalesTax(String sUniqueID)
    {
        String sQuery;
        int iRecordSetCount;
        boolean bResult;
        try
        {
            fLogMessage(1,sGLTestCaseName,"Tax Calculation for Test case: " + sUniqueID + " Started.");
        // Creating Connection  with excel sheet
            sQuery = "Select * From [AutomationTaxCalculation$] where  UniqueID = '" + sUniqueID + "'";
            oResultSet = fGetRecordSet(sGLDataPoolTaxFilePath, sQuery);
            if (oResultSet == null)
                fLogMessage(0,sGLTestCaseName,"Unable to connect to excel sheet");
        //Move to last item in record set to get the record
            oResultSet.last();
            iRecordSetCount = oResultSet.getRow();
            iRecordSetCount1=iRecordSetCount ;
            oResultSet.first();
        // Fetching data from excel sheet
            sGLTotalTax = oResultSet.getString("TotalTax");
            sGLTotalTax = sGLTotalTax.trim();
            sGLShiptoAddress_Line1 = oResultSet.getString("ShiptoAddress_Line1");
            sGLShiptoAddress_City = oResultSet.getString("ShiptoAddress_City");
            sGLShiptoAddress_State = oResultSet.getString("ShiptoAddress_State");
            sGLShiptoAddress_Zip = oResultSet.getString("ShiptoAddress_Zip");
            sGLShipToCountryCode = oResultSet.getString("ShiptoAddress_Country");
            sGLErrorMessageDisplayed       = oResultSet.getString("ErrorMessageStatus");
            sGLEnableShippingCharges       = oResultSet.getString("EnableShippingCharges");
            sGLDisableTaxCalc   = oResultSet.getString("DisableTaxCalc");
            sGLRMA   = oResultSet.getString("RMA");
            sGLDiscount =   oResultSet.getString("Discount");
            sGLEnableTaxCalculation  =   oResultSet.getString("EnableTaxCalculationFlag");
            sGLUPCCode  =   oResultSet.getString("EnableTaxCalculationFlag");
            sGLCustExemptNo  = oResultSet.getString("ExemptCustomer");
            sGLEntityUseCode  = oResultSet.getString("EnableEntity/USeCode");
            sGLSaveDoce_AvaAdmin   = oResultSet.getString("SaveTransactionAtAdmin");
            //sGLLoginAdminIteration = oResultSet.getString("EnableShippingCharges");
        // CS cart admin setting
         //  bResult = fAdminSetting();
          //  if (!bResult)
          //      return false;
           // ExecutionDelay (6);
        // Open CS cart store front
          //  bResult = fLogin_CsCart();
          //  if (!bResult)
          //      return false;


             bResult=  fLine_EntryForMultipleProducts();
            if (!bResult)
                return false;

        // Go to Menu selection function and select StoreCart option for transaction
          /*
            bResult= fMenuSelection  ("StoreCart");
            if (!bResult)
                return false;
                */
        // Calling  fLogin_Opencart_Admin for opening the OpenCart Admin
           /*
            bResult= fLogin_CsCart_Admin("Iteration");
            if (!bResult)
                return false;
                */
        // Verifying tax for trigger get tax at store front
            /*
            bResult = fVerifyStatusAndTaxOnWindow("StoreCart");
            if (!bResult)
                return false;
                */
        // Go to Menu selection function and select AdminCart option for transaction
            /*
            bResult= fMenuSelection  ("AdminCart");
            if (!bResult)
                return false;
                */
        // Verifying Status for commit transaction at Open Cart admin front
            /*
            bResult = fVerifyStatusAndTaxOnWindow("AdminCart");
            if (!bResult)
                return false;
                */
        // Go to Menu selection function and select RMA option for transaction
           /*
            bResult= fMenuSelection("RMA");
            if (!bResult)
                return false;
                */

        // Test result Log message
            fLogMessage(1,sGLTestCaseName,"Tax Calculation for Test case: " + sUniqueID + " Ended.");
        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fCalculateSalesTax: Exception: " + oException.toString());
        }
        return true;
    }
    /*******************************************************************************************************************
     * fLogin_Opencart_Admin
     * Description   : Function for Add a product for transaction

     ******************************************************************************************************************/

    public boolean fLogin_CsCart_Admin(String sMenuOption)
    {                     boolean bResult;
        // OpenCart Login Credentials
        String sUsername = "admin@admin.com";
        String sPassword = "admin";
        try
        {
         //Opening Opencart admin URL
            //driver.get("http://localhost/cscart421/admin.php");
           // driver.get("http://localhost/cscartlog/admin.php");
            driver.get("http://localhost/cscart423logreader/admin.php");
            ExecutionDelay (10);
            Thread.sleep(1000);
            driver.manage().window().maximize();
         // Enter credentials for Admin
            if(sMenuOption.equalsIgnoreCase ("First Time Open"))
            {
            driver.findElement(By.id("username")).click();
            driver.findElement(By.id("username")).clear();
            driver.findElement(By.id("username")).sendKeys(sUsername);
            driver.findElement(By.id("password")).clear();
            driver.findElement(By.id("password")).clear();
            driver.findElement(By.id("password")).sendKeys(sPassword);

         // Click on login button
            driver.findElement(By.xpath("//div[3]/input")).click();
            ExecutionDelay (10);
                Thread.sleep(1000);
            }
         // Verify Login Successful Or not
            if(IsElementPresent(By.linkText("Add-ons")))   // Home Icon
            {
                fLogMessage(1,sGLTestCaseName,"Logging into CsCartAdmin application is successful.");
                return true;
            }
            else
            {
                fLogMessage(1,sGLTestCaseName,"Logging into CsCartAdmin application is Failed.");
                return false;
            }

        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fLoginException:" + oException.toString());
            return false;
        }
    }
    /*******************************************************************************************************************
     * fMenuSelection
     * Description   : Function for selecting the store and admin front transactions

     ******************************************************************************************************************/

    public boolean fMenuSelection(String sMenu) throws Exception
    {
        boolean bResult;
        int iTemp;
        String sCustEmailID = fRamdomString (6);
        String sCustName ;
        String sCustLastName = fRamdomString (4);
        String  sCardNumber =  "1234567890123456";// fRamdomInt (16);
        String  sCVVNumber =  "234";
        String  sYear =  "08";
        String  sCardHolder =  fRamdomString (3);
        try {
            if(sMenu.equalsIgnoreCase("StoreCart"))
            {      ExecutionDelay (10);
                sGLItem1Code = "//form/div/div/div/div/div/div/div/a/img";  //  16GB A Series Walkman Video MP3
                sGLItem2Code = "//div/form/div/a/img";     // 18-55mm Portrait Lens
                sGLItem3Code = "//div[3]/div/form/div/div/div/div/div/div/div/a/img"; // 3D Blu-ray Disc™ Player (BD-D7000)
                sCustName = fRamdomString (5);
                sCust = sCustName;
                iGLIterationNumber = 0;
                for (iTemp = 0; iTemp < iRecordSetCount1; iTemp++)
                {
                    sGLProductType  = oResultSet.getString("TaxCodeMapping");

                        if (sGLProductType.equalsIgnoreCase("xyz"))
                            sGLItemCode = sGLItem2Code;
                        else if (sGLProductType.equalsIgnoreCase("NT"))
                            sGLItemCode = sGLItem3Code;
                        else
                            sGLItemCode =    sGLItem1Code;
                 //Enter data in Line Tab
                    driver.findElement(By.linkText("Electronics")).click();
                    ExecutionDelay (20);
                    driver.findElement(By.xpath(sGLItemCode)).click();
                    ExecutionDelay (20);
                    if (sGLItemCode.equals(sGLItem1Code))
                        driver.findElement(By.id("button_cart_148")).click();
                    if (sGLItemCode.equals(sGLItem2Code))
                        driver.findElement(By.id("button_cart_180")).click();
                    if (sGLItemCode.equals(sGLItem3Code))
                        driver.findElement(By.id("button_cart_18")).click();
                    ExecutionDelay (15);
                    iGLIterationNumber = iGLIterationNumber + 1;
                    oResultSet.next();
                }
                iGLIterationNumber = 0;
                oResultSet.first();
                ExecutionDelay (5);

                // driver.findElement(By.id("sw_dropdown_5")).click();
                driver.findElement(By.xpath("//div[3]/div/div/div")).click();
                driver.findElement(By.linkText("Checkout")).click();

                // Existing Customer
                if(IsElementPresent(By.xpath("//div[3]/div/h2/span")))
                {
                    driver.findElement(By.xpath("//span[2]/a")).click();     // Customer Change Button
                    driver.findElement(By.linkText("Sign in as a different user")).click();
                }
               // Register User
                if (sGLCustExemptNo !=null ||  sGLEntityUseCode !=null)
                {
                    driver.findElement(By.id("checkout_type_register")).click();
                    driver.findElement(By.id("login_checkout_login")).clear();
                    driver.findElement(By.id("login_checkout_login")).sendKeys("awa@awa.com");
                    driver.findElement(By.id("psw_checkout_login")).clear();
                    driver.findElement(By.id("psw_checkout_login")).sendKeys("kennwort");
                    driver.findElement(By.xpath("//div[2]/div/button")).click();
                }

                // Guest Customer
                else
                {
                driver.findElement(By.id("checkout_type_guest")).click();
                driver.findElement(By.xpath("//div[3]/form/div/button")).click();
                ExecutionDelay (8);
                driver.findElement(By.xpath("//div[2]/div/div/div/input")).clear();
                driver.findElement(By.xpath("//div[2]/div/div/div/input")).sendKeys(sCustName);
                driver.findElement(By.xpath("//div/div/div[2]/input")).clear();
                driver.findElement(By.xpath("//div/div/div[2]/input")).sendKeys(sCustLastName);
                driver.findElement(By.xpath("//div/div/div[3]/input")).clear();
                driver.findElement(By.xpath("//div/div/div[3]/input")).sendKeys(sCustEmailID+"@cscart.com");
                driver.findElement(By.xpath("//div[5]/input")).clear();
                // Enter Customer Address
                driver.findElement(By.xpath("//div[5]/input")).sendKeys(sGLShiptoAddress_Line1);
                driver.findElement(By.xpath("//div[7]/input")).clear();
                driver.findElement(By.xpath("//div[7]/input")).sendKeys(sGLShiptoAddress_City);
                new Select(driver.findElement(By.xpath("//div[9]/select"))).selectByVisibleText("Florida");
                driver.findElement(By.xpath("//div[10]/input")).clear();
                driver.findElement(By.xpath("//div[10]/input")).sendKeys(sGLShiptoAddress_Zip);
                driver.findElement(By.xpath("//div[4]/button")).click();
                ExecutionDelay (15);
                }
               // driver.findElement(By.xpath("//div[3]/div/form/div[2]/button")).click(); // Shipping continue button
                driver.findElement(By.id("step_three_but")).click(); // Shipping continue button
                ExecutionDelay (15);
                bResult=  fVerifyTaxValues ("StoreCart");
                if (!bResult)
                    return false;
                ExecutionDelay (5);
                driver.findElement(By.id("payments_tab1")).click();
                ExecutionDelay (5);
                driver.findElement(By.id("credit_card_number_1")).clear();
                driver.findElement(By.id("credit_card_number_1")).sendKeys(sCardNumber);
                driver.findElement(By.id("credit_card_cvv2_1")).clear();
                driver.findElement(By.id("credit_card_cvv2_1")).sendKeys(sCVVNumber);
                driver.findElement(By.id("credit_card_month_1")).clear();
                driver.findElement(By.id("credit_card_month_1")).sendKeys("09");
                driver.findElement(By.id("credit_card_year_1")).clear();
                driver.findElement(By.id("credit_card_year_1")).sendKeys(sYear);
                driver.findElement(By.id("credit_card_name_1")).clear();
                driver.findElement(By.id("credit_card_name_1")).sendKeys("Ajay"+sCardHolder);
                driver.findElement(By.xpath("//div[2]/div/form/div[2]/button")).click(); // Submit Order
                ExecutionDelay (10);
                 /*
                driver.findElement(By.xpath("//div[3]/div/form/div[2]/button")).click();
                driver.findElement(By.xpath("//div[4]/div/div/div/div/ul/li")).click();
                driver.findElement(By.xpath("//div[3]/input")).clear();
                driver.findElement(By.xpath("//div[3]/input")).sendKeys("Ajay");
                driver.findElement(By.xpath("//div[2]/div/form/div[2]/button")).click();
                */
                if (sGLRMA.equalsIgnoreCase("1"))
                {
                    driver.findElement(By.linkText("Order details")).click();
                    Thread.sleep(2000);
                    ExecutionDelay (10);
                   RMA_Store_URL = driver.getCurrentUrl();
                }
            }
            //Admin Menu Option
            if(sMenu.equalsIgnoreCase("AdminCart"))
            {  ExecutionDelay (8);
                Thread.sleep(2000);
                driver.findElement(By.xpath("//div[2]/ul/li[2]/a")).click();  // Click order tab
                driver.findElement(By.xpath("//li[2]/ul/li/a/span")).click(); // Click for viewing the order
                ExecutionDelay (4);
                Thread.sleep(2000);
                driver.findElement(By.xpath("//td[2]/a")).click();  // Clicking on order
                ExecutionDelay (15);
                Thread.sleep(2000);
            }
            //RMA Menu Option- Return order and return invoices transaction
            if(sMenu.equalsIgnoreCase("RMA"))
            {  ExecutionDelay (8);
                Thread.sleep(2000);
                driver.get(RMA_Store_URL);  // Opening order details - CS cart store url
                Thread.sleep(2000);
                ExecutionDelay (8);
                driver.findElement(By.linkText("Request a replacement or a refund")).click();
                Thread.sleep(2000);
                ExecutionDelay (5);
                new Select(driver.findElement(By.name("action"))).selectByVisibleText("Refund");
                driver.findElement(By.name("check_all")).click();
                driver.findElement(By.name("dispatch[rma.add_return]")).click();
                Thread.sleep(2000);
                ExecutionDelay (10);
            // Open Open Cart Admin for completing the status
                bResult= fLogin_CsCart_Admin("Iteration");
                if (!bResult)
                    return false;
            // Go to Return order and comitting transaction
                driver.findElement(By.xpath("//div[2]/ul/li[2]/a")).click();
                Thread.sleep(2000);
                driver.findElement(By.xpath("//li[4]/a/span")).click();
                Thread.sleep(2000);
                driver.findElement(By.linkText("Return requests")).click();
                Thread.sleep(2000);
                driver.findElement(By.xpath("//td[2]/a")).click();
                Thread.sleep(2000);
                driver.findElement(By.linkText("Actions")).click();
                Thread.sleep(1000);
                new Select(driver.findElement(By.id("elm_status"))).selectByVisibleText("Completed");
                driver.findElement(By.xpath("//div[4]/div/div/input")).click();  //Save
                Thread.sleep(2000);
            //Opening Return order for status
                driver.findElement(By.xpath("//div[2]/ul/li[2]/a")).click();
                Thread.sleep(2000);
                driver.findElement(By.xpath("//li[4]/a/span")).click();
                Thread.sleep(2000);
                driver.findElement(By.linkText("Return requests")).click();
                Thread.sleep(2000);
            }
            Thread.sleep(2000);
            return true;
        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fCalculateSalesTax: Exception: " + oException.toString());
            return false;
        }
    }
    // End of fMenuSelection
    /*******************************************************************************************************************
     * Description   : Function for Add a product for transaction
     * @param  sMenuOption = On which window we are verifying tax
     ******************************************************************************************************************/
    boolean fVerifyTaxValues(String sMenuOption) throws InterruptedException {
        String   sErrorMessage;
        String sSalesTax;
        String  sTaxID = null;
        String [] sExpectedSalesTax;
        // If error message is enabled
        if ( sGLErrorMessageDisplayed != null)
        {
            if(sMenuOption.equalsIgnoreCase("StoreCart"))
            sErrorMessage = driver.findElement(By.xpath("//div[@id='tygh_container']/div[3]/div/div/b")).getText();  // Storing store front error message
             else
            sErrorMessage = driver.findElement(By.xpath("//b")).getText();  // Storing Admin front error message
            sErrorMessage = sErrorMessage.replaceAll("\\n"," ");
            fLogMessage(1,sGLTestCaseName,"Error message appeared as " + sErrorMessage );
            driver.findElement(By.xpath("//div[@id='tygh_container']/div[3]/div/button")).clear(); //closing error message
        }
        else
        {    // Verify tax at store front
            if(sMenuOption.equalsIgnoreCase("StoreCart"))
            {
                if(IsElementPresent(By.linkText("Credit card")))   // Credit cart field
                {
                    sTaxID = driver.findElement(By.xpath("//tr[4]/td[2]/span")).getText();

                    if (sGLDisableTaxCalc !=null)
                    {
                        sTaxID = sTaxID.replaceAll(",","");

                        // sTaxID=sTaxID.substring(0,1)+","+sTaxID.substring(1,sTaxID.length()-1);
                    }
                }
                else
                   // sTaxID = "//div[@id='confirm']/div[2]/div/table/tfoot/tr[2]/td[2]";
                    sTaxID = driver.findElement(By.xpath("//tr[3]/td[2]/span")).getText();    // Verify tax for zero shipping
                if (sGLDisableTaxCalc !=null)
                {
                    sTaxID = sTaxID.replaceAll(",","");

                    // sTaxID=sTaxID.substring(0,1)+","+sTaxID.substring(1,sTaxID.length()-1);

                }
                   // sTaxID = "//tr[4]/td[2]/span";
            }
            else if(sMenuOption.equalsIgnoreCase("AdminCart"))
            {
                //sTaxID = "//tr[5]/td[2]";
                sTaxID = driver.findElement(By.xpath("//tr[5]/td[2]/span")).getText();
            }
            //sSalesTax = selenium.getText(sTaxID);
            sSalesTax =  sTaxID;
            sExpectedSalesTax = sSalesTax.split("\\$");
            sGLTotalTax = sGLTotalTax.trim();
            if (sExpectedSalesTax[1].equalsIgnoreCase(sGLTotalTax))
                fLogMessage(1,sGLTestCaseName,"'Total Sales Tax' " + sGLTotalTax + " verified successfully for Test case " +sGLTestCaseName
                        + " on "  + sMenuOption + " Window.");
            else
            {
                fLogMessage(0,sGLTestCaseName,"'Total Sales Tax' " + sGLTotalTax + " NOT verified successfully for Test case" +sGLTestCaseName
                        + " on " + sMenuOption + " Window.Expected Tax :- " + sGLTotalTax + " and Actual Tax:- " + sExpectedSalesTax[1]);
                return false;
            }
        }

        return true;
    }
    // End of fVerifyTaxValues
    /*******************************************************************************************************************
     * Description   : Function for verifying the status
     * @param  sMenuOption = On which window we are verifying status
     ******************************************************************************************************************/
    boolean fVerifyStatusAndTaxOnWindow(String sMenuOption) throws InterruptedException {
        String sOnscreenAvalaraStatus;
        String sStatusID = null;
        boolean bResult;
        //Click on Calculate Sales Tax Button depending upon passed parameter
        if((sMenuOption.equalsIgnoreCase("RMA")))
        {
            sStatusID = driver.findElement(By.xpath("//td[3]")).getText();
        }
        else
        {
        if((sMenuOption.equalsIgnoreCase("AdminCart")))
        {    ExecutionDelay (8);
            driver.findElement(By.xpath("//button[@type='button']")).click();
            ExecutionDelay (4);
            driver.findElement(By.xpath("//button[@type='button']")).click();
            ExecutionDelay (4);
           // driver.findElement(By.xpath("//button[@type='button']")).click();
            sGLAvalaraDocStatus="Complete";
            driver.findElement(By.xpath("//div[2]/div/a/span")).click();
            driver.findElement(By.linkText("Complete")).click();
    //////////////////////////// VERIFYING TAX AT ADMIN CART FOR COMMIT TRANSACTION ///////////////////////////////////
            bResult=  fVerifyTaxValues ("AdminCart");
            if (!bResult)
                return false;
        // Clicking on Save button
            driver.findElement(By.linkText("Save changes")).click();
            ExecutionDelay (10);
        }
        else if (sMenuOption.equalsIgnoreCase("StoreCart") ) //For Order
        {
            sGLAvalaraDocStatus="Open";
        }
        driver.findElement(By.xpath("//div[2]/ul/li[2]/a")).click();  //Clicking on order tab
        Thread.sleep(500);
        driver.findElement(By.xpath("//li[2]/ul/li/a/span")).click();  // Clicking on view order tab
        ExecutionDelay (10);
        Thread.sleep(2000);
        sStatusID =  "//td[3]/div/a";
        }
        ExecutionDelay (8);
            sOnscreenAvalaraStatus= driver.findElement(By.xpath(sStatusID)).getText();

            if (sOnscreenAvalaraStatus.equalsIgnoreCase(sGLAvalaraDocStatus))
                fLogMessage(1,sGLTestCaseName,"Avalara Status ' " + sGLAvalaraDocStatus + "' verified successfully on Calculate for Test case " +sGLTestCaseName
                        + " On tax calculation on " + sMenuOption + " Window ");
            else
            {
                fLogMessage(0,sGLTestCaseName,"Avalara Status ' " + sGLAvalaraDocStatus + " ' NOT verified successfully on Calculate for Test case " +sGLTestCaseName
                        + " On tax calculation for on " + sMenuOption + " Window " + "Expected : " + sGLAvalaraDocStatus + " and Actual: "+ sOnscreenAvalaraStatus);

                return false;
        }
        ExecutionDelay (10);
        return true;
    }
    // End of fVerifyStatusAndTaxOnWindow
    /*******************************************************************************************************************
     * Function : fAdminSetting
     * Description   : Function for CS Cart settings at admin front
     ******************************************************************************************************************/
    public boolean fAdminSetting() throws Exception
    {
        try{

            // Configuration setting
            Thread.sleep(2000);
            ExecutionDelay (8);
           // Actions action = new Actions(driver);
           // WebElement mainMenu = driver.findElement(By.linkText("Add-ons"));
           // action.moveToElement(mainMenu).moveToElement(driver.findElement(By.linkText("Manage Add-ons"))).click().build().perform();

            //driver.findElement(By.linkText("Add-ons")).wait();
            driver.findElement(By.linkText("Add-ons")).click();
            //driver.findElement(By.linkText("Add-ons")).wait(5);
            ExecutionDelay (2);
            driver.findElement(By.linkText("Manage Add-ons")).click();
            ExecutionDelay (12);
            driver.findElement(By.linkText("AvaTax Tax Calculation")).click();
            ExecutionDelay (8);

            // For disable tax calculation test case

            if(sGLEnableTaxCalculation!=null)
            {
                driver.findElement(By.id("variant_avatax_tax_calculation_1")).click();
            }
            else
            {
                driver.findElement(By.id("variant_avatax_tax_calculation_0")).click();
            }
            // UPC Code setting
            if (sGLUPCCode!=null)
            {
                driver.findElement(By.id("variant_avatax_tax_upc_1")).click();
            }
            else
            {
                driver.findElement(By.id("variant_avatax_tax_upc_0")).click();
            }
            // Saving transaction on Avalara admin console
            if (sGLSaveDoce_AvaAdmin!=null)
            {
                driver.findElement(By.id("variant_avatax_tax_savedoc_1")).click();
            }
            else
            {
                driver.findElement(By.id("variant_avatax_tax_savedoc_0")).click();
            }
            ////////////////////Log reader //////////////////
            driver.findElement(By.id("variant_avatax_log_mode_1")).click();    // Enable log reader at config UI
            //driver.findElement(By.id("variant_avatax_tax_Log_0")).click();    // Disable log reader at config UI
            // Saving the configuration setting
            driver.findElement(By.xpath("//div[9]/div[2]/div/div/div[2]/form/div[2]/input")).click();
            ExecutionDelay (10);

            // Shipping charges setting
           // WebElement element = driver.findElement(By.xpath("//li[2]/a/b"));
            //WebElement element1 = driver.findElement(By.xpath("//li[5]/a"));
           // Actions action = new Actions(driver);

           // action.moveToElement(element).build().perform();
           // action.moveToElement(element1).build().perform();
           // driver.findElement(By.linkText("Shipping methods")).click();


            Thread.sleep(2000);
            /*
            driver.findElement(By.xpath("//li[2]/a/b")).click();
            Thread.sleep(1000);
            driver.findElement(By.xpath("//li[5]/a")).click();
            Thread.sleep(1000);
            driver.findElement(By.linkText("Shipping methods")).click();
            ExecutionDelay (10);
             */
            driver.findElement(By.id("elm_menu_administration")).click();
            Thread.sleep(1000);
            driver.findElement(By.id("elm_menu_administration_shippings_taxes")).click();
            Thread.sleep(1000);
            driver.findElement(By.id("elm_menu_administration_shippings_taxes_shipping_methods")).click();
            ExecutionDelay (10);



            Thread.sleep(2000);
            driver.findElement(By.linkText("Custom shipping method")).click();
            ExecutionDelay (8);

            if  (sGLEnableShippingCharges == null)
            {
                driver.findElement(By.id("elm_shipping_status_0_d")).click();       // Enter Value
            }
            else
            {
                driver.findElement(By.id("elm_shipping_status_0_a")).click();
                sGLProductType  = oResultSet.getString("TaxCodeMapping");// Enter Value
                if (sGLProductType.equalsIgnoreCase("1"))
                {
                    driver.findElement(By.id("elm_tax_code")).clear();
                   driver.findElement(By.id("elm_tax_code")).sendKeys("1");
                }
                else if  (sGLProductType.equalsIgnoreCase("NT"))
                {
                    driver.findElement(By.id("elm_tax_code")).clear();
                    driver.findElement(By.id("elm_tax_code")).sendKeys("NT");
                }
                else
                {
                    driver.findElement(By.id("elm_tax_code")).clear();
                    driver.findElement(By.id("elm_tax_code")).sendKeys("");
                }
            }

           // driver.findElement(By.linkText("Save")).click();     // Saving the shipping setting
            driver.findElement(By.linkText("Save and close")).click();
            ExecutionDelay (10);

            /////////////////////////////////   DISCOUNT    /////////////////////////////
           /*
            driver.findElement(By.linkText("Marketing")).click();
            driver.findElement(By.xpath("//li[5]/ul/li/a/span")).click();
            ExecutionDelay (10);
           if (IsElementPresent(By.linkText("Ajay")))  // If discount promotion is already created
           {     driver.findElement(By.id("sw_select_16_wrap")).click();
               if ((sGLDiscount == "1"))
               {
                   driver.findElement(By.xpath("//tr[3]/td[6]/div/ul/li/a")).click();  // Click on active
               }
               else
               {
                   driver.findElement(By.xpath("//tr[3]/td[6]/div/ul/li[2]/a")).click();   // Click on disable
               }
           }
           else          // If discount not created - Create discount
           {

            driver.findElement(By.xpath("//div[3]/div/div/a/i")).click();  //Clicking on Add promotion + sign
            driver.findElement(By.linkText("Add cart promotion")).click();    // Add cart promotion
            ExecutionDelay (10);
            driver.findElement(By.xpath("//button")).click();  // Warning message
            driver.findElement(By.xpath("//button[@type='button']")).click();    // Warning message
            driver.findElement(By.xpath("//button[@type='button']")).click();     // Warning message
           // driver.findElement(By.xpath("//button[@type='button']")).click();     // Warning message
            driver.findElement(By.id("elm_promotion_name")).clear();
            driver.findElement(By.id("elm_promotion_name")).sendKeys("Ajay");

            driver.findElement(By.linkText("Conditions")).click();
               Thread.sleep(500);
            driver.findElement(By.linkText("Add condition")).click();
               Thread.sleep(500);
            new Select(driver.findElement(By.name("promotion_data[conditions][conditions][1]"))).selectByVisibleText("Product price");
            driver.findElement(By.name("promotion_data[conditions][conditions][1][value]")).clear();
            driver.findElement(By.name("promotion_data[conditions][conditions][1][value]")).sendKeys("1000");
            driver.findElement(By.linkText("Bonuses")).click();
               Thread.sleep(500);
            driver.findElement(By.id("add_bonus")).click();
            new Select(driver.findElement(By.id("add_bonus_2"))).selectByVisibleText("Order discount");
            driver.findElement(By.linkText("Create")).click();
            driver.findElement(By.xpath("//input[4]")).click();
            driver.findElement(By.linkText("Save")).click();
               Thread.sleep(2000);
               ExecutionDelay (10);
           }
            */
            ////////////////////////////////// CUSTOMER EXEMPTION  ///////////////////////////////////////

               driver.findElement(By.linkText("Customers")).click();
               Thread.sleep(2000);
               driver.findElement(By.xpath("//li[4]/ul/li[2]/a/span[2]")).click();
               ExecutionDelay (10);
               //driver.findElement(By.linkText("Customer Customer")).click();
               driver.findElement(By.xpath("//td[3]/a")).click();  // FirstCustomer Link
               ExecutionDelay (10);

            if ((sGLCustExemptNo != null))
            {
            if (!driver.findElement(By.id("tax_exempt")).isSelected() )
            {
                driver.findElement(By.id("email")).sendKeys("awa@awa.com");
                driver.findElement(By.id("password1")).sendKeys("kennwort");
                driver.findElement(By.id("password2")).sendKeys("kennwort");
                driver.findElement(By.id("tax_exempt")).click();
                driver.findElement(By.id("tax_exempt_number")).clear();
                driver.findElement(By.id("tax_exempt_number")).sendKeys("1234");
                sCust = "Customer Customer" ;
            }
            }
           else
            {
                if (driver.findElement(By.id("tax_exempt")).isSelected() )
                {
                    driver.findElement(By.id("tax_exempt")).click();
                    driver.findElement(By.id("tax_exempt_number")).clear();
                //  driver.findElement(By.id("tax_exempt_number")).sendKeys("Tax Exempt");
                }
            }
            if ((sGLEntityUseCode != null))
            {
                new Select(driver.findElement(By.id("tax_entity_usecode"))).selectByVisibleText("A - Federal government (United States)");
                sCust = "Customer Customer" ;
            }
                else
            {
                new Select(driver.findElement(By.id("tax_entity_usecode"))).selectByVisibleText("- - Select Entity Use Code");
            }
            driver.findElement(By.linkText("Save changes")).click();
            ExecutionDelay (10);
        // Done the exemption setting
           // if(IsElementPresent(By.linkText("Add-ons")))
           if(IsElementPresent(By.id("elm_menu_addons")))
            {
                fLogMessage(1,sGLTestCaseName,"All the CS cart admin setting is updated successfully");
            }
            else
                fLogMessage(0,sGLTestCaseName,"All the CS Cart admin setting is not updated successfully");
            return true;
        }
        catch (Exception oException)
        {
            fLogMessage(0,sGLTestCaseName,"fUpdateSettingsException:" + oException.toString());
            return false;
        }
    }

    // End of fAdminSetting






































    //    End of fAddressValidation


    /*

     public boolean IisElementPresent(By sElementLocatorDesc)
     {
         if(driver.findElements(sElementLocatorDesc).size() > 0)
         {
             return true;
         }
         else
         {
             return false;
         }

     }

     public boolean IesElementPresent(By xpath)
     {
         if(driver.findElements(xpath).size() > 0)
         {
             return true;
         }
         else
         {
             return false;
         }

     }
     public boolean IasElementPresent(By linkText)
     {
         if(driver.findElements(linkText).size() > 0)
         {
             return true;
         }
         else
         {
             return false;
         }

     }
     */
    public boolean IsElementPresent(By by)
    {
        return driver.findElements(by).size() > 0;

    }

  /*
    public boolean IsElementPresent(By by)
    {
        if(driver.findElements(by).size() > 0)
        {
            return true;
        }
        else

            return false;

    }
   */

    ////////////// CONNECTOR MATRIX SCRIPT //////////////////////////


    //////////////////////////// Create products  ///////////////////////////////
    public boolean fCreateProducts()
    {      int iCount =300;
        boolean bResult;
        try
        {
            for ( int iTemp = 201; iTemp <= iCount; iTemp++)
            {
                // sGLTestCaseName = "TestCase" + iTemp;

                driver.findElement(By.xpath("(//a[contains(text(),'Products')])[3]")).click();
                Thread.sleep(1000);
                driver.findElement(By.xpath("//div[@id='header_subnav']/ul/li[3]/ul/li[2]/a")).click();
                Thread.sleep(3000);
                ExecutionDelay (10);
                driver.findElement(By.xpath("//div[3]/div/div/a/i")).click();
                Thread.sleep(3000);
                ExecutionDelay (10);
                driver.findElement(By.id("product_description_product")).clear();
                driver.findElement(By.id("product_description_product")).sendKeys("Test"+iTemp);
                driver.findElement(By.xpath("//div[3]/div/input")).clear();
                driver.findElement(By.xpath("//div[3]/div/input")).sendKeys("1000");
                driver.findElement(By.xpath("//form/div/div/div[2]/div/a")).click();
                Thread.sleep(2000);
                ExecutionDelay (10);
                driver.findElement(By.xpath("//div/div/div/div/table/tbody/tr/td/input")).click();
                Thread.sleep(200);
                ExecutionDelay (5);
                driver.findElement(By.name("submit")).click();
                Thread.sleep(1000);
                ExecutionDelay (10);
                driver.findElement(By.id("category_rb_168")).click();
                driver.findElement(By.id("elm_product_code")).clear();
                driver.findElement(By.id("elm_product_code")).sendKeys("Test"+iTemp);
                driver.findElement(By.id("elm_list_price")).clear();
                driver.findElement(By.id("elm_list_price")).sendKeys("1000");
                driver.findElement(By.id("elm_tax_code")).clear();
                driver.findElement(By.id("elm_tax_code")).sendKeys("1");
                driver.findElement(By.linkText("Create and close")).click();
                Thread.sleep(2000);
                ExecutionDelay (10);
               // driver.findElement(By.name("dispatch[products.update]")).click();
                //Thread.sleep(2000);










                  /*


                driver.findElement(By.linkText("Products")).click();
                Thread.sleep(2000);

                driver.findElement(By.name("new")).click();
                Thread.sleep(2000);
                driver.findElement(By.id("Name")).clear();
                driver.findElement(By.id("Name")).sendKeys("Test"+iTemp);
                driver.findElement(By.id("ProductCode")).clear();
                driver.findElement(By.id("ProductCode")).sendKeys("Test"+iTemp);
                driver.findElement(By.id("IsActive")).click();
                driver.findElement(By.xpath("//form/div/div[3]/table/tbody/tr/td[2]/input")).click();
                Thread.sleep(2000);
                driver.findElement(By.name("add")).click();
                Thread.sleep(1000);
                driver.findElement(By.id("td0_2")).clear();
                driver.findElement(By.id("td0_2")).sendKeys("1000");
                driver.findElement(By.name("save")).click();
                Thread.sleep(2000);
                driver.findElement(By.name("add")).click();
                Thread.sleep(2000);
                driver.findElement(By.id("ids0")).click();
                driver.findElement(By.xpath("//div[3]/input")).click();
                Thread.sleep(1000);
                driver.findElement(By.id("td0_8")).clear();
                driver.findElement(By.id("td0_8")).sendKeys("1000");
                driver.findElement(By.name("save")).click();
                Thread.sleep(2000);
                */
            }

            return true;
        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, "Products Creation failed " + oException.toString());
            return false;
        }
    }

        public boolean fLine_EntryForMultipleProducts()
        {      int iCount =279;
            int iLoop =10;
            //boolean bResult;
        //    int tr =5;
        //    String td ="";
            boolean bResult;
           // int iTemp;
            String sCustEmailID = fRamdomString (6);
           // String sCustName ;
            String sCustLastName = fRamdomString (4);
            String  sCardNumber =  "1234567890123456";// fRamdomInt (16);
            String  sCVVNumber =  "234";
            String  sYear =  "08";
            String  sCardHolder =  fRamdomString (3);
            try
            {
                for ( int iTemp1 = 1; iTemp1 <= iLoop; iTemp1++)
                {


                for ( int iTemp = 80; iTemp <= iCount; iTemp++)
                {
                    /*
                    driver.get("http://localhost/cscart423logreader/index.php?dispatch=products.search");
                    Thread.sleep(20000);
                   // driver.get(baseUrl + "/cscart423logreader/index.php?dispatch=products.search");
                    driver.findElement(By.name("q")).clear();
                    driver.findElement(By.name("q")).sendKeys("Test"+iTemp);
                    driver.findElement(By.name("dispatch[products.search]")).click();
                    Thread.sleep(20000);
                    driver.findElement(By.xpath("//form/div/a/span")).click();
                     */
                    driver.get("http://localhost/cscart423logreader/electronics/computers/desktops/"+"Test"+iTemp);
                    Thread.sleep(20000);
                    driver.findElement(By.xpath("//div[7]/div/button")).click();
                    Thread.sleep(20000);




                  /*

                   driver.findElement(By.id("search_input")).clear();

                    driver.findElement(By.id("search_input")).sendKeys("Test"+iTemp);
                  //  Thread.sleep(22000);
                    driver.findElement(By.id("search_input")).sendKeys(Keys.ENTER);
                    //driver.findElement(By.xpath("//form/button")).sendKeys(Keys.ENTER);
                   // driver.findElement(By.xpath("//form/button")).click();
                   Thread.sleep(10000);
                    driver.findElement(By.xpath("//a/span/i")).click();
                 //   Thread.sleep(5000);
                    driver.findElement(By.xpath("//div[7]/div/button")).click();
                  Thread.sleep(20000);
                  */
                }
               // ExecutionDelay (10);
                   /////////////////////////////////////////////////////////////////
                    driver.findElement(By.xpath("//div[3]/div/div/div")).click();
                    ExecutionDelay (2);
                    driver.findElement(By.linkText("Checkout")).click();
                    ExecutionDelay (8);
                    driver.findElement(By.id("checkout_type_guest")).click();
                    driver.findElement(By.xpath("//div[3]/form/div/button")).click();
                    ExecutionDelay (8);
                    driver.findElement(By.xpath("//div[2]/div/div/div/input")).clear();
                    driver.findElement(By.xpath("//div[2]/div/div/div/input")).sendKeys("Ajay_Connector_Matrix");
                    driver.findElement(By.xpath("//div/div/div[2]/input")).clear();
                    driver.findElement(By.xpath("//div/div/div[2]/input")).sendKeys(sCustLastName);
                    driver.findElement(By.xpath("//div/div/div[3]/input")).clear();
                    driver.findElement(By.xpath("//div/div/div[3]/input")).sendKeys(sCustEmailID+"@cscart.com");
                    driver.findElement(By.xpath("//div[5]/input")).clear();
                    // Enter Customer Address
                    driver.findElement(By.xpath("//div[5]/input")).sendKeys("900 winslow way e");//(sGLShiptoAddress_Line1);
                    driver.findElement(By.xpath("//div[7]/input")).clear();
                    driver.findElement(By.xpath("//div[7]/input")).sendKeys("Bainbridge Island");//(sGLShiptoAddress_City);
                    new Select(driver.findElement(By.xpath("//div[9]/select"))).selectByVisibleText("Washington");
                    driver.findElement(By.xpath("//div[10]/input")).clear();
                    driver.findElement(By.xpath("//div[10]/input")).sendKeys("98110");//(sGLShiptoAddress_Zip);
                    driver.findElement(By.xpath("//div[4]/button")).click();
                    ExecutionDelay (15);

                // driver.findElement(By.xpath("//div[3]/div/form/div[2]/button")).click(); // Shipping continue button
                driver.findElement(By.id("step_three_but")).click(); // Shipping continue button
                ExecutionDelay (15);
               // bResult=  fVerifyTaxValues ("StoreCart");
               // if (!bResult)
               //     return false;
               //Thread.sleep(2000);
                driver.findElement(By.id("payments_tab1")).click();
                ExecutionDelay (5);
                driver.findElement(By.id("credit_card_number_1")).clear();
                driver.findElement(By.id("credit_card_number_1")).sendKeys(sCardNumber);
                driver.findElement(By.id("credit_card_cvv2_1")).clear();
                driver.findElement(By.id("credit_card_cvv2_1")).sendKeys(sCVVNumber);
                driver.findElement(By.id("credit_card_month_1")).clear();
                driver.findElement(By.id("credit_card_month_1")).sendKeys("09");
                driver.findElement(By.id("credit_card_year_1")).clear();
                driver.findElement(By.id("credit_card_year_1")).sendKeys(sYear);
                driver.findElement(By.id("credit_card_name_1")).clear();
                driver.findElement(By.id("credit_card_name_1")).sendKeys("Ajay"+sCardHolder);
                driver.findElement(By.xpath("//div[2]/div/form/div[2]/button")).click(); // Submit Order
                ExecutionDelay (10);
                    ////////////////////////////////////////////////////////////////

                   /*
                    // Thread.sleep(2000);
                    // Entering amount and quantity
                    driver.findElement(By.xpath("//tr["+tr+"]/td/input")).clear();
                    driver.findElement(By.xpath("//tr["+tr+"]/td/input")).sendKeys("1");
                    driver.findElement(By.xpath("//"+td+"td[2]/input")).clear();
                    driver.findElement(By.xpath("//"+td+"td[2]/input")).sendKeys("1000");

                    tr = tr+4;
                    td =  "tr["+tr+"]/";
                   */
               // }

                }
                return true;
            }


            catch(Exception oException)
            {
                fLogMessage(0, sGLTestCaseName, "Products Creation failed " + oException.toString());
                return false;
            }






    }
    ////////////// CONNECTOR MATRIX SCRIPT END//////////////////////////





}
