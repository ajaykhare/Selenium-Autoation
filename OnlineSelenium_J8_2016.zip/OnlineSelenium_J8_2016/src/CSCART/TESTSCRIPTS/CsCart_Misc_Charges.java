package CSCART.TESTSCRIPTS;


import CSCART.FUNCTIONLIBRARY.FunctionLibrary_CsCart;

/**
 * Created with IntelliJ IDEA.
 * User: Ajay.Khare
 * Date: 1/9/15
 * Time: 10:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class CsCart_Misc_Charges extends FunctionLibrary_CsCart {
    public static void main(String[] args)
    {
        try
        {
            CsCart_Misc_Charges oTestMain = new CsCart_Misc_Charges();
            oTestMain.testmain();
        }
        catch(Exception oException)
        {
            System.out.println(oException.toString());
        }
    }

    public void testmain()
    {
        String sScriptName = "";
        int iCount =10;
        boolean bResult;
        bGLTaxCodeAtLinelevel = false;
        try
        {
            sGLCustomer = "Testing";
            sGLItem1Code = "GenWatt Diesel 1000kW";
            sGLItem2Code = "GenWatt Diesel 10kW";
            sGLItem3Code = "GenWatt Diesel 200kW";


            //Step 1: Browse to application URL and login
            //bResult = false;
            bResult = fStartFunction();
            if(!bResult)
                return;
            // Start Data sheet test cases execution
            for (int iTemp = 10; iTemp <= iCount; iTemp++)
            {
                sGLTestCaseName = "TestCase" + iTemp;
                fCalculateSalesTax (sGLTestCaseName);
            }
        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, oException.toString());
        }
        finally
        {
            fFinallyFunction(sScriptName);
        }
        //return;
    }
}
