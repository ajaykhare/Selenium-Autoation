package CSCART.TESTSCRIPTS;

import CSCART.FUNCTIONLIBRARY.FunctionLibrary_CsCart;

/**
 * Created with IntelliJ IDEA.
 * User: Ajay.Khare
 * Date: 2/4/15
 * Time: 3:07 PM
 * To change this template use File | Settings | File Templates.
 */
public class CsCart_RMA extends FunctionLibrary_CsCart {
    public static void main(String[] args)
    {
        try
        {
            CsCart_RMA oTestMain = new CsCart_RMA();
            oTestMain.testmain();
        }
        catch(Exception oException)
        {
            System.out.println(oException.toString());
        }
    }

    public void testmain()
    {
        String sScriptName = "";
        int iCount =133;
        boolean bResult;
        bGLTaxCodeAtLinelevel = false;
        try
        {
            sGLCustomer = "Testing";
            sGLItem1Code = "GenWatt Diesel 1000kW";
            sGLItem2Code = "GenWatt Diesel 10kW";
            sGLItem3Code = "GenWatt Diesel 200kW";


            //Step 1: Browse to application URL and login
            //bResult = false;
            bResult = fStartFunction();
            if(!bResult)
                return;
            // Start Data sheet test cases execution
            for (int iTemp = 130; iTemp <= iCount; iTemp++)
            {
                sGLTestCaseName = "TestCase" + iTemp;
                fCalculateSalesTax (sGLTestCaseName);
            }
        }
        catch(Exception oException)
        {
            fLogMessage(0, sGLTestCaseName, oException.toString());
        }
        finally
        {
            fFinallyFunction(sScriptName);
        }
        //return;
    }
}
